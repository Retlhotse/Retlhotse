"""
Agent — the main orchestrator.

Wires together:
    • ChatOpenAI (gpt-4o)
    • ConversationMemory (auto-summarising context manager)
    • All skill tools (auto-discovered)

Uses LangChain's ``create_tool_calling_agent`` + ``AgentExecutor`` so the
model can autonomously decide which tools to call.
"""

from __future__ import annotations

from langchain_openai import ChatOpenAI
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

from config.settings import MODEL_NAME
from utils.memory import ConversationMemory
from utils.skill_registry import discover_tools

# ---------------------------------------------------------------------------
# System prompt — customise freely
# ---------------------------------------------------------------------------
SYSTEM_PROMPT = """\
You are a helpful AI assistant with access to a database via specialised tools.

Guidelines:
- Always use the provided tools to query the database; never fabricate data.
- If a query is ambiguous, ask the user to clarify before running a tool.
- Present results in a clear, human-friendly format.
- If a tool returns no results, say so honestly.
"""


def build_agent() -> tuple[AgentExecutor, ConversationMemory]:
    """
    Construct the agent and its memory. Returns both so the caller can
    feed messages into memory and invoke the agent.
    """
    # 1. LLM
    llm = ChatOpenAI(model=MODEL_NAME, temperature=0, streaming=True)

    # 2. Tools (auto-discovered from skills/)
    print("Discovering skills …")
    tools = discover_tools()

    # 3. Prompt template — note the ``chat_history`` placeholder which
    #    the memory manager populates before every invocation.
    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", SYSTEM_PROMPT),
            MessagesPlaceholder(variable_name="chat_history"),
            ("human", "{input}"),
            MessagesPlaceholder(variable_name="agent_scratchpad"),
        ]
    )

    # 4. Build agent + executor
    agent = create_tool_calling_agent(llm, tools, prompt)
    executor = AgentExecutor(
        agent=agent,
        tools=tools,
        verbose=True,          # flip to False in production
        handle_parsing_errors=True,
        max_iterations=10,
    )

    # 5. Memory
    memory = ConversationMemory(system_prompt=SYSTEM_PROMPT)

    return executor, memory
