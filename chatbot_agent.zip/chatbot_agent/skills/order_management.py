"""
Skill: Order Management
───────────────────────
Tools for querying orders and order line items.
"""

from langchain_core.tools import tool
from db.connection import execute_query


@tool
def get_orders_for_user(user_id: int) -> str:
    """Retrieve all orders for a given user, most recent first."""
    rows = execute_query(
        "SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC LIMIT 50",
        (user_id,),
    )
    if not rows:
        return f"No orders found for user {user_id}."
    return "\n".join(str(r) for r in rows)


@tool
def get_order_details(order_id: int) -> str:
    """Get full details for a single order including its line items."""
    order = execute_query("SELECT * FROM orders WHERE id = ?", (order_id,))
    if not order:
        return f"Order {order_id} not found."
    items = execute_query(
        "SELECT * FROM order_items WHERE order_id = ?", (order_id,)
    )
    return f"Order: {order[0]}\nItems: {items}"


@tool
def get_recent_orders(limit: int = 10) -> str:
    """Get the N most recent orders across all users."""
    rows = execute_query(
        "SELECT * FROM orders ORDER BY created_at DESC LIMIT ?", (limit,)
    )
    if not rows:
        return "No orders found."
    return "\n".join(str(r) for r in rows)


# ── Export ────────────────────────────────────────────────────────────────
tools = [get_orders_for_user, get_order_details, get_recent_orders]
