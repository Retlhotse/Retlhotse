"""
Skill: <NAME>
────────────────────
<DESCRIPTION>

Copy this file to create a new skill.
1.  Rename it (e.g. ``skills/inventory.py``).
2.  Add your @tool functions.
3.  List them in the ``tools`` export at the bottom.
4.  The agent picks them up automatically on next start.
"""

from langchain_core.tools import tool
from db.connection import execute_query, execute_write


@tool
def example_read_tool(param: str) -> str:
    """Describe what this tool does — the LLM reads this docstring."""
    rows = execute_query("SELECT 1 AS test WHERE ? IS NOT NULL", (param,))
    return str(rows)


@tool
def example_write_tool(value: str) -> str:
    """Describe the write operation this tool performs."""
    affected = execute_write(
        "UPDATE some_table SET col = ? WHERE id = 1", (value,)
    )
    return f"{affected} row(s) updated."


# ── Export ────────────────────────────────────────────────────────────────
tools = [example_read_tool, example_write_tool]
