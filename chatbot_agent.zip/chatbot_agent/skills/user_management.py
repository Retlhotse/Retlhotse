"""
Skill: User Management
──────────────────────
Tools for querying and managing users in the database.

Add / modify tools here.  Each must be decorated with ``@tool`` and
included in the module-level ``tools`` list at the bottom.
"""

from langchain_core.tools import tool
from db.connection import execute_query, execute_write


@tool
def get_user_by_id(user_id: int) -> str:
    """Look up a single user by their numeric ID. Returns user details."""
    rows = execute_query("SELECT * FROM users WHERE id = ?", (user_id,))
    if not rows:
        return f"No user found with id {user_id}."
    return str(rows[0])


@tool
def search_users(name: str) -> str:
    """Search for users whose name contains the given string (case-insensitive)."""
    rows = execute_query(
        "SELECT id, name, email FROM users WHERE name LIKE ? LIMIT 20",
        (f"%{name}%",),
    )
    if not rows:
        return f"No users matching '{name}'."
    return "\n".join(str(r) for r in rows)


@tool
def count_users() -> str:
    """Return the total number of users in the database."""
    rows = execute_query("SELECT COUNT(*) AS total FROM users")
    return str(rows[0]["total"])


# ── Export ────────────────────────────────────────────────────────────────
tools = [get_user_by_id, search_users, count_users]
