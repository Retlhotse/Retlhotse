"""
Conversation memory with automatic summarisation.

Strategy
--------
1.  Every user / assistant turn is appended to the full history.
2.  Before each LLM call we count tokens.  If the history exceeds
    SUMMARY_THRESHOLD_TOKENS we *compartmentalise*:
      - The oldest N messages (everything before the most recent K turns)
        are summarised into a single SystemMessage ("running summary").
      - Only the running summary + the recent K turns are sent to the model.
3.  The running summary is itself updated incrementally: the new summary is
    produced by asking the LLM to merge the *previous* summary with the
    messages that are about to be evicted.

This gives the model a compressed memory of the full conversation while
keeping the context window well within budget.
"""

from __future__ import annotations

import tiktoken
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
)
from langchain_openai import ChatOpenAI

from config.settings import (
    MAX_CONTEXT_TOKENS,
    MODEL_NAME,
    REPLY_RESERVE_TOKENS,
    SUMMARY_THRESHOLD_TOKENS,
)

# ---------------------------------------------------------------------------
# Token helpers
# ---------------------------------------------------------------------------
_encoder = tiktoken.encoding_for_model(MODEL_NAME)


def count_tokens(text: str) -> int:
    return len(_encoder.encode(text))


def count_message_tokens(messages: list[BaseMessage]) -> int:
    """Rough token count for a list of LangChain messages."""
    total = 0
    for msg in messages:
        # 4 tokens overhead per message (role, delimiters)
        total += 4
        content = msg.content if isinstance(msg.content, str) else str(msg.content)
        total += count_tokens(content)
    return total


# ---------------------------------------------------------------------------
# Memory manager
# ---------------------------------------------------------------------------
RECENT_TURNS_TO_KEEP = 10  # keep last N exchanges verbatim


class ConversationMemory:
    """Manages full history + a rolling summary for long conversations."""

    def __init__(self, system_prompt: str):
        self.system_prompt = system_prompt
        self.full_history: list[BaseMessage] = []
        self.running_summary: str | None = None
        self._llm = ChatOpenAI(model=MODEL_NAME, temperature=0, max_tokens=1024)

    # -- public API ---------------------------------------------------------

    def add_user_message(self, text: str) -> None:
        self.full_history.append(HumanMessage(content=text))

    def add_ai_message(self, text: str) -> None:
        self.full_history.append(AIMessage(content=text))

    def add_message(self, message: BaseMessage) -> None:
        self.full_history.append(message)

    async def get_context_messages(self) -> list[BaseMessage]:
        """
        Return the message list to send to the LLM, summarising old
        messages if the token budget is exceeded.
        """
        system_msg = SystemMessage(content=self.system_prompt)
        candidate = [system_msg] + self._build_history_window()

        token_count = count_message_tokens(candidate)
        budget = MAX_CONTEXT_TOKENS - REPLY_RESERVE_TOKENS

        if token_count > SUMMARY_THRESHOLD_TOKENS:
            await self._summarise_old_messages()
            candidate = [system_msg] + self._build_history_window()

        return candidate

    # -- internals ----------------------------------------------------------

    def _build_history_window(self) -> list[BaseMessage]:
        """Recent turns, optionally prefixed by the running summary."""
        recent = self.full_history[-RECENT_TURNS_TO_KEEP * 2 :]
        parts: list[BaseMessage] = []
        if self.running_summary:
            parts.append(
                SystemMessage(
                    content=(
                        "[Conversation summary so far]\n"
                        f"{self.running_summary}"
                    )
                )
            )
        parts.extend(recent)
        return parts

    async def _summarise_old_messages(self) -> None:
        """Compress older messages into the running summary."""
        # Messages that will be evicted (everything except recent window)
        cutoff = len(self.full_history) - RECENT_TURNS_TO_KEEP * 2
        if cutoff <= 0:
            return

        old_messages = self.full_history[:cutoff]
        old_text = "\n".join(
            f"{'User' if isinstance(m, HumanMessage) else 'Assistant'}: {m.content}"
            for m in old_messages
        )

        previous = self.running_summary or "(no prior summary)"

        prompt = (
            "You are a conversation summariser. Merge the previous summary "
            "with the new messages below into a single, concise summary that "
            "preserves every important fact, decision, user preference, and "
            "open question.  Be thorough but compact.\n\n"
            f"## Previous summary\n{previous}\n\n"
            f"## New messages to incorporate\n{old_text}"
        )

        response = await self._llm.ainvoke([HumanMessage(content=prompt)])
        self.running_summary = response.content

        # Drop the old messages from full_history (they're now in the summary)
        self.full_history = self.full_history[cutoff:]
