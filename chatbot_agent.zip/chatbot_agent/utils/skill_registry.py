"""
Skill registry — auto-discovers tool modules in the ``skills/`` package.

Every skill file (e.g. ``skills/user_management.py``) should expose a
module-level list called ``tools`` containing LangChain ``@tool`` decorated
functions.  The registry collects them all so the agent has a single
flat list of available tools.

Adding a new skill:
    1. Create ``skills/my_new_skill.py``
    2. Define one or more @tool functions.
    3. Export them in a module-level ``tools`` list.
    4. That's it — the registry picks them up automatically.
"""

from __future__ import annotations

import importlib
import pkgutil
from pathlib import Path

from langchain_core.tools import BaseTool

import skills  # the package itself, so pkgutil can walk it


def discover_tools() -> list[BaseTool]:
    """Import every module in ``skills/`` and collect their ``tools`` lists."""
    collected: list[BaseTool] = []
    package_path = str(Path(skills.__file__).parent)

    for _importer, module_name, _is_pkg in pkgutil.iter_modules([package_path]):
        if module_name.startswith("_"):
            continue
        module = importlib.import_module(f"skills.{module_name}")
        module_tools = getattr(module, "tools", [])
        collected.extend(module_tools)
        if module_tools:
            print(f"  ✔ loaded {len(module_tools)} tool(s) from skills.{module_name}")

    print(f"  → {len(collected)} total tools registered")
    return collected
