"""
Seed script — creates a sample SQLite database for local testing.

Run once:
    python db/seed.py
"""

import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent / "app.db"


def seed():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT NOT NULL,
            email       TEXT UNIQUE NOT NULL,
            created_at  TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS orders (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL REFERENCES users(id),
            status      TEXT NOT NULL DEFAULT 'pending',
            total       REAL NOT NULL DEFAULT 0,
            created_at  TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS order_items (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id    INTEGER NOT NULL REFERENCES orders(id),
            product     TEXT NOT NULL,
            quantity    INTEGER NOT NULL DEFAULT 1,
            unit_price  REAL NOT NULL
        );

        -- Sample data
        INSERT OR IGNORE INTO users (id, name, email) VALUES
            (1, 'Alice Johnson',  'alice@example.com'),
            (2, 'Bob Smith',      'bob@example.com'),
            (3, 'Charlie Brown',  'charlie@example.com');

        INSERT OR IGNORE INTO orders (id, user_id, status, total) VALUES
            (1, 1, 'shipped',   149.99),
            (2, 1, 'delivered',  29.50),
            (3, 2, 'pending',    75.00);

        INSERT OR IGNORE INTO order_items (order_id, product, quantity, unit_price) VALUES
            (1, 'Wireless Headphones', 1, 149.99),
            (2, 'USB-C Cable',         3,   9.83),
            (3, 'Desk Lamp',           1,  75.00);
        """
    )
    conn.commit()
    conn.close()
    print(f"✔ Database seeded at {DB_PATH}")


if __name__ == "__main__":
    seed()
