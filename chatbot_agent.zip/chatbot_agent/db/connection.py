"""
Thin wrapper around the SQLite database.

Usage in skill tools:
    from db.connection import get_db
    db = get_db()
    rows = db.execute("SELECT * FROM users WHERE id = ?", (user_id,))
"""

import sqlite3
from contextlib import contextmanager
from config.settings import SQLITE_DB_PATH

_connection: sqlite3.Connection | None = None


def get_connection() -> sqlite3.Connection:
    """Return a module-level singleton connection (row-factory enabled)."""
    global _connection
    if _connection is None:
        _connection = sqlite3.connect(SQLITE_DB_PATH, check_same_thread=False)
        _connection.row_factory = sqlite3.Row
        _connection.execute("PRAGMA journal_mode=WAL;")
    return _connection


@contextmanager
def get_cursor():
    """Convenience context manager that yields a cursor and commits."""
    conn = get_connection()
    cur = conn.cursor()
    try:
        yield cur
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()


def execute_query(sql: str, params: tuple = ()) -> list[dict]:
    """Run a read query and return rows as a list of dicts."""
    with get_cursor() as cur:
        cur.execute(sql, params)
        columns = [desc[0] for desc in cur.description] if cur.description else []
        return [dict(zip(columns, row)) for row in cur.fetchall()]


def execute_write(sql: str, params: tuple = ()) -> int:
    """Run an INSERT / UPDATE / DELETE and return rows affected."""
    with get_cursor() as cur:
        cur.execute(sql, params)
        return cur.rowcount
