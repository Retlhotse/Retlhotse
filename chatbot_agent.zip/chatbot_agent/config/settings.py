"""
Centralised configuration loaded once from .env / environment variables.
"""

import os
from dotenv import load_dotenv

load_dotenv()

OPENAI_API_KEY: str = os.environ["OPENAI_API_KEY"]
MODEL_NAME: str = os.getenv("MODEL_NAME", "gpt-4o")
SQLITE_DB_PATH: str = os.getenv("SQLITE_DB_PATH", "./db/app.db")

# --- token budget ----------------------------------------------------------
# gpt-4o has a 128 000-token context window.  We leave headroom for the
# system prompt, tool definitions and the model's reply.
MAX_CONTEXT_TOKENS: int = int(os.getenv("MAX_CONTEXT_TOKENS", 128_000))
SUMMARY_THRESHOLD_TOKENS: int = int(os.getenv("SUMMARY_THRESHOLD_TOKENS", 100_000))
REPLY_RESERVE_TOKENS: int = 4_096
