# Chatbot AI Agent — LangChain + GPT-4o + SQLite

A modular, tool-calling chatbot with automatic conversation summarisation to
stay within the GPT-4o context window.

## Architecture

```
main.py                 ← CLI chat loop (swap for FastAPI / Streamlit)
agent.py                ← Wires LLM + tools + memory into an AgentExecutor
│
├─ config/
│   └─ settings.py      ← All env-driven configuration
│
├─ db/
│   ├─ connection.py    ← SQLite helpers (singleton connection, execute_*)
│   └─ seed.py          ← Creates sample tables & data for testing
│
├─ utils/
│   ├─ memory.py        ← ConversationMemory — history + auto-summarisation
│   └─ skill_registry.py← Auto-discovers tool modules in skills/
│
└─ skills/              ← One file per domain; each exports a `tools` list
    ├─ _template.py     ← Copy this to create a new skill
    ├─ user_management.py
    └─ order_management.py
```

## Quick start

```bash
# 1. Set up
cp .env.example .env        # add your OpenAI key
pip install -r requirements.txt

# 2. Seed the test database
python db/seed.py

# 3. Run the chatbot
python main.py
```

## How context management works

| Phase | What happens |
|-------|-------------|
| Every turn | User + assistant messages are appended to `full_history`. |
| Before each LLM call | `count_message_tokens()` checks total token usage. |
| If tokens > `SUMMARY_THRESHOLD` | Older messages are compressed into a `running_summary` by a secondary LLM call, then dropped from history. |
| Sent to model | `[system_prompt] + [running_summary (if any)] + [recent N turns]` |

Tune `SUMMARY_THRESHOLD_TOKENS` and `RECENT_TURNS_TO_KEEP` in
`utils/memory.py` to balance recall vs. token budget.

## Adding a new skill

1. Copy `skills/_template.py` → `skills/my_domain.py`
2. Write `@tool` functions that call `db.connection.execute_query` /
   `execute_write`.
3. List them in `tools = [...]` at the bottom.
4. Restart — the registry picks them up automatically.

## Swapping the chat interface

`main.py` is a plain CLI loop.  Replace it with any framework:

- **FastAPI** — expose `/chat` as a POST endpoint
- **Streamlit** — use `st.chat_input` / `st.chat_message`
- **WebSocket** — for streaming responses

The `agent.py` → `build_agent()` function returns a framework-agnostic
`(AgentExecutor, ConversationMemory)` pair you can plug in anywhere.
