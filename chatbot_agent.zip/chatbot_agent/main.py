"""
main.py — Interactive chat loop (CLI).

Run with:
    python main.py
"""

from __future__ import annotations

import asyncio

from agent import build_agent


async def chat_loop() -> None:
    executor, memory = build_agent()

    print("\n💬  Chatbot ready — type 'quit' to exit.\n")

    while True:
        user_input = input("You: ").strip()
        if not user_input:
            continue
        if user_input.lower() in {"quit", "exit", "q"}:
            print("Goodbye!")
            break

        # 1. Record the user message in memory
        memory.add_user_message(user_input)

        # 2. Build the context window (summarises if needed)
        chat_history = await memory.get_context_messages()

        # 3. Invoke the agent
        result = await executor.ainvoke(
            {
                "input": user_input,
                "chat_history": chat_history,
            }
        )

        assistant_reply = result["output"]

        # 4. Record the assistant's reply in memory
        memory.add_ai_message(assistant_reply)

        print(f"\nAssistant: {assistant_reply}\n")


if __name__ == "__main__":
    asyncio.run(chat_loop())
