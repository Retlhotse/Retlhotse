"""Landing page — overview and navigation."""

import streamlit as st

st.set_page_config(
    page_title="LLM Agent Eval",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.title("LLM Agent Evaluation Framework")
st.caption("Evaluate enterprise LLM agents across context-window and tool-count tiers.")

st.markdown("""
## How It Works

This tool evaluates how well any LLM performs in three enterprise agent archetypes:

| Agent Type | What's Measured | Tiers |
|------------|-----------------|-------|
| **Chatbot** | Answer relevancy at increasing context sizes | 5k / 10k / 30k / 50k tokens |
| **RAG** | Faithfulness + answer relevancy at increasing context sizes | 5k / 10k / 30k / 50k tokens |
| **Tool-Calling** | Tool-selection accuracy at increasing tool-catalog sizes | 5 / 15 / 30 / 50 tools |

Scoring uses [deepeval](https://deepeval.com) metrics. Results are persisted to a local
SQLite database for comparison across models.

---

## Getting Started

1. **Onboard a Model** — upload a JSON config with your LLM's connection details.
2. **Run Evaluation** — select a model, choose an agent type, and watch results appear tier by tier.
3. **Compare Results** — filter stored runs and compare two models side-by-side.

Use the sidebar to navigate between pages.
""")

st.info(
    "No authentication is required. This tool is designed for trusted internal environments.",
    icon="ℹ️",
)
