"""Onboard Model — upload JSON config and register an LLM for evaluation."""

import json
import sys
from pathlib import Path

import streamlit as st

PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

SCHEMA_PATH = (
    PROJECT_ROOT / "specs" / "001-llm-agent-eval" / "contracts" / "model-config.schema.json"
)

from agenteval.config.model_config import ConfigValidationError, DuplicateModelError
from agenteval.runner import list_models, register_model

st.set_page_config(page_title="Onboard Model", layout="wide")
st.title("Onboard a Model")
st.caption("Register a new LLM by uploading its JSON connection configuration.")

# ── Upload form ───────────────────────────────────────────────────────────────
with st.expander("📋 Config format", expanded=False):
    st.markdown(
        "**Credentials — supply exactly one of the following:**\n"
        "- `api_key_env` *(preferred)* — name of an environment variable holding the key; "
        "the value is read at run time and never stored.\n"
        "- `api_key` *(on-premises escape hatch)* — the raw token inline. "
        "⚠️ Stored in the local SQLite database in plaintext — protect the DB file and never commit it."
    )

    st.markdown("**Example — cloud model (env-var credential):**")
    st.code(
        json.dumps(
            {
                "name": "my-cloud-model",
                "provider": "anthropic",
                "model_identifier": "claude-opus-4-8",
                "credentials": {"api_key_env": "ANTHROPIC_API_KEY"},
                "max_context_tokens": 200000,
                "request_params": {"max_tokens": 1024},
            },
            indent=2,
        ),
        language="json",
    )

    st.markdown("**Example — on-premises model (inline token + endpoint):**")
    st.code(
        json.dumps(
            {
                "name": "my-onprem-model",
                "provider": "custom",
                "model_identifier": "llama3-70b",
                "endpoint": "http://10.0.1.42:8000/v1",
                "credentials": {"api_key": "sk-internal-token-xyz"},
                "max_context_tokens": 32000,
            },
            indent=2,
        ),
        language="json",
    )

    st.caption(
        "Supported providers: `anthropic`, `openai`, `azure_openai`, `google`, `custom`. "
        "`custom` and `azure_openai` require an `endpoint` field."
    )

    st.markdown("**Full JSON Schema contract:**")
    try:
        schema_text = SCHEMA_PATH.read_text(encoding="utf-8")
        st.code(schema_text, language="json")
    except OSError as exc:
        st.caption(f"Schema file unavailable ({exc}).")

uploaded = st.file_uploader("Upload model config JSON", type=["json"])

if uploaded:
    try:
        config_data = json.loads(uploaded.read().decode("utf-8"))
    except json.JSONDecodeError as exc:
        st.error(f"Invalid JSON file. What failed: {exc}. What to do: fix the JSON syntax.")
        config_data = None

    if config_data:
        with st.expander("Preview config", expanded=True):
            safe_preview = {k: v for k, v in config_data.items() if k != "credentials"}
            creds = config_data.get("credentials", {}) or {}
            safe_creds: dict[str, str] = {}
            if creds.get("api_key_env"):
                safe_creds["api_key_env"] = creds["api_key_env"]
            if creds.get("api_key"):
                # Never echo the raw token — mask it (constitution: Security & Credential Handling).
                safe_creds["api_key"] = "•••••• (inline, masked)"
            safe_preview["credentials"] = safe_creds or {"<missing>": "no credential provided"}
            st.json(safe_preview)

        if st.button("Register Model", type="primary"):
            try:
                target = register_model(config_data)
                st.success(f"✅ Model **{target.name}** registered successfully (id={target.id}).")
                st.rerun()
            except ConfigValidationError as exc:
                st.error(str(exc))
            except DuplicateModelError as exc:
                st.warning(str(exc))
            except Exception as exc:
                st.error(f"Unexpected error: {exc}")

# ── Registered models table ───────────────────────────────────────────────────
st.divider()
st.subheader("Registered Models")

try:
    targets = list_models()
except Exception as exc:
    st.error(f"Could not load models: {exc}")
    targets = []

if targets:
    rows = [
        {
            "ID": t.id,
            "Name": t.name,
            "Provider": t.provider,
            "Model Identifier": t.model_identifier,
            "Max Context Tokens": t.max_context_tokens if hasattr(t, "max_context_tokens") else "—",
            "Registered": t.created_at.strftime("%Y-%m-%d %H:%M UTC"),
        }
        for t in targets
    ]
    st.dataframe(rows, use_container_width=True)
else:
    st.info("No models registered yet. Upload a config above to get started.")
