"""Run Evaluation — select a model and agent type, run the suite, see live results."""

import json
import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "src"))

from agenteval.db.repository import ResultFilter
from agenteval.runner import list_datasets, list_models, load_dataset, run_evaluation

st.set_page_config(page_title="Run Evaluation", layout="wide")
st.title("Run Evaluation")
st.caption("Evaluate an onboarded model across all tiers for a chosen agent type.")

AGENT_TYPES = ["chatbot", "rag", "tool_calling"]
DATASET_PATHS = {
    "chatbot": Path(__file__).parents[2] / "datasets" / "chatbot" / "v1.0.json",
    "rag": Path(__file__).parents[2] / "datasets" / "rag" / "v1.0.json",
    "tool_calling": Path(__file__).parents[2] / "datasets" / "tool_calling" / "v1.0.json",
}

# ── Configuration ─────────────────────────────────────────────────────────────
col1, col2, col3 = st.columns(3)

with col1:
    try:
        targets = list_models()
    except Exception:
        targets = []
    model_options = {t.name: t.id for t in targets}
    selected_model_name = st.selectbox(
        "Model", options=list(model_options.keys()) or ["(no models registered)"]
    )

with col2:
    selected_agent = st.selectbox("Agent Type", options=AGENT_TYPES)

with col3:
    st.write("")
    st.write("")
    run_button = st.button("▶ Start Evaluation", type="primary", disabled=not model_options)

# ── Tier info ─────────────────────────────────────────────────────────────────
tier_info = {
    "chatbot": "Context tiers: 5k / 10k / 30k / 50k tokens | Metric: Answer Relevancy",
    "rag": "Context tiers: 5k / 10k / 30k / 50k tokens | Metrics: Faithfulness + Answer Relevancy",
    "tool_calling": "Tool-count tiers: 5 / 15 / 30 / 50 tools | Metric: Tool Correctness",
}
st.info(tier_info.get(selected_agent, ""))

# ── Live results ───────────────────────────────────────────────────────────────
if run_button and model_options:
    target_id = model_options[selected_model_name]

    # Auto-register the built-in dataset
    dataset_path = DATASET_PATHS.get(selected_agent)
    if dataset_path and dataset_path.exists():
        try:
            dataset = load_dataset(dataset_path)
        except Exception as exc:
            st.error(f"Failed to load dataset: {exc}")
            st.stop()
    else:
        st.error(f"Dataset not found at {dataset_path}. What to do: ensure datasets/ directory exists.")
        st.stop()

    st.subheader("Results")
    results_rows: list[dict] = []
    results_placeholder = st.empty()

    progress = st.progress(0)
    TIER_COUNTS = {"chatbot": 4, "rag": 4, "tool_calling": 4}
    total = TIER_COUNTS[selected_agent]

    try:
        for i, tier_result in enumerate(run_evaluation(target_id, selected_agent, dataset.id)):
            metrics = json.loads(tier_result.metrics_json) if tier_result.metrics_json else {}
            tier_label = (
                f"{tier_result.tier_value:,} tokens"
                if tier_result.tier_kind == "context_tokens"
                else f"{tier_result.tier_value} tools"
            )
            row = {
                "Tier": tier_label,
                "Status": tier_result.status.upper(),
                "Skip Reason": tier_result.skip_reason or "",
            }
            for k, v in metrics.items():
                row[k.replace("_", " ").title()] = f"{v:.2%}"
            results_rows.append(row)
            results_placeholder.dataframe(results_rows, use_container_width=True)
            progress.progress((i + 1) / total)

        st.success("✅ Evaluation complete! View results in the **Results / Compare** page.")
    except Exception as exc:
        st.error(f"Evaluation failed: {exc}")
