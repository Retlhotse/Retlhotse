"""Results / Compare — filter stored runs and compare two models side-by-side."""

import json
import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "src"))

from agenteval.db.repository import IncomparableRunsError, ResultFilter
from agenteval.runner import compare_runs, get_results, list_models

st.set_page_config(page_title="Results / Compare", layout="wide")
st.title("Results & Comparison")
st.caption("Filter stored evaluation runs and compare two models side-by-side.")

# ── Filters ───────────────────────────────────────────────────────────────────
st.subheader("Filter Runs")
fcol1, fcol2, fcol3 = st.columns(3)

with fcol1:
    try:
        targets = list_models()
    except Exception:
        targets = []
    model_filter_options = {"All Models": None} | {t.name: t.id for t in targets}
    selected_model_filter = st.selectbox("Model", options=list(model_filter_options.keys()))

with fcol2:
    agent_filter = st.selectbox(
        "Agent Type", options=["All", "chatbot", "rag", "tool_calling"]
    )

with fcol3:
    st.write("")
    st.write("")
    refresh = st.button("🔄 Refresh")

filters = ResultFilter(
    llm_target_id=model_filter_options.get(selected_model_filter),
    agent_type=None if agent_filter == "All" else agent_filter,
)

try:
    runs = get_results(filters)
except Exception as exc:
    st.error(f"Could not load results: {exc}")
    runs = []

# ── Runs table ────────────────────────────────────────────────────────────────
st.subheader(f"Stored Runs ({len(runs)})")

if not runs:
    st.info("No runs match the selected filters. Run an evaluation first.")
    st.stop()

target_names = {t.id: t.name for t in targets}

rows = []
for r in runs:
    avg_score: float | None = None
    if r.tier_results:
        scores = []
        for tr in r.tier_results:
            if tr.metrics_json:
                m = json.loads(tr.metrics_json)
                scores.extend(m.values())
        avg_score = round(sum(scores) / len(scores), 4) if scores else None

    rows.append(
        {
            "Run ID": r.id,
            "Model": target_names.get(r.llm_target_id, str(r.llm_target_id)),
            "Agent Type": r.agent_type,
            "Status": r.status,
            "Tiers Scored": sum(1 for t in r.tier_results if t.status == "scored"),
            "Avg Score": f"{avg_score:.2%}" if avg_score is not None else "—",
            "Started": r.started_at.strftime("%Y-%m-%d %H:%M UTC"),
        }
    )

st.dataframe(rows, use_container_width=True)

# ── JSON export ────────────────────────────────────────────────────────────────
if st.button("⬇ Export results as JSON"):
    export = []
    for r in runs:
        export.append(
            {
                "run_id": r.id,
                "model": target_names.get(r.llm_target_id),
                "agent_type": r.agent_type,
                "status": r.status,
                "started_at": r.started_at.isoformat(),
                "tiers": [
                    {
                        "tier_kind": t.tier_kind,
                        "tier_value": t.tier_value,
                        "status": t.status,
                        "metrics": json.loads(t.metrics_json) if t.metrics_json else None,
                        "skip_reason": t.skip_reason,
                    }
                    for t in r.tier_results
                ],
            }
        )
    st.download_button(
        "Download JSON",
        data=json.dumps(export, indent=2, default=str),
        file_name="evaluation_results.json",
        mime="application/json",
    )

# ── Side-by-side comparison ───────────────────────────────────────────────────
st.divider()
st.subheader("Side-by-Side Comparison")
st.caption("Select two runs with the same agent type to compare them tier by tier.")

run_id_options = {f"Run {r.id} — {target_names.get(r.llm_target_id, '?')} ({r.agent_type})": r.id for r in runs}

ccol1, ccol2 = st.columns(2)
with ccol1:
    run_a_label = st.selectbox("Run A", options=list(run_id_options.keys()), key="run_a")
with ccol2:
    run_b_label = st.selectbox("Run B", options=list(run_id_options.keys()), key="run_b")

if st.button("Compare", type="primary"):
    run_a_id = run_id_options[run_a_label]
    run_b_id = run_id_options[run_b_label]

    if run_a_id == run_b_id:
        st.warning("Select two different runs to compare.")
    else:
        try:
            view = compare_runs(run_a_id, run_b_id)
            comp_rows = []
            for entry in view.tiers:
                tier_label = (
                    f"{entry['tier_value']:,} tokens"
                    if entry["tier_kind"] == "context_tokens"
                    else f"{entry['tier_value']} tools"
                )
                tr_a = entry["run_a"]
                tr_b = entry["run_b"]

                def fmt(tr):
                    if tr is None:
                        return "—"
                    if tr.status == "skipped":
                        return f"SKIPPED ({tr.skip_reason})"
                    if not tr.metrics_json:
                        return "failed"
                    m = json.loads(tr.metrics_json)
                    return " | ".join(f"{k}: {v:.2%}" for k, v in m.items())

                comp_rows.append(
                    {
                        "Tier": tier_label,
                        f"Run {run_a_id} — {run_a_label.split('—')[1].strip()}": fmt(tr_a),
                        f"Run {run_b_id} — {run_b_label.split('—')[1].strip()}": fmt(tr_b),
                    }
                )
            st.dataframe(comp_rows, use_container_width=True)
        except IncomparableRunsError as exc:
            st.error(str(exc))
        except Exception as exc:
            st.error(f"Comparison failed: {exc}")
