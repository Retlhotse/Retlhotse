# Implementation Plan: LLM Agent Evaluation Framework

**Branch**: `001-llm-agent-eval` | **Date**: 2026-06-16 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/001-llm-agent-eval/spec.md`

## Summary

Build a Streamlit web application that evaluates onboarded LLMs across three agent archetypes
(Chatbot, RAG, Tool-Calling) using the deepeval framework. Chatbot and RAG agents are tested
at four context-window tiers (5k / 10k / 30k / 50k tokens); the Tool-Calling agent is tested
at four tool-count tiers (5 / 15 / 30 / 50 tools). Models are registered through an onboarding
page that accepts a JSON connection configuration. An evaluation page runs the suite and shows
each test's result as it completes. All runs, tier results, and manifests are persisted to a
local SQLite database for later retrieval and comparison. No authentication is required.

## Technical Context

**Language/Version**: Python 3.11+

**Primary Dependencies**: Streamlit (UI), deepeval (evaluation metrics & test runner),
SQLite via the Python standard-library `sqlite3` module, SQLAlchemy (ORM / schema management),
Pydantic (config validation), tiktoken (token counting for tier construction)

**Storage**: SQLite database file (`data/evaluations.db`) at repository root

**Testing**: pytest (unit + integration); deepeval's own assertion harness for metric-level tests

**Target Platform**: Local / internal Linux or Windows host running `streamlit run`

**Project Type**: Single-project web application (Streamlit multipage app + Python service layer)

**Performance Goals**: Full three-agent, four-tier run for one LLM completes in < 30 min
wall-clock excluding model API latency (SC-001); stored results queryable within 5 s of run
completion (SC-002); batch scoring of cached responses ≥ 500 prompts/min on one core
(constitution IV)

**Constraints**: ≤ 512 MB RSS per evaluation process for a 100-prompt benchmark (constitution
IV); no authentication; offline-capable except for outbound LLM API calls; judge-model calls
use temperature 0 / fixed seed to bound non-determinism

**Scale/Scope**: Single-tenant internal tool; tens of onboarded models; 3 agent types ×
4 tiers; ~5 dashboard pages; low-thousands of stored tier-result rows

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

Verify compliance with all five constitution principles before proceeding:

- [x] **I. Code Quality** — type annotations on all public functions; ruff + black configured;
  service / data / UI layers separated by responsibility
- [x] **II. Test-First** — pytest suite written before implementation; deterministic scorers
  covered by parametric tests; provider adapters covered by integration tests using recorded
  fixtures (no live API in CI)
- [x] **III. UX Consistency** — Streamlit pages follow a documented layout contract; results
  exposed in both human-readable tables and machine-readable JSON export; error messages state
  what/why/next
- [x] **IV. Performance Standards** — targets stated in Technical Context above; a benchmark
  test guards the cached-scoring throughput path
- [x] **V. Evaluation Integrity** — every run emits a manifest (model id, prompt hashes, scorer
  versions, timestamps, seeds); benchmark datasets versioned in source control; see Complexity
  Tracking for the LLM-as-judge non-determinism justification

**Re-check after Phase 1 design**: PASS — data-model.md defines the `run_manifest` and
`dataset_version` fields; contracts define deterministic tool-correctness scoring and
documented-variance handling for judge-based metrics. No new violations introduced.

## Project Structure

### Documentation (this feature)

```text
specs/001-llm-agent-eval/
├── plan.md              # This file
├── research.md          # Phase 0 output
├── data-model.md        # Phase 1 output
├── quickstart.md        # Phase 1 output
├── contracts/           # Phase 1 output
│   ├── model-config.schema.json   # Onboarding JSON config contract
│   ├── evaluation-service.md      # Internal service interface contract
│   └── database-schema.md         # Persisted entity contract
└── tasks.md             # Phase 2 output (/speckit-tasks — NOT created here)
```

### Source Code (repository root)

```text
src/
├── agenteval/
│   ├── __init__.py
│   ├── config/
│   │   ├── model_config.py        # Pydantic models for onboarding JSON
│   │   └── tiers.py               # Token / tool tier definitions
│   ├── models/                    # SQLAlchemy ORM entities
│   │   ├── evaluation_run.py
│   │   ├── tier_result.py
│   │   ├── llm_target.py
│   │   └── benchmark_dataset.py
│   ├── db/
│   │   ├── engine.py              # SQLite engine + session factory
│   │   └── repository.py          # Query/persist API (FR-005, FR-006)
│   ├── providers/
│   │   ├── base.py                # DeepEvalBaseLLM wrapper interface
│   │   └── factory.py             # Build a provider client from onboarding config
│   ├── agents/
│   │   ├── chatbot.py             # Chatbot evaluation logic (context tiers)
│   │   ├── rag.py                 # RAG evaluation logic (context tiers)
│   │   └── tool_calling.py        # Tool-calling evaluation logic (tool tiers)
│   ├── scoring/
│   │   ├── metrics.py             # deepeval metric configuration per agent
│   │   └── manifest.py            # Run manifest builder (constitution V)
│   └── runner.py                  # Orchestrates a run, persists per-tier (FR-010)

app/                               # Streamlit multipage app
├── Home.py                        # Landing / overview
└── pages/
    ├── 1_Onboard_Model.py         # Upload + validate model JSON config
    ├── 2_Run_Evaluation.py        # Trigger run, live per-test results
    └── 3_Results_Compare.py       # Query + side-by-side comparison

datasets/                          # Versioned benchmark inputs (constitution V)
├── chatbot/
├── rag/
└── tool_calling/

tests/
├── unit/                          # Scorers, config validation, tier construction
├── integration/                   # Provider adapters (recorded fixtures), runner end-to-end
└── benchmark/                     # Performance guards (constitution IV)

data/                              # SQLite db file (gitignored)
```

**Structure Decision**: Single-project web application. The Streamlit `app/` layer is a thin
presentation shell that calls into the reusable `src/agenteval/` service package — this keeps
UI separate from evaluation logic (constitution I) and lets the runner/scoring layers be unit
tested without Streamlit. deepeval drives the metric scoring; SQLAlchemy over SQLite provides
the persistence and query layer.

## Complexity Tracking

> Filled because Constitution Principle V has a tension requiring justification.

| Violation | Why Needed | Simpler Alternative Rejected Because |
|-----------|------------|-------------------------------------|
| Judge-based (non-deterministic) metrics used as primary scores for Chatbot & RAG | deepeval's faithfulness / answer-relevancy are LLM-as-judge; no deterministic metric captures open-ended answer quality | Pure deterministic metrics (ROUGE/exact-match) cannot judge semantic faithfulness or relevance, defeating the purpose of RAG/chatbot evaluation. Mitigation: judge model pinned at temperature 0 with a fixed seed, judge model id + version recorded in the manifest, variance treated as a documented point-in-time snapshot (spec edge case), and results never presented as exact-reproducible. Tool-Correctness remains fully deterministic. |
