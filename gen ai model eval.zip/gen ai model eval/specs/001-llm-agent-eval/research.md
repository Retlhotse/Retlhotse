# Research: LLM Agent Evaluation Framework

**Feature**: 001-llm-agent-eval | **Date**: 2026-06-16

This document records the technology decisions that resolve the Technical Context for the
plan. The three spec-level clarifications (LLM scope, scoring method, UI) were resolved by the
user's planning input and are reflected in spec.md.

---

## Decision 1: Evaluation framework — deepeval

**Decision**: Use deepeval (Confident AI) as the evaluation engine for all three agent types.

**Rationale**:
- Ships ready-made, agent-relevant metrics: `FaithfulnessMetric` and `AnswerRelevancyMetric`
  for RAG, `AnswerRelevancyMetric` / task-completion for chatbot, and `ToolCorrectnessMetric`
  for tool-calling.
- `ToolCorrectnessMetric` is **deterministic** at its core (`correctly used tools / total
  tools called`), satisfying constitution Principle V for the tool-calling agent.
- Provider-agnostic: any model can be wrapped as a `DeepEvalBaseLLM` subclass, which matches
  the JSON-onboarding requirement (FR-008).
- Integrates with pytest, supporting the Test-First principle.

**Alternatives considered**:
- *RAGAS* — strong for RAG but weaker tool-calling coverage; would need a second framework.
- *Hand-rolled metrics* — rejected; reinvents well-tested metric logic and raises maintenance.
- *promptfoo* — YAML/JS-centric; less natural fit for a Python/Streamlit service layer.

**Key constraint surfaced**: Faithfulness and Answer Relevancy are LLM-as-judge metrics and
therefore non-deterministic. Mitigation (recorded in plan Complexity Tracking): pin the judge
model at temperature 0 with a fixed seed, record judge model id/version in the run manifest,
and treat scores as point-in-time snapshots.

**Source**: [DeepEval metrics intro](https://deepeval.com/docs/metrics-introduction),
[Faithfulness](https://deepeval.com/docs/metrics-faithfulness),
[Answer Relevancy](https://deepeval.com/docs/metrics-answer-relevancy),
[Tool Correctness](https://deepeval.com/docs/metrics-tool-correctness)

---

## Decision 2: Model onboarding — JSON config wrapped as DeepEvalBaseLLM

**Decision**: Onboard each model via an uploaded JSON file validated by a Pydantic schema, then
construct a `DeepEvalBaseLLM` wrapper through a provider factory.

**Rationale**:
- Decouples the framework from any single provider; new models are added by config, no code
  change (FR-008).
- Pydantic gives validation with clear error messages (constitution Principle III — error
  messages state what/why/next).
- The factory pattern isolates provider SDK specifics behind one interface, keeping the runner
  provider-agnostic and unit-testable with fixtures.

**Alternatives considered**:
- *Environment variables only* — rejected; cannot register multiple models per environment and
  is not user-friendly on a web page.
- *Hardcoded provider list* — rejected; violates the provider-agnostic requirement.

**Config contract**: defined in `contracts/model-config.schema.json`.

---

## Decision 3: Persistence — SQLite via SQLAlchemy

**Decision**: SQLite file database accessed through SQLAlchemy ORM, with a thin repository layer.

**Rationale**:
- SQLite is zero-config and file-based — ideal for a single-tenant internal tool (no server to
  run, satisfies "no auth / trusted environment" assumption).
- SQLAlchemy provides typed models and schema migrations as the data model evolves.
- A repository layer centralises the persist-per-tier behaviour (FR-005, FR-010) and the
  filtered queries (FR-006), and is independently unit-testable.

**Alternatives considered**:
- *Raw `sqlite3`* — rejected; manual SQL increases error surface and weakens typing.
- *Postgres* — rejected for v1; needs a server and multi-tenant features that are out of scope.
- *Flat JSON/CSV files* — rejected; poor query/filter support (FR-006) and concurrency risk.

---

## Decision 4: UI — Streamlit multipage app

**Decision**: Streamlit multipage app with a thin presentation layer over `src/agenteval/`.

**Rationale**:
- Fast to build a dashboard with file upload (onboarding) and live-updating result tables.
- Streamlit's rerun model supports showing each test result as it completes (User Story on the
  evaluation page) via incremental writes to a results container.
- Keeping evaluation logic in `src/agenteval/` (not in page scripts) preserves separation of
  concerns and testability (constitution Principle I & II).

**Alternatives considered**:
- *FastAPI + React* — rejected; far more scope than needed for an internal eval tool.
- *Pure CLI* — rejected; user explicitly requested onboarding and live-results pages.

**Live-results note**: long runs will be executed tier-by-tier so the page can render each
completed test incrementally and the runner can persist partial progress (FR-010).

---

## Decision 5: Context-tier construction — tiktoken token counting

**Decision**: Build the 5k/10k/30k/50k token payloads by measuring token counts with tiktoken
and assembling fixtures to hit each target tier within a tolerance.

**Rationale**:
- Tiers are defined by token count, so a real tokenizer is required to construct reproducible
  payloads.
- Recording the exact token count per tier supports the manifest/auditability requirement.

**Edge handling**: if an assembled payload exceeds a target model's maximum context length, the
runner skips that tier and records the skip reason (spec edge case, SC-006).

**Alternatives considered**:
- *Character/word heuristics* — rejected; inaccurate, breaks tier reproducibility.

---

## Resolved Unknowns Summary

| Technical Context item | Resolution |
|------------------------|------------|
| Language/Version | Python 3.11+ |
| Evaluation framework | deepeval |
| Storage | SQLite + SQLAlchemy |
| UI | Streamlit multipage |
| Provider strategy | JSON config → Pydantic → DeepEvalBaseLLM factory |
| Token tier construction | tiktoken |
| Auth | None (trusted internal environment) |

No NEEDS CLARIFICATION markers remain.
