# Data Model: LLM Agent Evaluation Framework

**Feature**: 001-llm-agent-eval | **Date**: 2026-06-16

Entities are persisted in SQLite via SQLAlchemy. All timestamps are stored in UTC ISO-8601.

---

## Entity: LLMTarget

The model under evaluation, registered through onboarding.

| Field | Type | Constraints |
|-------|------|-------------|
| id | int | PK, autoincrement |
| name | str | required, unique — display name from config |
| provider | str | required — e.g. `anthropic`, `openai`, `custom` |
| model_identifier | str | required — provider model id (e.g. `claude-opus-4-8`) |
| version_snapshot | str | optional — version or snapshot date of the model |
| config_json | str (JSON) | required — full onboarding config (credentials reference, not raw secret) |
| created_at | datetime | required, default now |

**Validation**:
- `config_json` MUST validate against `contracts/model-config.schema.json`.
- Raw secret values MUST NOT be stored; only a credentials reference (e.g. env var name).

**Relationships**: one LLMTarget → many EvaluationRun.

---

## Entity: BenchmarkDataset

A versioned set of inputs for one agent type. Source-controlled under `datasets/`.

| Field | Type | Constraints |
|-------|------|-------------|
| id | int | PK |
| agent_type | enum | required — `chatbot` \| `rag` \| `tool_calling` |
| name | str | required |
| version | str | required — semantic or date version (constitution V) |
| content_hash | str | required — hash of the dataset content for audit |
| source_path | str | required — path under `datasets/` |

**Validation**:
- `(agent_type, name, version)` MUST be unique.
- `content_hash` MUST match the referenced file at run time; mismatch fails the run.

**Relationships**: one BenchmarkDataset → many EvaluationRun.

---

## Entity: EvaluationRun

One execution of one agent type against one LLMTarget.

| Field | Type | Constraints |
|-------|------|-------------|
| id | int | PK |
| llm_target_id | int | FK → LLMTarget, required |
| dataset_id | int | FK → BenchmarkDataset, required |
| agent_type | enum | required — `chatbot` \| `rag` \| `tool_calling` |
| status | enum | `running` \| `completed` \| `partial` \| `failed`, default `running` |
| run_manifest | str (JSON) | required — see Run Manifest below (constitution V) |
| started_at | datetime | required, default now |
| completed_at | datetime | nullable — set when run ends |

**State transitions**:
- `running` → `completed` (all tiers scored)
- `running` → `partial` (some tiers saved, a later tier failed/skipped — FR-010)
- `running` → `failed` (no tier completed)

**Relationships**: one EvaluationRun → many TierResult.

### Run Manifest (JSON shape, constitution Principle V)

```json
{
  "llm_target": { "name": "...", "provider": "...", "model_identifier": "...", "version_snapshot": "..." },
  "agent_type": "rag",
  "dataset": { "name": "...", "version": "...", "content_hash": "..." },
  "judge_model": { "model_identifier": "...", "temperature": 0, "seed": 12345 },
  "scorer_versions": { "deepeval": "x.y.z", "metrics": ["FaithfulnessMetric", "AnswerRelevancyMetric"] },
  "tiers_requested": [5000, 10000, 30000, 50000],
  "started_at": "2026-06-16T10:00:00Z"
}
```

---

## Entity: TierResult

The score(s) for one tier within a run. Persisted as soon as the tier completes (FR-005, FR-010).

| Field | Type | Constraints |
|-------|------|-------------|
| id | int | PK |
| run_id | int | FK → EvaluationRun, required |
| tier_kind | enum | required — `context_tokens` \| `tool_count` |
| tier_value | int | required — e.g. 5000, 10000 … or 5, 15, 30, 50 |
| status | enum | `scored` \| `skipped` \| `failed`, required |
| skip_reason | str | nullable — required when status = `skipped` (SC-006) |
| metrics_json | str (JSON) | nullable — metric name → score map; null when skipped/failed |
| measured_tokens | int | nullable — actual token count of payload (context tiers) |
| created_at | datetime | required, default now |

**Validation**:
- `(run_id, tier_kind, tier_value)` MUST be unique within a run.
- If `status = skipped`, `skip_reason` MUST be present.
- If `status = scored`, `metrics_json` MUST contain at least one metric score.
- `tier_kind` MUST be `context_tokens` for chatbot/rag and `tool_count` for tool_calling.

### metrics_json shape (examples)

RAG / chatbot:
```json
{ "faithfulness": 0.92, "answer_relevancy": 0.88 }
```

Tool-calling:
```json
{ "tool_correctness": 0.80, "parameter_correctness": 0.75 }
```

---

## Relationships Diagram (textual)

```
LLMTarget 1───* EvaluationRun *───1 BenchmarkDataset
                    │
                    1
                    │
                    *
                TierResult
```

## Indexing & Query Support (FR-006)

- Index `EvaluationRun(llm_target_id, agent_type, started_at)` for filtered retrieval.
- Index `TierResult(run_id)` for per-run aggregation.
- Comparison queries (FR-009) join two runs sharing `(agent_type, dataset_id)` and align
  TierResults by `(tier_kind, tier_value)`.
