# Quickstart: LLM Agent Evaluation Framework

**Feature**: 001-llm-agent-eval

End-to-end validation guide. Proves the framework can onboard a model, run an evaluation across
tiers, show live results, and persist them for later comparison.

## Prerequisites

- Python 3.11+
- An API key for at least one LLM provider, exported as an environment variable
  (e.g. `ANTHROPIC_API_KEY`)
- Dependencies installed (see plan.md for the dependency list):
  ```bash
  pip install -r requirements.txt
  ```

## Setup

1. Initialise the SQLite database (creates `data/evaluations.db` and tables from
   `contracts/database-schema.md`):
   ```bash
   python -m agenteval.db.engine --init
   ```
2. Confirm the versioned benchmark datasets exist under `datasets/chatbot/`, `datasets/rag/`,
   and `datasets/tool_calling/`.
3. Launch the dashboard:
   ```bash
   streamlit run app/Home.py
   ```

## Scenario 1 — Onboard a model (User Story: onboarding)

1. Open the **Onboard Model** page.
2. Upload a JSON config conforming to `contracts/model-config.schema.json`, e.g.:
   ```json
   {
     "name": "claude-opus-4-8-eval",
     "provider": "anthropic",
     "model_identifier": "claude-opus-4-8",
     "credentials": { "api_key_env": "ANTHROPIC_API_KEY" },
     "max_context_tokens": 200000
   }
   ```
3. **Expected**: success message; the model appears in the onboarded-models list.
4. **Negative check**: upload a config missing `model_identifier` → an error names the missing
   field (what/why/next).

## Scenario 2 — Run a chatbot evaluation with live results (User Story 1, P1)

1. Open the **Run Evaluation** page.
2. Select the onboarded model, agent type **Chatbot**, and the chatbot dataset.
3. Start the run.
4. **Expected**: each tier (5k → 10k → 30k → 50k tokens) appears as it completes, each showing
   its metric scores (e.g. answer_relevancy). Results stream in rather than all at the end.
5. **Expected on completion**: run status is `completed`; four TierResults are visible.

## Scenario 3 — Tool-calling evaluation (User Story 2, P2)

1. On **Run Evaluation**, select agent type **Tool-Calling** and the tool-calling dataset.
2. Start the run.
3. **Expected**: tiers 5 → 15 → 30 → 50 tools each report `tool_correctness` (a deterministic
   score) and `parameter_correctness`.

## Scenario 4 — Persistence and comparison (User Story 4, P4)

1. Run an evaluation for a second model (repeat Scenario 2 with a different onboarded model).
2. Open the **Results / Compare** page.
3. Filter by agent type **Chatbot**.
4. **Expected**: both runs are listed (persistence verified — FR-005).
5. Select both runs and request a comparison.
6. **Expected**: a side-by-side table aligns each token tier with both models' scores (FR-009).

## Scenario 5 — Tier skip handling (Edge case, SC-006)

1. Onboard a model whose `max_context_tokens` is below 50000 (e.g. 32000).
2. Run a chatbot evaluation.
3. **Expected**: the 50k tier is recorded as `skipped` with a reason ("payload exceeds model
   max context"), and the run status is `partial`. The 5k/10k/30k tiers still have scores.

## Acceptance roll-up

| Validated | Spec reference |
|-----------|----------------|
| Onboarding via JSON config | FR-008 |
| Chatbot tiers + live results | User Story 1, FR-002 |
| Tool-calling tiers | User Story 2, FR-003 |
| Persistence | FR-005, SC-002 |
| Comparison | FR-009, SC-004 |
| Skip handling | FR-010, SC-006 |
| Run manifest recorded | FR-007 (inspect `evaluation_run.run_manifest`) |
