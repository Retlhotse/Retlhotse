﻿---
description: "Task list for LLM Agent Evaluation Framework"
---

# Tasks: LLM Agent Evaluation Framework

**Input**: Design documents from `/specs/001-llm-agent-eval/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/, quickstart.md

**Tests**: Test tasks are INCLUDED and REQUIRED. Constitution Principle II (Test-First) is
NON-NEGOTIABLE â€” every implementation task in a story is preceded by failing tests for that story.

**Organization**: Tasks are grouped by user story. Stories are independently testable. The data
layer, onboarding, and provider/runner scaffolding are shared prerequisites (Foundational phase).

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: US1=Chatbot, US2=Tool-Calling, US3=RAG, US4=Storage/Comparison
- All paths are relative to repository root, matching the structure in `plan.md`

## Path Conventions

- Service package: `src/agenteval/`
- Streamlit UI: `app/` and `app/pages/`
- Versioned benchmark inputs: `datasets/`
- Tests: `tests/unit/`, `tests/integration/`, `tests/benchmark/`

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Project initialization and tooling

- [x] T001 Create project structure per plan.md: `src/agenteval/{config,models,db,providers,agents,scoring}`, `app/pages`, `datasets/{chatbot,rag,tool_calling}`, `tests/{unit,integration,benchmark}`, `data/` (each Python dir gets `__init__.py`)
- [x] T002 Create `requirements.txt` with streamlit, deepeval, sqlalchemy, pydantic, tiktoken, pytest, ruff, black and pin versions
- [x] T003 [P] Create `pyproject.toml` configuring ruff + black (line length, target py311) and pytest (testpaths, coverage â‰¥80% gate per constitution II)
- [x] T004 [P] Create `.gitignore` excluding `data/*.db`, `__pycache__`, `.venv`, and secrets
- [x] T005 [P] Create `README.md` stub with run instructions (`streamlit run app/Home.py`) referencing quickstart.md

**Checkpoint**: Project skeleton and tooling ready.

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Shared data layer, config validation, provider integration, and runner/UI scaffolding
that ALL user stories depend on.

**âš ï¸ CRITICAL**: No user story work can begin until this phase is complete.

### Data layer

- [x] T006 [P] Implement SQLAlchemy ORM entities in `src/agenteval/models/llm_target.py` and `src/agenteval/models/benchmark_dataset.py` per data-model.md
- [x] T007 [P] Implement SQLAlchemy ORM entities in `src/agenteval/models/evaluation_run.py` and `src/agenteval/models/tier_result.py` per data-model.md (status enums, FKs, unique constraints)
- [x] T008 Implement SQLite engine + session factory in `src/agenteval/db/engine.py` with `--init` CLI that creates tables per `contracts/database-schema.md` (indexes included)
- [x] T009 Write unit tests in `tests/unit/test_repository.py` for persist-per-tier, partial-run status, and filtered queries (MUST FAIL before T010)
- [x] T010 Implement repository layer in `src/agenteval/db/repository.py`: create run, persist single TierResult in its own transaction (FR-005, FR-010), and `get_results(filters)` (FR-006)

### Config & providers

- [x] T011 [P] Write unit tests in `tests/unit/test_model_config.py` validating the onboarding JSON against `contracts/model-config.schema.json` incl. provider-conditional `endpoint` rule (MUST FAIL before T012)
- [x] T012 [P] Implement Pydantic config models + schema validation in `src/agenteval/config/model_config.py` with what/why/next error messages (constitution III)
- [x] T013 [P] Implement tier definitions in `src/agenteval/config/tiers.py` (context: 5k/10k/30k/50k; tools: 5/15/30/50) per `contracts/evaluation-service.md`
- [x] T014 [P] Implement token-counting helper in `src/agenteval/config/tiers.py` (or `src/agenteval/scoring/`) using tiktoken to build/measure context payloads (research Decision 5)
- [x] T015 Implement provider base `DeepEvalBaseLLM` wrapper in `src/agenteval/providers/base.py` and factory in `src/agenteval/providers/factory.py` that builds a client from validated config (research Decision 2)
- [x] T016 [P] Write integration test in `tests/integration/test_provider_factory.py` using recorded fixtures (NO live API per constitution II) (MUST FAIL before T015 completion is verified)

### Onboarding (prerequisite for all agent runs)

- [x] T017 Implement `register_model(config)` service in `src/agenteval/runner.py` (or `src/agenteval/db/repository.py`) raising `ConfigValidationError`/`DuplicateModelError` per `contracts/evaluation-service.md`
- [x] T018 Implement onboarding Streamlit page `app/pages/1_Onboard_Model.py`: upload JSON, validate, persist LLMTarget, list onboarded models

### Manifest, scoring base, runner skeleton

- [x] T019 [P] Implement run-manifest builder in `src/agenteval/scoring/manifest.py` producing the JSON shape in data-model.md (model id, dataset hash, judge model temp 0 + seed, scorer versions) â€” constitution V
- [x] T020 [P] Implement scoring base in `src/agenteval/scoring/metrics.py`: per-agent deepeval metric configuration registry (research Decision 1)
- [x] T021 Implement runner skeleton in `src/agenteval/runner.py`: `run_evaluation()` iterates tiers, skips tiers exceeding `max_context_tokens` with reason (SC-006), persists each TierResult immediately, sets run status completed/partial/failed (FR-010), and yields each TierResult for live UI
- [x] T022 [P] Implement Streamlit shell `app/Home.py` with navigation and a documented page-layout contract (constitution III)

**Checkpoint**: Data layer, onboarding, provider factory, and runner scaffolding ready â€” user stories can now proceed.

---

## Phase 3: User Story 1 - Chatbot Context-Window Evaluation (Priority: P1) ðŸŽ¯ MVP

**Goal**: Evaluate a chatbot agent at 5k/10k/30k/50k token context tiers, showing each tier's
score live as it completes.

**Independent Test**: Onboard one model, run a chatbot evaluation against the chatbot dataset,
and confirm scores are produced (or tiers skipped) for all four token tiers (quickstart Scenario 2).

### Tests for User Story 1 âš ï¸ (write first, MUST FAIL)

- [x] T023 [P] [US1] Unit test in `tests/unit/test_chatbot_tiers.py` asserting context payloads are assembled to each target token tier within tolerance
- [x] T024 [P] [US1] Integration test in `tests/integration/test_chatbot_run.py` running a chatbot evaluation end-to-end with recorded model fixtures and asserting 4 persisted TierResults

### Implementation for User Story 1

- [x] T025 [P] [US1] Create versioned chatbot benchmark dataset under `datasets/chatbot/` (prompts + conversation histories) and register it as a BenchmarkDataset with content hash (constitution V)
- [x] T026 [US1] Implement chatbot agent logic in `src/agenteval/agents/chatbot.py`: build context-tier payloads, call model, return responses for scoring
- [x] T027 [US1] Configure chatbot metrics in `src/agenteval/scoring/metrics.py` (deepeval answer relevancy + task/instruction adherence) per spec SC-003
- [x] T028 [US1] Wire chatbot into `src/agenteval/runner.py` (context_tokens tier kind) so `run_evaluation` produces per-tier chatbot scores
- [x] T029 [US1] Implement `app/pages/2_Run_Evaluation.py` for chatbot: select model/dataset, start run, render each TierResult live as it streams in (User Story 1 acceptance)
- [x] T030 [US1] Run quickstart Scenario 2 to validate live results and completion status

**Checkpoint**: Chatbot evaluation fully functional and independently testable â€” MVP deliverable.

---

## Phase 4: User Story 2 - Tool-Calling Accuracy Evaluation (Priority: P2)

**Goal**: Evaluate a tool-calling agent at 5/15/30/50 tool-count tiers, reporting tool-selection
and parameter correctness.

**Independent Test**: Run a tool-calling evaluation against the tool-calling dataset and confirm
deterministic tool-correctness scores per tool-count tier (quickstart Scenario 3).

### Tests for User Story 2 âš ï¸ (write first, MUST FAIL)

- [x] T031 [P] [US2] Unit test in `tests/unit/test_tool_correctness.py` asserting deterministic scoring (correct tools / total called) for known tool-call sets
- [x] T032 [P] [US2] Integration test in `tests/integration/test_tool_calling_run.py` running tool-calling evaluation across the 4 tool-count tiers with fixtures

### Implementation for User Story 2

- [x] T033 [P] [US2] Create versioned tool-calling dataset under `datasets/tool_calling/` (tool catalogs at 5/15/30/50 tools + tasks with expected tools) and register as BenchmarkDataset
- [x] T034 [US2] Implement tool-calling agent logic in `src/agenteval/agents/tool_calling.py`: present N tools, capture `tools_called` vs `expected_tools`
- [x] T035 [US2] Configure tool-calling metrics in `src/agenteval/scoring/metrics.py` using deepeval `ToolCorrectnessMetric` (deterministic) + parameter correctness (research Decision 1)
- [x] T036 [US2] Wire tool-calling into `src/agenteval/runner.py` (tool_count tier kind)
- [x] T037 [US2] Extend `app/pages/2_Run_Evaluation.py` to support the tool-calling agent and its tool-count tiers
- [x] T038 [US2] Run quickstart Scenario 3 to validate per-tier tool-correctness reporting

**Checkpoint**: Chatbot AND tool-calling evaluations both work independently.

---

## Phase 5: User Story 3 - RAG Agent Evaluation (Priority: P3)

**Goal**: Evaluate a RAG agent at 5k/10k/30k/50k token context tiers, reporting faithfulness and
relevance.

**Independent Test**: Run a RAG evaluation against the knowledge corpus + question set and confirm
faithfulness/relevance scores for all four context tiers (quickstart, spec US3).

### Tests for User Story 3 âš ï¸ (write first, MUST FAIL)

- [x] T039 [P] [US3] Unit test in `tests/unit/test_rag_tiers.py` asserting retrieved-context payloads hit each token tier within tolerance
- [x] T040 [P] [US3] Integration test in `tests/integration/test_rag_run.py` running a RAG evaluation end-to-end with fixtures and asserting persisted TierResults with faithfulness + relevance

### Implementation for User Story 3

- [x] T041 [P] [US3] Create versioned RAG dataset under `datasets/rag/` (knowledge corpus + questions + golden context) and register as BenchmarkDataset
- [x] T042 [US3] Implement RAG agent logic in `src/agenteval/agents/rag.py`: assemble retrieved-context tiers, call model with question + context
- [x] T043 [US3] Configure RAG metrics in `src/agenteval/scoring/metrics.py` (deepeval `FaithfulnessMetric` + `AnswerRelevancyMetric`, judge pinned temp 0 + seed per Complexity Tracking)
- [x] T044 [US3] Wire RAG into `src/agenteval/runner.py` (context_tokens tier kind)
- [x] T045 [US3] Extend `app/pages/2_Run_Evaluation.py` to support the RAG agent
- [x] T046 [US3] Run RAG evaluation validation (spec US3 acceptance scenarios)

**Checkpoint**: All three agent evaluations are independently functional and stored together.

---

## Phase 6: User Story 4 - Result Storage and Comparison (Priority: P4)

**Goal**: Retrieve stored runs filtered by agent type, model, tier, and date; compare two runs
side-by-side.

**Independent Test**: After two runs exist, filter results and request a comparison, confirming
both runs return and align by tier (quickstart Scenario 4).

### Tests for User Story 4 âš ï¸ (write first, MUST FAIL)

- [x] T047 [P] [US4] Unit test in `tests/unit/test_result_filters.py` for `get_results` filtering by agent type, model, tier, and date range (FR-006)
- [x] T048 [P] [US4] Unit test in `tests/unit/test_compare_runs.py` asserting tier alignment and `IncomparableRunsError` for mismatched agent types (FR-009)

### Implementation for User Story 4

- [x] T049 [US4] Implement `compare_runs(run_id_a, run_id_b)` in `src/agenteval/db/repository.py` aligning TierResults by `(tier_kind, tier_value)` per `contracts/evaluation-service.md`
- [x] T050 [US4] Implement `app/pages/3_Results_Compare.py`: filter controls, results table, and side-by-side comparison view (FR-009, SC-004)
- [x] T051 [US4] Run quickstart Scenario 4 to validate persistence retrieval and side-by-side comparison

**Checkpoint**: Full retrieval and comparison workflow operational over stored results.

---

## Phase 7: Polish & Cross-Cutting Concerns

**Purpose**: Constitution gates and cross-story hardening

- [x] T052 [P] Add JSON export of results on `app/pages/3_Results_Compare.py` (machine-readable output, constitution III)
- [x] T053 [P] Add benchmark test in `tests/benchmark/test_scoring_throughput.py` asserting â‰¥500 cached prompts/min on one core (constitution IV)
- [x] T054 [US1] Run quickstart Scenario 5 (tier-skip handling) and assert `skipped` reason + `partial` run status (SC-006)
- [x] T055 [P] Audit error messages across services and pages for what/why/next format (constitution III)
- [x] T056 [P] Verify coverage â‰¥80% on changed modules and that ruff + black pass (constitution I & II quality gates)
- [x] T057 [P] Update `README.md` / docs with onboarding config example and full run walkthrough

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies â€” start immediately
- **Foundational (Phase 2)**: Depends on Setup â€” BLOCKS all user stories
- **User Stories (Phases 3â€“6)**: All depend on Foundational completion
  - US1 (P1) â†’ US2 (P2) â†’ US3 (P3) â†’ US4 (P4) in priority order, OR in parallel by different
    developers since each touches its own agent module and dataset
  - US4 depends only on the Foundational data layer + at least one completed run to compare
- **Polish (Phase 7)**: Depends on the targeted user stories being complete

### Story Independence

- US1, US2, US3 each own a distinct `src/agenteval/agents/*.py`, dataset folder, and test files â€”
  no cross-story code dependencies. They share `runner.py`, `metrics.py`, and the Run Evaluation
  page (sequential edits to those shared files are the only coordination point).
- US4 reads what the other stories write; it needs the Foundational repository but no agent code.

### Within Each User Story

- Tests (âš ï¸) MUST be written and FAIL before implementation
- Dataset â†’ agent logic â†’ metrics â†’ runner wiring â†’ UI â†’ validation

---

## Parallel Execution Examples

### Foundational entities (after T001â€“T005)

```
T006 (llm_target + benchmark_dataset models)
T007 (evaluation_run + tier_result models)
T011 (config validation tests)
T013 (tier definitions)
T019 (manifest builder)
T020 (scoring base)
```

### User Story 1 tests (after Foundational)

```
T023 (chatbot tier unit test)
T024 (chatbot run integration test)
```

### Cross-story parallelism (multiple developers, after Foundational)

```
Developer A: US1 (T023â€“T030)
Developer B: US2 (T031â€“T038)
Developer C: US3 (T039â€“T046)
```

---

## Implementation Strategy

### MVP First (User Story 1 only)

1. Phase 1: Setup
2. Phase 2: Foundational (CRITICAL â€” blocks all stories)
3. Phase 3: User Story 1 (Chatbot)
4. **STOP and VALIDATE** with quickstart Scenario 2 â€” deployable MVP

### Incremental Delivery

- Foundational â†’ US1 (MVP, chatbot) â†’ US2 (tool-calling) â†’ US3 (RAG) â†’ US4 (compare) â†’ Polish
- Each story is independently testable and adds value without breaking prior stories.

---

## Notes

- [P] tasks = different files, no incomplete dependencies
- Constitution II is non-negotiable: verify each story's tests fail before implementing
- The judge-model non-determinism for RAG/chatbot is mitigated per plan Complexity Tracking
  (temp 0 + fixed seed, recorded in manifest); tool-correctness stays deterministic
- Commit after each task or logical group

