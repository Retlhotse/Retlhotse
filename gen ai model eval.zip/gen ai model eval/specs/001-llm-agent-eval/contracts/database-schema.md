# Contract: Database Schema (SQLite)

**Feature**: 001-llm-agent-eval

The persisted schema backing the repository layer. Authoritative field definitions live in
[data-model.md](../data-model.md); this contract fixes table/column names and keys.

```sql
CREATE TABLE llm_target (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    name              TEXT    NOT NULL UNIQUE,
    provider          TEXT    NOT NULL,
    model_identifier  TEXT    NOT NULL,
    version_snapshot  TEXT,
    config_json       TEXT    NOT NULL,
    created_at        TEXT    NOT NULL
);

CREATE TABLE benchmark_dataset (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_type    TEXT    NOT NULL CHECK (agent_type IN ('chatbot','rag','tool_calling')),
    name          TEXT    NOT NULL,
    version       TEXT    NOT NULL,
    content_hash  TEXT    NOT NULL,
    source_path   TEXT    NOT NULL,
    UNIQUE (agent_type, name, version)
);

CREATE TABLE evaluation_run (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    llm_target_id INTEGER NOT NULL REFERENCES llm_target(id),
    dataset_id    INTEGER NOT NULL REFERENCES benchmark_dataset(id),
    agent_type    TEXT    NOT NULL CHECK (agent_type IN ('chatbot','rag','tool_calling')),
    status        TEXT    NOT NULL DEFAULT 'running'
                          CHECK (status IN ('running','completed','partial','failed')),
    run_manifest  TEXT    NOT NULL,
    started_at    TEXT    NOT NULL,
    completed_at  TEXT
);

CREATE TABLE tier_result (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id          INTEGER NOT NULL REFERENCES evaluation_run(id),
    tier_kind       TEXT    NOT NULL CHECK (tier_kind IN ('context_tokens','tool_count')),
    tier_value      INTEGER NOT NULL,
    status          TEXT    NOT NULL CHECK (status IN ('scored','skipped','failed')),
    skip_reason     TEXT,
    metrics_json    TEXT,
    measured_tokens INTEGER,
    created_at      TEXT    NOT NULL,
    UNIQUE (run_id, tier_kind, tier_value)
);

CREATE INDEX idx_run_filter ON evaluation_run (llm_target_id, agent_type, started_at);
CREATE INDEX idx_tier_run   ON tier_result (run_id);
```

**Integrity rules enforced in the repository layer** (not all expressible in SQLite CHECKs):
- `tier_result.skip_reason` MUST be non-null when `status = 'skipped'`.
- `tier_result.metrics_json` MUST be non-null when `status = 'scored'`.
- Each TierResult is committed in its own transaction so partial runs persist (FR-010).
