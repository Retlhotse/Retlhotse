# Contract: Evaluation Service Interface

**Feature**: 001-llm-agent-eval

The internal Python interface exposed by `src/agenteval/` to the Streamlit pages. Pages MUST
only call this layer (constitution Principle I — separation of concerns).

---

## `register_model(config: dict) -> LLMTarget`

Validates an onboarding config and persists a new `LLMTarget`.

- **Input**: parsed JSON dict conforming to `model-config.schema.json`.
- **Behaviour**: validate against schema → reject duplicates by `name` → persist.
- **Returns**: the created `LLMTarget`.
- **Errors** (message MUST state what/why/next — constitution III):
  - `ConfigValidationError` — schema violation; message lists the failing field(s).
  - `DuplicateModelError` — a model with that name already exists.

---

## `run_evaluation(target_id: int, agent_type: str, dataset_id: int) -> Iterator[TierResult]`

Runs one agent evaluation across all tiers, yielding each `TierResult` as it completes.

- **Input**: an onboarded model id, agent type (`chatbot` | `rag` | `tool_calling`), dataset id.
- **Behaviour**:
  1. Build the run manifest (constitution V) and create an `EvaluationRun` with status `running`.
  2. For each tier (context tokens for chatbot/rag, tool counts for tool_calling):
     - If the tier payload exceeds `max_context_tokens`, persist a `skipped` TierResult with a
       reason and continue (SC-006).
     - Otherwise call the model, score with deepeval, and persist a `scored` TierResult
       immediately (FR-005, FR-010).
     - On a per-tier exception, persist a `failed` TierResult and continue.
  3. Set run status to `completed` (all scored), `partial` (some scored), or `failed` (none).
- **Yields**: each `TierResult` as soon as it is persisted, enabling live UI updates.
- **Guarantees**: completed tiers are never lost if a later tier fails (SC-005).

---

## `get_results(filters: ResultFilter) -> list[EvaluationRun]`

Retrieves stored runs with their tier results.

- **Filters**: any of `llm_target_id`, `agent_type`, `tier_value`, `date_from`, `date_to` (FR-006).
- **Returns**: matching runs (with eager-loaded tier results), newest first.
- **Performance**: MUST return within 5 s of a run completing (SC-002).

---

## `compare_runs(run_id_a: int, run_id_b: int) -> ComparisonView`

Aligns two runs sharing the same `agent_type` for side-by-side display (FR-009).

- **Precondition**: both runs MUST have the same `agent_type`; otherwise `IncomparableRunsError`.
- **Returns**: a structure pairing TierResults by `(tier_kind, tier_value)` with both scores.

---

## Tier definitions (fixed for v1)

| Agent type | tier_kind | tier values |
|------------|-----------|-------------|
| chatbot | `context_tokens` | 5000, 10000, 30000, 50000 |
| rag | `context_tokens` | 5000, 10000, 30000, 50000 |
| tool_calling | `tool_count` | 5, 15, 30, 50 |
