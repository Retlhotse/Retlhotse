# LLM Agent Evaluation Framework

Evaluates LLMs across three enterprise agent archetypes — **Chatbot**, **RAG**, and
**Tool-Calling** — at multiple context-window or tool-count tiers using
[deepeval](https://deepeval.com) metrics. Results are persisted to a local SQLite database
for side-by-side comparison.

## Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Set your API key environment variable

```bash
export ANTHROPIC_API_KEY=sk-ant-...   # or OPENAI_API_KEY, etc.
```

### 3. Initialise the database

```bash
python -m agenteval.db.engine --init
```

### 4. Launch the dashboard

```bash
streamlit run app/Home.py
```

Open [http://localhost:8501](http://localhost:8501) in your browser.

## Usage

| Page | What it does |
|------|-------------|
| **Onboard Model** | Upload a JSON config to register a model (see `specs/001-llm-agent-eval/contracts/model-config.schema.json`) |
| **Run Evaluation** | Select a model + agent type, run the suite, and see each test's score live |
| **Results / Compare** | Filter stored runs and compare two models side-by-side |

## Evaluation Tiers

| Agent type | Dimension | Tiers |
|------------|-----------|-------|
| Chatbot | Context tokens | 5k, 10k, 30k, 50k |
| RAG | Context tokens | 5k, 10k, 30k, 50k |
| Tool-Calling | Tool count | 5, 15, 30, 50 |

## Testing

```bash
pytest                        # run full suite with coverage
pytest tests/unit/            # unit tests only
pytest tests/integration/     # integration tests only
pytest tests/benchmark/       # performance benchmarks
```

## Full Validation

See `specs/001-llm-agent-eval/quickstart.md` for end-to-end validation scenarios.
