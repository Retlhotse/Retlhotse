<!--
SYNC IMPACT REPORT
==================
Version change: 1.0.0 → 1.1.0  (MINOR — new Security & Credential Handling section)
Modified principles: none
Added sections:
  - Security & Credential Handling (governs onboarding credential storage)
Removed sections: n/a
Rationale: On-premises / air-gapped model targets cannot always rely on host environment
  variables for credential provisioning. The framework now permits a raw `api_key` to be supplied
  inline in the onboarding config as an explicit, documented alternative to `api_key_env`. This
  section records the policy, its trade-offs (inline keys are persisted to the local SQLite DB),
  and the operator's responsibility to protect that store.
Templates checked:
  - .specify/templates/plan-template.md  ✅ No new gate required; credential handling is design-level
  - .specify/templates/spec-template.md  ✅ No constitution-specific changes required
  - .specify/templates/tasks-template.md ✅ No phase-ordering impact
Downstream artifacts updated:
  - specs/001-llm-agent-eval/contracts/model-config.schema.json  ✅ credentials now allow api_key XOR api_key_env
  - app/pages/1_Onboard_Model.py  ✅ config format + schema surfaced on the onboarding page
Deferred TODOs: none
-->

# Gen AI Model Eval Constitution

## Core Principles

### I. Code Quality

Every module MUST be clean, typed, and self-documenting through well-named identifiers.

- All public interfaces MUST carry type annotations (or equivalent for the chosen language).
- Dead code, commented-out blocks, and unresolved TODOs MUST NOT be merged to the main branch.
- Functions and classes MUST have a single, clearly-stated responsibility; mixed concerns require
  explicit justification in the PR.
- Linting and formatting gates MUST pass in CI before any merge.

### II. Test-First Development (NON-NEGOTIABLE)

Tests MUST be written and confirmed to fail before implementation begins. This rule has no exceptions.

- Red-Green-Refactor: write failing test → implement until green → refactor without breaking green.
- Unit test coverage MUST reach ≥ 80 % for all new modules; coverage regressions are blocked.
- Every evaluation metric or scoring function MUST have a property-based or parametric test that
  verifies edge-case correctness (empty responses, null outputs, maximum-length inputs).
- Integration tests MUST cover each model provider adapter end-to-end using recorded fixtures so
  tests do not require live API calls in CI.

### III. UX Consistency

All user-facing surfaces — CLI flags, output formats, error messages, and report layouts — MUST
follow a single, documented interaction contract.

- CLI commands MUST follow the pattern `<verb> <noun> [--options]`; no positional-only argument APIs.
- Structured output (JSON / CSV / Markdown) MUST use consistent field names across all commands and
  reports; field renames are breaking changes and require a version bump.
- Error messages MUST include: what failed, why it failed, and what the user can do next.
- Human-readable and machine-readable (JSON) output modes MUST both be supported for every command
  that produces tabular or comparative data.

### IV. Performance Standards

Evaluation pipelines MUST meet measurable latency and throughput targets; unmeasured performance
is non-compliant.

- A single-model evaluation run over a 100-prompt benchmark MUST complete in ≤ 60 seconds
  (excluding network I/O to the model provider API).
- Batch scoring logic MUST process ≥ 500 prompts/minute on a single CPU core when operating on
  cached responses.
- Memory usage for any evaluation process MUST NOT exceed 512 MB resident set size for a standard
  100-prompt benchmark.
- Every performance-critical path MUST have a benchmark test that runs in CI and fails if the
  target is regressed by > 15 %.

### V. Evaluation Integrity

Evaluation results MUST be reproducible, auditable, and free from undisclosed bias.

- Every evaluation run MUST emit a manifest recording: model IDs, prompt hashes, scorer versions,
  timestamps, and random seeds used.
- Prompt datasets and golden references MUST be versioned under source control; modifications
  MUST be logged as a distinct dataset version.
- Scorer implementations MUST be deterministic for identical inputs; any non-deterministic scorer
  MUST document its variance bounds and MUST NOT be used as a primary metric.
- Results MUST NOT be published without disclosing evaluation parameters in the same artifact.

## Security & Credential Handling

Model-connection credentials MUST be handled per the following policy. The framework supports two
mutually exclusive credential sources in an onboarding config, and each config MUST supply exactly
one of them:

- **`api_key_env` (preferred)** — the *name* of an environment variable holding the key. The key
  value itself is read at run time and MUST NOT be persisted. This is the default for cloud
  providers and any host where environment-based secret provisioning is available.
- **`api_key` (on-premises escape hatch)** — the raw token supplied inline. This is permitted for
  on-premises, air-gapped, or self-hosted targets that cannot rely on host environment variables.

Operators using inline `api_key` MUST acknowledge the following trade-off, which the onboarding
surface MUST make visible:

- An inline `api_key` is stored in the local SQLite database (`LLMTarget.config_json`) in
  plaintext. The database file is therefore sensitive and MUST be protected with appropriate
  filesystem permissions and excluded from version control.
- Inline keys MUST NOT be committed to source control, shared in exported result artifacts, or
  echoed in logs or UI previews; previews MUST mask the raw value.

Providers MUST accept an optional `endpoint` / base URL so on-premises deployments can be targeted
without code changes.

## Quality Gates

The following gates MUST be enforced in CI and MUST NOT be bypassed:

| Gate | Threshold | Blocks |
|------|-----------|--------|
| Lint / format | Zero violations | Merge |
| Unit test coverage | ≥ 80 % on changed modules | Merge |
| Performance benchmark | ≤ 15 % regression vs. baseline | Merge |
| Type check | Zero errors | Merge |
| Evaluation manifest present | Required for any result artifact | Release |

If a gate cannot be automated, it MUST be documented as a manual checklist item in `quickstart.md`
for the relevant feature.

## Development Workflow

- Features MUST follow the full SDD cycle: specify → clarify → plan → tasks → analyze → implement.
- No implementation task MAY begin before `tasks.md` exists and `/speckit-analyze` reports zero
  CRITICAL findings.
- Each phase checkpoint in `tasks.md` MUST be validated before the next phase begins.
- All constitution compliance checks are part of `/speckit-analyze`; CRITICAL findings block
  implementation.

## Governance

- This constitution supersedes all other development conventions; conflicts resolve in favor of
  the constitution.
- Amendments require: (a) a written rationale, (b) a version bump per semver rules below,
  (c) propagation to affected templates via `/speckit-constitution`, and (d) a note in the PR.
- Versioning: MAJOR — principle removal or redefinition; MINOR — new principle or section;
  PATCH — wording, clarifications, typo fixes.
- All `/speckit-analyze` runs MUST verify compliance with every principle; violations classified
  as CRITICAL halt implementation until resolved.

**Version**: 1.1.0 | **Ratified**: 2026-06-16 | **Last Amended**: 2026-06-16
