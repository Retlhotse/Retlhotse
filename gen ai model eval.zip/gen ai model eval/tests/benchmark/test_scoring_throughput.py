"""
Performance benchmark: cached scoring throughput (constitution Principle IV).

Guard: ≥ 500 prompts/minute on one core when operating on pre-built ContextPayloads.
This tests the token-counting + payload-assembly path, which is the hot loop for
cached-response scenarios.
"""

from __future__ import annotations

import time

from agenteval.config.tiers import build_context_payload, count_tokens

FILLER_CHUNK = (
    "Enterprise software performance optimization involves multiple layers of improvement "
    "including database query optimization, caching strategies, CDN implementation, and code "
    "profiling to identify hot paths. Teams use profilers like py-spy and cProfile to find "
    "the most expensive operations, then apply targeted optimizations. "
)

PROMPTS_TO_SCORE = 100  # count per benchmark run
REQUIRED_PER_MINUTE = 500


def _simulate_payload_assembly(target_tokens: int) -> dict:
    """Simulate the cached-scoring hot path: build payload + measure tokens."""
    payload = build_context_payload(
        base_text="The user asks: What are the main ML model types?",
        filler_chunks=[FILLER_CHUNK] * 200,
        target_tokens=target_tokens,
    )
    return {
        "text": payload.text,
        "measured_tokens": payload.measured_tokens,
        "target_tokens": payload.target_tokens,
    }


class TestScoringThroughput:
    def test_payload_assembly_rate_meets_threshold(self):
        """
        Assemble 100 payloads at 5k-token target and verify the rate
        extrapolates to ≥ 500/min — constitution Principle IV.

        Note: Only the CPU-bound payload-assembly path is benchmarked here.
        Live model API calls are excluded (network I/O is out of scope).
        """
        start = time.perf_counter()
        results = [_simulate_payload_assembly(target_tokens=5_000) for _ in range(PROMPTS_TO_SCORE)]
        elapsed = time.perf_counter() - start

        elapsed_minutes = elapsed / 60.0
        rate_per_minute = PROMPTS_TO_SCORE / elapsed_minutes

        # Validate results are non-trivial
        assert all(r["measured_tokens"] > 0 for r in results)

        assert rate_per_minute >= REQUIRED_PER_MINUTE, (
            f"Throughput {rate_per_minute:.0f} prompts/min is below the required "
            f"{REQUIRED_PER_MINUTE} prompts/min (constitution IV). "
            f"Elapsed: {elapsed:.2f}s for {PROMPTS_TO_SCORE} payloads."
        )

    def test_token_counting_is_fast(self):
        """count_tokens on a 5k-token string should complete in < 100ms."""
        long_text = FILLER_CHUNK * 100
        start = time.perf_counter()
        for _ in range(50):
            count_tokens(long_text)
        elapsed = time.perf_counter() - start
        avg_ms = (elapsed / 50) * 1000
        assert avg_ms < 100, f"count_tokens averaged {avg_ms:.1f}ms — too slow."
