"""Integration test: tool-calling evaluation using recorded fixtures."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from agenteval.agents.tool_calling import run_tool_calling_tier
from agenteval.config.tiers import TOOL_COUNT_TIERS

DATASET_PATH = (
    Path(__file__).resolve().parents[2] / "datasets" / "tool_calling" / "v1.0.json"
)


class TestToolCallingDataset:
    def test_dataset_file_exists(self):
        assert DATASET_PATH.exists()

    def test_dataset_has_enough_tools(self):
        data = json.loads(DATASET_PATH.read_text())
        assert len(data["base_tools"]) >= 50

    def test_dataset_has_test_cases(self):
        data = json.loads(DATASET_PATH.read_text())
        assert len(data["test_cases"]) >= 4


class TestToolCallingEndToEnd:
    @pytest.fixture()
    def dataset_data(self):
        return json.loads(DATASET_PATH.read_text())

    @pytest.fixture()
    def mock_provider(self):
        provider = MagicMock()
        provider.model_identifier = "gpt-4o-mini"
        provider.generate_with_tools.return_value = (
            "I'll search for flights.",
            [{"name": "search_flights", "input": {"destination": "London"}}],
        )
        return provider

    def test_all_four_tool_count_tiers(self, mock_provider, dataset_data):
        """Run all 4 tool-count tiers and confirm results for each."""
        results = []
        tc = dataset_data["test_cases"][0]
        all_tools = dataset_data["base_tools"]

        for tool_count in TOOL_COUNT_TIERS:
            result = run_tool_calling_tier(mock_provider, tc, all_tools, tool_count)
            results.append(result)

        assert len(results) == 4
        tier_values = [r.tool_count for r in results]
        assert tier_values == TOOL_COUNT_TIERS

    def test_tools_called_captured(self, mock_provider, dataset_data):
        tc = dataset_data["test_cases"][0]
        all_tools = dataset_data["base_tools"]
        result = run_tool_calling_tier(mock_provider, tc, all_tools, tool_count=5)
        assert result.tools_called[0]["name"] == "search_flights"

    def test_provider_receives_correct_tool_count(self, mock_provider, dataset_data):
        tc = dataset_data["test_cases"][0]
        all_tools = dataset_data["base_tools"]
        run_tool_calling_tier(mock_provider, tc, all_tools, tool_count=15)
        call_kwargs = mock_provider.generate_with_tools.call_args
        called_tools = call_kwargs[1].get("tools") or call_kwargs[0][1]
        assert len(called_tools) == 15
