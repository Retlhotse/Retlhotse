"""Integration test: RAG evaluation using recorded fixtures."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from agenteval.agents.rag import run_rag_tier
from agenteval.config.tiers import CONTEXT_TOKEN_TIERS

DATASET_PATH = (
    Path(__file__).resolve().parents[2] / "datasets" / "rag" / "v1.0.json"
)


class TestRagDataset:
    def test_dataset_file_exists(self):
        assert DATASET_PATH.exists()

    def test_dataset_has_knowledge_chunks(self):
        data = json.loads(DATASET_PATH.read_text())
        assert len(data["knowledge_chunks"]) >= 3

    def test_dataset_has_test_cases(self):
        data = json.loads(DATASET_PATH.read_text())
        assert len(data["test_cases"]) >= 2


class TestRagEndToEnd:
    @pytest.fixture()
    def dataset_data(self):
        return json.loads(DATASET_PATH.read_text())

    @pytest.fixture()
    def mock_provider(self):
        provider = MagicMock()
        provider.model_identifier = "gpt-4o-mini"
        provider.generate.return_value = (
            "Machine learning is a subset of AI. The three main types are supervised, "
            "unsupervised, and reinforcement learning."
        )
        return provider

    def test_rag_tier_returns_result(self, mock_provider, dataset_data):
        tc = dataset_data["test_cases"][0]
        chunks = dataset_data["knowledge_chunks"]
        result = run_rag_tier(mock_provider, tc, chunks, target_tokens=5000)
        assert result.actual_output != ""
        assert len(result.retrieval_context) > 0
        assert result.measured_tokens > 0

    def test_all_four_context_tiers(self, mock_provider, dataset_data):
        """Verify the agent runs at all 4 context sizes without error."""
        tc = dataset_data["test_cases"][0]
        chunks = dataset_data["knowledge_chunks"]
        results = []
        for target_tokens in CONTEXT_TOKEN_TIERS:
            result = run_rag_tier(mock_provider, tc, chunks, target_tokens=target_tokens)
            results.append(result)
        assert len(results) == 4
        token_counts = [r.measured_tokens for r in results]
        # Larger targets should produce larger or equal payloads
        assert token_counts[-1] >= token_counts[0]

    def test_question_included_in_prompt(self, mock_provider, dataset_data):
        tc = dataset_data["test_cases"][0]
        chunks = dataset_data["knowledge_chunks"]
        run_rag_tier(mock_provider, tc, chunks, target_tokens=1000)
        prompt_used = mock_provider.generate.call_args[0][0]
        assert tc["question"].lower()[:20] in prompt_used.lower()
