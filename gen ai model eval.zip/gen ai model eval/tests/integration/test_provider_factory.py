"""Integration tests for provider factory using recorded fixtures (no live API)."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from agenteval.config.model_config import ModelConfig, parse_model_config
from agenteval.providers.base import ProviderError
from agenteval.providers.factory import AnthropicProvider, OpenAIProvider, build_provider


ANTHROPIC_CFG = {
    "name": "test-claude",
    "provider": "anthropic",
    "model_identifier": "claude-haiku-4-5-20251001",
    "credentials": {"api_key_env": "TEST_ANTHROPIC_KEY"},
}

OPENAI_CFG = {
    "name": "test-gpt",
    "provider": "openai",
    "model_identifier": "gpt-4o-mini",
    "credentials": {"api_key_env": "TEST_OPENAI_KEY"},
}


@pytest.fixture(autouse=True)
def set_test_env(monkeypatch):
    monkeypatch.setenv("TEST_ANTHROPIC_KEY", "sk-ant-test-key")
    monkeypatch.setenv("TEST_OPENAI_KEY", "sk-test-openai-key")


class TestBuildProvider:
    def test_builds_anthropic_provider(self):
        cfg = parse_model_config(ANTHROPIC_CFG)
        with patch("anthropic.Anthropic"):
            provider = build_provider(cfg)
        assert isinstance(provider, AnthropicProvider)
        assert provider.model_identifier == "claude-haiku-4-5-20251001"

    def test_builds_openai_provider(self):
        cfg = parse_model_config(OPENAI_CFG)
        with patch("openai.OpenAI"):
            provider = build_provider(cfg)
        assert isinstance(provider, OpenAIProvider)

    def test_missing_env_var_raises(self, monkeypatch):
        monkeypatch.delenv("TEST_ANTHROPIC_KEY", raising=False)
        cfg = parse_model_config(ANTHROPIC_CFG)
        with pytest.raises(ProviderError) as exc_info:
            build_provider(cfg)
        assert "What to do" in str(exc_info.value)


class TestAnthropicProviderGenerate:
    def test_generate_returns_text(self):
        with patch("anthropic.Anthropic") as mock_cls:
            mock_client = MagicMock()
            mock_cls.return_value = mock_client

            # Recorded fixture response
            content_block = MagicMock()
            content_block.text = "Paris is the capital of France."
            mock_client.messages.create.return_value = MagicMock(content=[content_block])

            provider = AnthropicProvider(
                "claude-haiku-4-5-20251001", api_key="sk-ant-test"
            )
            result = provider.generate("What is the capital of France?")

        assert result == "Paris is the capital of France."

    def test_generate_raises_provider_error_on_api_failure(self):
        with patch("anthropic.Anthropic") as mock_cls:
            mock_client = MagicMock()
            mock_cls.return_value = mock_client
            mock_client.messages.create.side_effect = Exception("API error")

            provider = AnthropicProvider("claude-haiku-4-5-20251001", api_key="sk-ant-test")
            with pytest.raises(ProviderError):
                provider.generate("test prompt")


class TestOpenAIProviderGenerate:
    def test_generate_returns_text(self):
        with patch("openai.OpenAI") as mock_cls:
            mock_client = MagicMock()
            mock_cls.return_value = mock_client

            mock_choice = MagicMock()
            mock_choice.message.content = "The answer is 42."
            mock_client.chat.completions.create.return_value = MagicMock(
                choices=[mock_choice]
            )

            provider = OpenAIProvider("gpt-4o-mini", api_key="sk-test")
            result = provider.generate("What is the answer?")

        assert result == "The answer is 42."

    def test_generate_with_tools_returns_tool_calls(self):
        with patch("openai.OpenAI") as mock_cls:
            mock_client = MagicMock()
            mock_cls.return_value = mock_client

            mock_tool_call = MagicMock()
            mock_tool_call.function.name = "search_flights"
            mock_tool_call.function.arguments = '{"destination": "NYC"}'

            mock_choice = MagicMock()
            mock_choice.message.content = None
            mock_choice.message.tool_calls = [mock_tool_call]
            mock_client.chat.completions.create.return_value = MagicMock(
                choices=[mock_choice]
            )

            provider = OpenAIProvider("gpt-4o-mini", api_key="sk-test")
            text, called = provider.generate_with_tools(
                "Book a flight to NYC",
                [{"name": "search_flights", "description": "Search for flights"}],
            )

        assert called[0]["name"] == "search_flights"
        assert called[0]["input"]["destination"] == "NYC"
