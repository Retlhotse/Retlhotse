"""Integration test: chatbot evaluation end-to-end using recorded fixtures."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from agenteval.models import Base, BenchmarkDataset, LLMTarget
from agenteval.db.repository import Repository


DATASET_PATH = (
    Path(__file__).resolve().parents[2] / "datasets" / "chatbot" / "v1.0.json"
)


@pytest.fixture()
def in_memory_session():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine, expire_on_commit=False)
    sess = factory()
    yield sess
    sess.close()


@pytest.fixture()
def chatbot_dataset(in_memory_session):
    from datetime import datetime, timezone
    import hashlib

    data = json.loads(DATASET_PATH.read_text())
    content_hash = hashlib.sha256(DATASET_PATH.read_bytes()).hexdigest()[:16]
    ds = BenchmarkDataset(
        agent_type="chatbot",
        name=data["name"],
        version=data["version"],
        content_hash=content_hash,
        source_path=str(DATASET_PATH),
    )
    in_memory_session.add(ds)
    in_memory_session.commit()
    return ds


@pytest.fixture()
def chatbot_target(in_memory_session):
    from datetime import datetime, timezone

    cfg = {
        "name": "fixture-model",
        "provider": "openai",
        "model_identifier": "gpt-4o-mini",
        "credentials": {"api_key_env": "TEST_OPENAI_KEY"},
    }
    target = LLMTarget(
        name="fixture-model",
        provider="openai",
        model_identifier="gpt-4o-mini",
        config_json=json.dumps(cfg),
        created_at=datetime.now(timezone.utc),
    )
    in_memory_session.add(target)
    in_memory_session.commit()
    return target


class TestChatbotRunEndToEnd:
    def test_dataset_file_exists(self):
        assert DATASET_PATH.exists(), f"Chatbot dataset not found at {DATASET_PATH}"

    def test_dataset_has_test_cases(self):
        data = json.loads(DATASET_PATH.read_text())
        assert "test_cases" in data
        assert len(data["test_cases"]) > 0

    def test_chatbot_agent_produces_output(self):
        """Run one chatbot tier with a mock provider and verify TierResult shape."""
        from agenteval.agents.chatbot import build_filler_chunks, run_chatbot_tier

        mock_provider = MagicMock()
        mock_provider.model_identifier = "gpt-4o-mini"
        mock_provider.generate.return_value = (
            "The three product issues were: 1) slow dashboard loading, "
            "2) export timeout, 3) search special characters."
        )

        data = json.loads(DATASET_PATH.read_text())
        tc = data["test_cases"][0]
        filler = build_filler_chunks(tc)
        result = run_chatbot_tier(mock_provider, tc, target_tokens=5000, filler_chunks=filler)

        assert result.actual_output != ""
        assert result.measured_tokens > 0
        assert result.target_tokens == 5000

    def test_four_tiers_produce_four_results(self, in_memory_session, chatbot_target, chatbot_dataset):
        """Simulate 4 chatbot tiers and confirm 4 TierResults are created."""
        from datetime import datetime, timezone
        from agenteval.models import EvaluationRun, TierResult
        from agenteval.config.tiers import CONTEXT_TOKEN_TIERS

        run = EvaluationRun(
            llm_target_id=chatbot_target.id,
            dataset_id=chatbot_dataset.id,
            agent_type="chatbot",
            status="running",
            run_manifest="{}",
            started_at=datetime.now(timezone.utc),
        )
        in_memory_session.add(run)
        in_memory_session.commit()

        repo = Repository(in_memory_session)
        for val in CONTEXT_TOKEN_TIERS:
            repo.persist_tier_result(
                run_id=run.id,
                tier_kind="context_tokens",
                tier_value=val,
                status="scored",
                metrics={"answer_relevancy": 0.88},
                measured_tokens=val - 100,
            )

        tiers = repo.get_tier_results(run.id)
        assert len(tiers) == 4
        assert {t.tier_value for t in tiers} == set(CONTEXT_TOKEN_TIERS)
