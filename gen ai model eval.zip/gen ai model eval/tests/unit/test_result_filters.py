"""Unit tests for get_results filtering (FR-006)."""

from __future__ import annotations

import json
from datetime import datetime, timezone

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from agenteval.models import Base, BenchmarkDataset, EvaluationRun, LLMTarget
from agenteval.db.repository import Repository, ResultFilter


@pytest.fixture()
def session():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine, expire_on_commit=False)
    sess = factory()
    yield sess
    sess.close()


@pytest.fixture()
def repo(session):
    return Repository(session)


@pytest.fixture()
def populated(session):
    targets = [
        LLMTarget(name="model-a", provider="openai", model_identifier="gpt-4o",
                  config_json="{}", created_at=datetime.now(timezone.utc)),
        LLMTarget(name="model-b", provider="anthropic", model_identifier="claude",
                  config_json="{}", created_at=datetime.now(timezone.utc)),
    ]
    datasets = [
        BenchmarkDataset(agent_type="chatbot", name="chatbot-ds", version="1.0",
                         content_hash="h1", source_path="p1"),
        BenchmarkDataset(agent_type="rag", name="rag-ds", version="1.0",
                         content_hash="h2", source_path="p2"),
    ]
    for obj in targets + datasets:
        session.add(obj)
    session.commit()

    for target in targets:
        for ds in datasets:
            session.add(EvaluationRun(
                llm_target_id=target.id,
                dataset_id=ds.id,
                agent_type=ds.agent_type,
                status="completed",
                run_manifest="{}",
                started_at=datetime.now(timezone.utc),
            ))
    session.commit()
    return {"targets": targets, "datasets": datasets}


class TestFilterByAgentType:
    def test_filter_chatbot_only(self, repo, populated):
        results = repo.get_results(ResultFilter(agent_type="chatbot"))
        assert all(r.agent_type == "chatbot" for r in results)
        assert len(results) == 2

    def test_filter_rag_only(self, repo, populated):
        results = repo.get_results(ResultFilter(agent_type="rag"))
        assert all(r.agent_type == "rag" for r in results)

    def test_no_filter_returns_all(self, repo, populated):
        results = repo.get_results(ResultFilter())
        assert len(results) == 4


class TestFilterByModel:
    def test_filter_by_target_id(self, repo, populated):
        model_a = populated["targets"][0]
        results = repo.get_results(ResultFilter(llm_target_id=model_a.id))
        assert all(r.llm_target_id == model_a.id for r in results)
        assert len(results) == 2

    def test_nonexistent_model_returns_empty(self, repo, populated):
        results = repo.get_results(ResultFilter(llm_target_id=9999))
        assert results == []


class TestResultsOrder:
    def test_results_newest_first(self, repo, populated):
        results = repo.get_results(ResultFilter())
        started_ats = [r.started_at for r in results]
        assert started_ats == sorted(started_ats, reverse=True)
