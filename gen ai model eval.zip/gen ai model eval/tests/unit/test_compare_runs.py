"""Unit tests for compare_runs tier alignment and error cases (FR-009)."""

from __future__ import annotations

import json
from datetime import datetime, timezone

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from agenteval.models import Base, BenchmarkDataset, EvaluationRun, LLMTarget, TierResult
from agenteval.db.repository import IncomparableRunsError, Repository


@pytest.fixture()
def session():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine, expire_on_commit=False)
    sess = factory()
    yield sess
    sess.close()


@pytest.fixture()
def repo(session):
    return Repository(session)


@pytest.fixture()
def two_chatbot_runs(session):
    target_a = LLMTarget(name="model-a", provider="openai", model_identifier="gpt-4o",
                         config_json="{}", created_at=datetime.now(timezone.utc))
    target_b = LLMTarget(name="model-b", provider="anthropic", model_identifier="claude",
                         config_json="{}", created_at=datetime.now(timezone.utc))
    ds = BenchmarkDataset(agent_type="chatbot", name="ds", version="1.0",
                          content_hash="h", source_path="p")
    session.add_all([target_a, target_b, ds])
    session.commit()

    run_a = EvaluationRun(llm_target_id=target_a.id, dataset_id=ds.id, agent_type="chatbot",
                          status="completed", run_manifest="{}", started_at=datetime.now(timezone.utc))
    run_b = EvaluationRun(llm_target_id=target_b.id, dataset_id=ds.id, agent_type="chatbot",
                          status="completed", run_manifest="{}", started_at=datetime.now(timezone.utc))
    session.add_all([run_a, run_b])
    session.commit()

    for run in [run_a, run_b]:
        for val in [5000, 10000, 30000]:
            session.add(TierResult(
                run_id=run.id, tier_kind="context_tokens", tier_value=val,
                status="scored",
                metrics_json=json.dumps({"answer_relevancy": 0.85}),
                created_at=datetime.now(timezone.utc),
            ))
    session.commit()
    return {"run_a": run_a, "run_b": run_b}


class TestCompareRuns:
    def test_aligned_tiers_returned(self, repo, two_chatbot_runs):
        view = repo.compare_runs(
            two_chatbot_runs["run_a"].id,
            two_chatbot_runs["run_b"].id,
        )
        assert len(view.tiers) == 3
        tier_values = [entry["tier_value"] for entry in view.tiers]
        assert tier_values == sorted(tier_values)

    def test_both_runs_present_in_view(self, repo, two_chatbot_runs):
        view = repo.compare_runs(
            two_chatbot_runs["run_a"].id,
            two_chatbot_runs["run_b"].id,
        )
        assert view.run_a.id == two_chatbot_runs["run_a"].id
        assert view.run_b.id == two_chatbot_runs["run_b"].id

    def test_each_tier_has_both_results(self, repo, two_chatbot_runs):
        view = repo.compare_runs(
            two_chatbot_runs["run_a"].id,
            two_chatbot_runs["run_b"].id,
        )
        for entry in view.tiers:
            assert entry["run_a"] is not None
            assert entry["run_b"] is not None


class TestIncomparableRuns:
    def test_different_agent_types_raises(self, repo, session):
        target = LLMTarget(name="m", provider="openai", model_identifier="gpt-4",
                           config_json="{}", created_at=datetime.now(timezone.utc))
        ds_chat = BenchmarkDataset(agent_type="chatbot", name="c", version="1", content_hash="h1", source_path="p1")
        ds_rag = BenchmarkDataset(agent_type="rag", name="r", version="1", content_hash="h2", source_path="p2")
        session.add_all([target, ds_chat, ds_rag])
        session.commit()

        run_chat = EvaluationRun(llm_target_id=target.id, dataset_id=ds_chat.id, agent_type="chatbot",
                                 status="completed", run_manifest="{}", started_at=datetime.now(timezone.utc))
        run_rag = EvaluationRun(llm_target_id=target.id, dataset_id=ds_rag.id, agent_type="rag",
                                status="completed", run_manifest="{}", started_at=datetime.now(timezone.utc))
        session.add_all([run_chat, run_rag])
        session.commit()

        with pytest.raises(IncomparableRunsError) as exc_info:
            repo.compare_runs(run_chat.id, run_rag.id)
        assert "What to do" in str(exc_info.value)
