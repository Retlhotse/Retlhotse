"""Unit tests for RAG context-tier payload construction."""

from __future__ import annotations

from agenteval.config.tiers import build_context_payload, count_tokens

CHUNK_A = "Machine learning is a subset of AI that enables systems to learn from experience."
CHUNK_B = "Deep learning uses neural networks with multiple layers for feature extraction."
CHUNK_C = "Vector databases store high-dimensional vectors for semantic similarity search."


class TestRagContextAssembly:
    def test_context_payload_joins_chunks(self):
        chunks = [CHUNK_A, CHUNK_B, CHUNK_C]
        payload = build_context_payload(
            base_text="\n\n".join(chunks),
            filler_chunks=chunks * 50,
            target_tokens=5000,
        )
        assert CHUNK_A in payload.text

    def test_smaller_target_produces_fewer_tokens(self):
        chunks = [CHUNK_A] * 200
        p_small = build_context_payload("base", chunks, target_tokens=500)
        p_large = build_context_payload("base", chunks, target_tokens=2000)
        assert p_small.measured_tokens <= p_large.measured_tokens

    def test_payload_measured_tokens_is_positive(self):
        chunks = [CHUNK_A] * 100
        payload = build_context_payload("base", chunks, target_tokens=1000)
        assert payload.measured_tokens > 0

    def test_target_tokens_recorded(self):
        payload = build_context_payload("base", [CHUNK_A] * 50, target_tokens=3000)
        assert payload.target_tokens == 3000


class TestRagAgent:
    def test_run_rag_tier_returns_result(self):
        from unittest.mock import MagicMock
        from agenteval.agents.rag import run_rag_tier

        provider = MagicMock()
        provider.model_identifier = "test-model"
        provider.generate.return_value = "Machine learning learns from experience."

        tc = {
            "question": "What is machine learning?",
            "knowledge_chunk_ids": ["kc001"],
        }
        knowledge_chunks = [
            {"id": "kc001", "topic": "ML", "text": CHUNK_A},
            {"id": "kc002", "topic": "DL", "text": CHUNK_B},
        ]
        result = run_rag_tier(provider, tc, knowledge_chunks, target_tokens=500)

        assert result.input_text == tc["question"]
        assert result.actual_output == "Machine learning learns from experience."
        assert len(result.retrieval_context) > 0
        assert result.measured_tokens > 0

    def test_provider_called_with_question_in_prompt(self):
        from unittest.mock import MagicMock
        from agenteval.agents.rag import run_rag_tier

        provider = MagicMock()
        provider.model_identifier = "test-model"
        provider.generate.return_value = "answer"

        tc = {"question": "What is deep learning?"}
        result = run_rag_tier(
            provider, tc, [{"id": "k1", "topic": "DL", "text": CHUNK_B}], 500
        )
        prompt_used = provider.generate.call_args[0][0]
        assert "deep learning" in prompt_used.lower()
