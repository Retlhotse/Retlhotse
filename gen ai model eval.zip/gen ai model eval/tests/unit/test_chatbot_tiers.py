"""Unit tests for chatbot context-tier payload construction."""

from __future__ import annotations

from agenteval.config.tiers import CONTEXT_TOKEN_TIERS, build_context_payload, count_tokens


FILLER = (
    "Enterprise software performance optimization involves multiple layers of improvement "
    "including database query optimization, caching strategies, and CDN implementation. "
)


class TestTokenCounting:
    def test_count_tokens_returns_positive_int(self):
        text = "Hello, world! This is a test sentence."
        count = count_tokens(text)
        assert isinstance(count, int)
        assert count > 0

    def test_empty_string_returns_zero(self):
        assert count_tokens("") == 0

    def test_longer_text_has_more_tokens(self):
        short = "Hello"
        long = "Hello, this is a longer sentence with many more words in it."
        assert count_tokens(long) > count_tokens(short)


class TestBuildContextPayload:
    def test_payload_reaches_target(self):
        base = "This is the starting context."
        fillers = [FILLER] * 200
        payload = build_context_payload(base, fillers, target_tokens=1000)
        assert payload.measured_tokens >= 900  # within 10% tolerance

    def test_payload_contains_base_text(self):
        base = "Important base content here."
        fillers = [FILLER] * 10
        payload = build_context_payload(base, fillers, target_tokens=500)
        assert base in payload.text

    def test_payload_target_stored(self):
        fillers = [FILLER] * 100
        payload = build_context_payload("start", fillers, target_tokens=2000)
        assert payload.target_tokens == 2000

    def test_insufficient_fillers_does_not_raise(self):
        payload = build_context_payload("base", [], target_tokens=5000)
        assert payload.text == "base"

    def test_all_context_tiers_defined(self):
        assert CONTEXT_TOKEN_TIERS == [5_000, 10_000, 30_000, 50_000]


class TestChatbotFillerChunks:
    def test_build_filler_chunks_returns_list(self):
        from agenteval.agents.chatbot import build_filler_chunks

        tc = {"filler_topic": FILLER}
        chunks = build_filler_chunks(tc)
        assert isinstance(chunks, list)
        assert len(chunks) > 0

    def test_empty_filler_topic_returns_empty(self):
        from agenteval.agents.chatbot import build_filler_chunks

        chunks = build_filler_chunks({"filler_topic": ""})
        assert chunks == []
