"""Unit tests for tool-calling tier logic and deterministic scoring."""

from __future__ import annotations

from agenteval.config.tiers import TOOL_COUNT_TIERS


class TestToolCountTiers:
    def test_tiers_defined(self):
        assert TOOL_COUNT_TIERS == [5, 15, 30, 50]

    def test_all_values_positive(self):
        assert all(t > 0 for t in TOOL_COUNT_TIERS)

    def test_tiers_ascending(self):
        assert TOOL_COUNT_TIERS == sorted(TOOL_COUNT_TIERS)


class TestToolCallingAgent:
    def _make_tools(self, n: int) -> list[dict]:
        return [{"name": f"tool_{i}", "description": f"Tool number {i}"} for i in range(n)]

    def test_tool_count_is_respected(self):
        """run_tool_calling_tier must use exactly tool_count tools."""
        from unittest.mock import MagicMock
        from agenteval.agents.tool_calling import run_tool_calling_tier

        provider = MagicMock()
        provider.model_identifier = "test-model"
        provider.generate_with_tools.return_value = ("I'll use tool_0", [{"name": "tool_0", "input": {}}])

        tools = self._make_tools(50)
        tc = {
            "input": "Do something",
            "expected_tools": [{"name": "tool_0"}],
        }
        result = run_tool_calling_tier(provider, tc, tools, tool_count=5)
        # Provider must have been called with exactly 5 tools
        call_args = provider.generate_with_tools.call_args
        assert len(call_args[1]["tools"]) == 5 or len(call_args[0][1]) == 5

    def test_result_contains_called_tools(self):
        from unittest.mock import MagicMock
        from agenteval.agents.tool_calling import run_tool_calling_tier

        provider = MagicMock()
        provider.model_identifier = "test-model"
        provider.generate_with_tools.return_value = (
            "Booking flight",
            [{"name": "search_flights", "input": {"destination": "NYC"}}],
        )

        tools = self._make_tools(5)
        tc = {"input": "Book flight to NYC", "expected_tools": [{"name": "search_flights"}]}
        result = run_tool_calling_tier(provider, tc, tools, tool_count=5)

        assert result.tools_called[0]["name"] == "search_flights"
        assert result.tool_count == 5


class TestToolScoring:
    """Verify deterministic scoring logic (constitution V)."""

    def test_perfect_score_when_all_correct(self):
        """Identical tools_called and expected_tools should yield score ≥ 0.8."""
        from unittest.mock import patch, MagicMock
        from agenteval.scoring.metrics import score_tool_calling

        with patch("agenteval.scoring.metrics.ToolCorrectnessMetric") as mock_cls:
            mock_metric = MagicMock()
            mock_metric.score = 1.0
            mock_cls.return_value = mock_metric
            mock_metric.measure.return_value = None

            scores = score_tool_calling(
                "Book flight to NYC",
                "I'll book that for you.",
                [{"name": "search_flights", "input": {"destination": "NYC"}}],
                [{"name": "search_flights", "input": {"destination": "NYC"}}],
            )
        assert scores["tool_correctness"] == 1.0

    def test_score_is_float_in_range(self):
        from unittest.mock import patch, MagicMock
        from agenteval.scoring.metrics import score_tool_calling

        with patch("agenteval.scoring.metrics.ToolCorrectnessMetric") as mock_cls:
            mock_metric = MagicMock()
            mock_metric.score = 0.5
            mock_cls.return_value = mock_metric
            mock_metric.measure.return_value = None

            scores = score_tool_calling("query", "response", [], [])

        assert 0.0 <= scores["tool_correctness"] <= 1.0
