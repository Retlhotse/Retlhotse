"""Unit tests for repository layer — written BEFORE implementation (Test-First, constitution II)."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from agenteval.models import Base, BenchmarkDataset, EvaluationRun, LLMTarget, TierResult
from agenteval.db.repository import Repository, ResultFilter


@pytest.fixture()
def session():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine, expire_on_commit=False)
    sess = factory()
    yield sess
    sess.close()
    Base.metadata.drop_all(engine)


@pytest.fixture()
def repo(session):
    return Repository(session)


@pytest.fixture()
def sample_target(session):
    t = LLMTarget(
        name="test-model",
        provider="openai",
        model_identifier="gpt-4o-mini",
        config_json=json.dumps({"name": "test-model", "provider": "openai"}),
        created_at=datetime.now(timezone.utc),
    )
    session.add(t)
    session.commit()
    return t


@pytest.fixture()
def sample_dataset(session):
    d = BenchmarkDataset(
        agent_type="chatbot",
        name="test-chatbot-ds",
        version="1.0.0",
        content_hash="abc123",
        source_path="datasets/chatbot/v1.0.json",
    )
    session.add(d)
    session.commit()
    return d


@pytest.fixture()
def sample_run(session, sample_target, sample_dataset):
    r = EvaluationRun(
        llm_target_id=sample_target.id,
        dataset_id=sample_dataset.id,
        agent_type="chatbot",
        status="running",
        run_manifest=json.dumps({"llm_target": {"name": "test-model"}}),
        started_at=datetime.now(timezone.utc),
    )
    session.add(r)
    session.commit()
    return r


class TestPersistTierResult:
    def test_persist_scored_tier(self, repo, sample_run):
        result = repo.persist_tier_result(
            run_id=sample_run.id,
            tier_kind="context_tokens",
            tier_value=5000,
            status="scored",
            metrics={"answer_relevancy": 0.85},
            measured_tokens=4980,
        )
        assert result.id is not None
        assert result.status == "scored"
        assert json.loads(result.metrics_json) == {"answer_relevancy": 0.85}
        assert result.measured_tokens == 4980

    def test_persist_skipped_tier_with_reason(self, repo, sample_run):
        result = repo.persist_tier_result(
            run_id=sample_run.id,
            tier_kind="context_tokens",
            tier_value=50000,
            status="skipped",
            skip_reason="payload exceeds model max context (32000 tokens)",
        )
        assert result.status == "skipped"
        assert result.skip_reason is not None
        assert "32000" in result.skip_reason

    def test_persist_each_tier_in_own_transaction(self, repo, sample_run):
        for val in [5000, 10000]:
            repo.persist_tier_result(
                run_id=sample_run.id,
                tier_kind="context_tokens",
                tier_value=val,
                status="scored",
                metrics={"answer_relevancy": 0.9},
            )
        tiers = repo.get_tier_results(sample_run.id)
        assert len(tiers) == 2

    def test_duplicate_tier_raises(self, repo, sample_run):
        repo.persist_tier_result(
            run_id=sample_run.id,
            tier_kind="context_tokens",
            tier_value=5000,
            status="scored",
            metrics={"answer_relevancy": 0.8},
        )
        with pytest.raises(Exception):
            repo.persist_tier_result(
                run_id=sample_run.id,
                tier_kind="context_tokens",
                tier_value=5000,
                status="scored",
                metrics={"answer_relevancy": 0.9},
            )


class TestRunStatus:
    def test_update_run_status_to_completed(self, repo, sample_run):
        repo.update_run_status(sample_run.id, "completed")
        run = repo.get_run(sample_run.id)
        assert run.status == "completed"
        assert run.completed_at is not None

    def test_partial_status(self, repo, sample_run):
        repo.update_run_status(sample_run.id, "partial")
        run = repo.get_run(sample_run.id)
        assert run.status == "partial"


class TestGetResults:
    def test_filter_by_agent_type(self, repo, sample_target, sample_dataset, session):
        rag_ds = BenchmarkDataset(
            agent_type="rag",
            name="rag-ds",
            version="1.0.0",
            content_hash="def456",
            source_path="datasets/rag/v1.0.json",
        )
        session.add(rag_ds)
        session.commit()

        rag_run = EvaluationRun(
            llm_target_id=sample_target.id,
            dataset_id=rag_ds.id,
            agent_type="rag",
            status="completed",
            run_manifest="{}",
            started_at=datetime.now(timezone.utc),
        )
        session.add(rag_run)
        chatbot_run = EvaluationRun(
            llm_target_id=sample_target.id,
            dataset_id=sample_dataset.id,
            agent_type="chatbot",
            status="completed",
            run_manifest="{}",
            started_at=datetime.now(timezone.utc),
        )
        session.add(chatbot_run)
        session.commit()

        results = repo.get_results(ResultFilter(agent_type="rag"))
        assert all(r.agent_type == "rag" for r in results)
        assert len(results) == 1

    def test_filter_by_model(self, repo, sample_target, sample_dataset, session):
        other = LLMTarget(
            name="other-model",
            provider="anthropic",
            model_identifier="claude-3",
            config_json="{}",
            created_at=datetime.now(timezone.utc),
        )
        session.add(other)
        session.commit()

        for target in [sample_target, other]:
            session.add(
                EvaluationRun(
                    llm_target_id=target.id,
                    dataset_id=sample_dataset.id,
                    agent_type="chatbot",
                    status="completed",
                    run_manifest="{}",
                    started_at=datetime.now(timezone.utc),
                )
            )
        session.commit()

        results = repo.get_results(ResultFilter(llm_target_id=sample_target.id))
        assert all(r.llm_target_id == sample_target.id for r in results)
