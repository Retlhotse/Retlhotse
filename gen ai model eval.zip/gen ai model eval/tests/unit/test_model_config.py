"""Unit tests for model onboarding config validation."""

from __future__ import annotations

import pytest

from agenteval.config.model_config import (
    ConfigValidationError,
    ModelConfig,
    parse_model_config,
)


VALID_ANTHROPIC = {
    "name": "claude-opus",
    "provider": "anthropic",
    "model_identifier": "claude-opus-4-8",
    "credentials": {"api_key_env": "ANTHROPIC_API_KEY"},
    "max_context_tokens": 200000,
}

VALID_OPENAI = {
    "name": "gpt-4o",
    "provider": "openai",
    "model_identifier": "gpt-4o",
    "credentials": {"api_key_env": "OPENAI_API_KEY"},
}

VALID_CUSTOM = {
    "name": "local-llama",
    "provider": "custom",
    "model_identifier": "llama-3",
    "endpoint": "http://localhost:11434/v1",
    "credentials": {"api_key_env": "LOCAL_API_KEY"},
}

VALID_AZURE = {
    "name": "azure-gpt4",
    "provider": "azure_openai",
    "model_identifier": "gpt-4",
    "endpoint": "https://my-resource.openai.azure.com/",
    "credentials": {"api_key_env": "AZURE_OPENAI_KEY"},
}


class TestValidConfigs:
    def test_anthropic_valid(self):
        cfg = parse_model_config(VALID_ANTHROPIC)
        assert cfg.name == "claude-opus"
        assert cfg.provider == "anthropic"
        assert cfg.max_context_tokens == 200000

    def test_openai_valid(self):
        cfg = parse_model_config(VALID_OPENAI)
        assert cfg.provider == "openai"

    def test_custom_with_endpoint_valid(self):
        cfg = parse_model_config(VALID_CUSTOM)
        assert cfg.endpoint == "http://localhost:11434/v1"

    def test_azure_with_endpoint_valid(self):
        cfg = parse_model_config(VALID_AZURE)
        assert cfg.provider == "azure_openai"


class TestMissingRequiredFields:
    def test_missing_name_raises(self):
        data = {**VALID_OPENAI}
        del data["name"]
        with pytest.raises(ConfigValidationError) as exc_info:
            parse_model_config(data)
        assert "What to do" in str(exc_info.value)

    def test_missing_model_identifier_raises(self):
        data = {**VALID_OPENAI}
        del data["model_identifier"]
        with pytest.raises(ConfigValidationError):
            parse_model_config(data)

    def test_missing_credentials_raises(self):
        data = {**VALID_OPENAI}
        del data["credentials"]
        with pytest.raises(ConfigValidationError):
            parse_model_config(data)

    def test_missing_api_key_env_raises(self):
        data = {**VALID_OPENAI, "credentials": {}}
        with pytest.raises(ConfigValidationError):
            parse_model_config(data)


class TestCredentialSources:
    def test_inline_api_key_valid(self):
        data = {
            "name": "onprem-llama",
            "provider": "custom",
            "model_identifier": "llama3-70b",
            "endpoint": "http://10.0.1.42:8000/v1",
            "credentials": {"api_key": "sk-internal-token-xyz"},
        }
        cfg = parse_model_config(data)
        assert cfg.credentials.api_key == "sk-internal-token-xyz"
        assert cfg.credentials.api_key_env is None

    def test_both_credential_sources_raises(self):
        data = {
            **VALID_OPENAI,
            "credentials": {"api_key_env": "OPENAI_API_KEY", "api_key": "sk-raw"},
        }
        with pytest.raises(ConfigValidationError) as exc_info:
            parse_model_config(data)
        assert "not both" in str(exc_info.value).lower()

    def test_neither_credential_source_raises(self):
        data = {**VALID_OPENAI, "credentials": {}}
        with pytest.raises(ConfigValidationError) as exc_info:
            parse_model_config(data)
        assert "required" in str(exc_info.value).lower()


class TestProviderConditionalEndpoint:
    def test_custom_without_endpoint_raises(self):
        data = {**VALID_CUSTOM}
        del data["endpoint"]
        with pytest.raises(ConfigValidationError) as exc_info:
            parse_model_config(data)
        assert "endpoint" in str(exc_info.value).lower()

    def test_azure_without_endpoint_raises(self):
        data = {**VALID_AZURE}
        del data["endpoint"]
        with pytest.raises(ConfigValidationError):
            parse_model_config(data)

    def test_anthropic_without_endpoint_ok(self):
        # endpoint is optional for anthropic
        cfg = parse_model_config(VALID_ANTHROPIC)
        assert cfg.endpoint is None


class TestInvalidProvider:
    def test_unknown_provider_raises(self):
        data = {**VALID_OPENAI, "provider": "unknown_provider"}
        with pytest.raises(ConfigValidationError):
            parse_model_config(data)


class TestErrorMessageFormat:
    def test_error_contains_what_to_do(self):
        data = {**VALID_OPENAI}
        del data["name"]
        with pytest.raises(ConfigValidationError) as exc_info:
            parse_model_config(data)
        msg = str(exc_info.value)
        assert "What to do" in msg or "what to do" in msg.lower()
