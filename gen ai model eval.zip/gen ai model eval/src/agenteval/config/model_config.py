from typing import Literal

from pydantic import BaseModel, Field, model_validator


class CredentialsConfig(BaseModel):
    api_key_env: str | None = Field(default=None, description="Env var name holding the API key")
    api_key: str | None = Field(default=None, description="Raw API key value (for on-prem models)")

    @model_validator(mode="after")
    def exactly_one_credential_source(self) -> "CredentialsConfig":
        has_env = bool(self.api_key_env)
        has_raw = bool(self.api_key)
        if has_env and has_raw:
            raise ValueError(
                "Provide either 'api_key_env' or 'api_key', not both. "
                "Why: having both is ambiguous. "
                "What to do: remove one of the two credential fields."
            )
        if not has_env and not has_raw:
            raise ValueError(
                "Either 'api_key_env' or 'api_key' is required. "
                "Why: the provider needs a credential to authenticate. "
                "What to do: add 'api_key' with the raw token, or 'api_key_env' with the env var name."
            )
        return self


class RequestParams(BaseModel):
    max_tokens: int | None = Field(default=None, ge=1)
    temperature: float | None = Field(default=None, ge=0)

    model_config = {"extra": "allow"}


class ModelConfig(BaseModel):
    name: str = Field(min_length=1, description="Unique display name for the model")
    provider: Literal["anthropic", "openai", "google", "azure_openai", "custom"]
    model_identifier: str = Field(min_length=1)
    version_snapshot: str | None = None
    endpoint: str | None = None
    credentials: CredentialsConfig
    request_params: RequestParams = Field(default_factory=RequestParams)
    max_context_tokens: int | None = Field(default=None, ge=1)

    @model_validator(mode="after")
    def endpoint_required_for_custom_and_azure(self) -> "ModelConfig":
        if self.provider in ("custom", "azure_openai") and not self.endpoint:
            raise ValueError(
                f"Field 'endpoint' is required when provider is '{self.provider}'."
                " What to do: add an 'endpoint' field with the base URL."
            )
        return self


class ConfigValidationError(Exception):
    """Raised when an onboarding JSON config fails validation."""


class DuplicateModelError(Exception):
    """Raised when a model with the same name is already registered."""


def parse_model_config(data: dict) -> ModelConfig:
    """
    Parse and validate a raw dict against ModelConfig.

    Raises ConfigValidationError with what/why/next message on failure.
    """
    try:
        return ModelConfig.model_validate(data)
    except Exception as exc:
        raise ConfigValidationError(
            f"Model configuration is invalid. "
            f"What failed: {exc}. "
            "What to do: correct the JSON fields listed above and re-upload."
        ) from exc
