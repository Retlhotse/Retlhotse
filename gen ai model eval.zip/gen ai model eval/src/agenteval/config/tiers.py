"""Fixed tier definitions and tiktoken-based payload construction."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import tiktoken

AgentType = Literal["chatbot", "rag", "tool_calling"]

CONTEXT_TOKEN_TIERS: list[int] = [5_000, 10_000, 30_000, 50_000]
TOOL_COUNT_TIERS: list[int] = [5, 15, 30, 50]

_FALLBACK_ENCODING = "cl100k_base"


def tier_kind_for(agent_type: AgentType) -> str:
    return "tool_count" if agent_type == "tool_calling" else "context_tokens"


def tier_values_for(agent_type: AgentType) -> list[int]:
    return TOOL_COUNT_TIERS if agent_type == "tool_calling" else CONTEXT_TOKEN_TIERS


def count_tokens(text: str, model: str = _FALLBACK_ENCODING) -> int:
    """Return the token count for *text* using the model's encoding."""
    try:
        enc = tiktoken.encoding_for_model(model)
    except KeyError:
        enc = tiktoken.get_encoding(_FALLBACK_ENCODING)
    return len(enc.encode(text))


@dataclass
class ContextPayload:
    text: str
    measured_tokens: int
    target_tokens: int


def build_context_payload(
    base_text: str,
    filler_chunks: list[str],
    target_tokens: int,
    model: str = _FALLBACK_ENCODING,
) -> ContextPayload:
    """
    Assemble a context payload that hits *target_tokens* by appending
    *filler_chunks* until the target is reached or exceeded.

    Returns a ContextPayload with the assembled text and measured token count.
    """
    assembled = base_text
    current_tokens = count_tokens(assembled, model)

    for chunk in filler_chunks:
        if current_tokens >= target_tokens:
            break
        assembled = assembled + "\n\n" + chunk
        current_tokens = count_tokens(assembled, model)

    return ContextPayload(
        text=assembled,
        measured_tokens=current_tokens,
        target_tokens=target_tokens,
    )
