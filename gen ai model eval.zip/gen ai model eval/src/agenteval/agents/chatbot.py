"""Chatbot agent: builds context-tier payloads and collects responses."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from agenteval.config.tiers import build_context_payload, count_tokens
from agenteval.providers.base import BaseProvider


@dataclass
class ChatbotTestResult:
    input_text: str
    actual_output: str
    measured_tokens: int
    target_tokens: int


def run_chatbot_tier(
    provider: BaseProvider,
    test_case: dict[str, Any],
    target_tokens: int,
    filler_chunks: list[str],
) -> ChatbotTestResult:
    """
    Build a context payload of *target_tokens* for one test case, call the
    provider, and return the response alongside token metadata.
    """
    base_context = test_case.get("base_context", "")
    system_prompt = test_case.get("system_prompt", "You are a helpful assistant.")
    question = test_case["question"]

    payload = build_context_payload(
        base_text=base_context,
        filler_chunks=filler_chunks,
        target_tokens=target_tokens,
        model=provider.model_identifier,
    )

    full_prompt = (
        f"{system_prompt}\n\n"
        f"Conversation history:\n{payload.text}\n\n"
        f"User question: {question}"
    )

    actual_output = provider.generate(full_prompt)
    return ChatbotTestResult(
        input_text=question,
        actual_output=actual_output,
        measured_tokens=payload.measured_tokens,
        target_tokens=target_tokens,
    )


def build_filler_chunks(test_case: dict[str, Any]) -> list[str]:
    """Generate repeated filler paragraphs from the test case's filler_topic."""
    filler = test_case.get("filler_topic", "")
    if not filler:
        return []
    return [filler] * 20  # repeat to allow building up to 50k tokens
