"""RAG agent: assembles retrieved-context tiers and collects model responses."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from agenteval.config.tiers import build_context_payload
from agenteval.providers.base import BaseProvider


@dataclass
class RagTestResult:
    input_text: str
    actual_output: str
    retrieval_context: list[str]
    measured_tokens: int
    target_tokens: int


def run_rag_tier(
    provider: BaseProvider,
    test_case: dict[str, Any],
    knowledge_chunks: list[dict[str, Any]],
    target_tokens: int,
) -> RagTestResult:
    """
    Assemble retrieved knowledge chunks up to *target_tokens*, call the model,
    and return the response with retrieval context for scoring.
    """
    question = test_case["question"]
    system_prompt = (
        "You are a knowledge assistant. "
        "Answer the user's question using ONLY the provided context. "
        "If the answer is not in the context, say so clearly."
    )

    chunk_texts = [c["text"] for c in knowledge_chunks]
    context_text = "\n\n".join(chunk_texts)

    payload = build_context_payload(
        base_text=context_text,
        filler_chunks=chunk_texts * 10,
        target_tokens=target_tokens,
        model=provider.model_identifier,
    )

    full_prompt = (
        f"{system_prompt}\n\n"
        f"Context:\n{payload.text}\n\n"
        f"Question: {question}"
    )

    actual_output = provider.generate(full_prompt)

    assembled_chunks = _split_into_chunks(payload.text, chunk_texts)

    return RagTestResult(
        input_text=question,
        actual_output=actual_output,
        retrieval_context=assembled_chunks,
        measured_tokens=payload.measured_tokens,
        target_tokens=target_tokens,
    )


def _split_into_chunks(assembled_text: str, original_chunks: list[str]) -> list[str]:
    """Return the individual chunks that were assembled into the payload."""
    result = []
    remaining = assembled_text
    for chunk in original_chunks:
        if chunk in remaining:
            result.append(chunk)
            remaining = remaining.replace(chunk, "", 1)
    return result or [assembled_text]
