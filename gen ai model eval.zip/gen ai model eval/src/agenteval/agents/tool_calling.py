"""Tool-calling agent: tests accuracy at different tool-catalog sizes."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from agenteval.providers.base import BaseProvider


@dataclass
class ToolCallingTestResult:
    input_text: str
    actual_output: str
    tools_called: list[dict[str, Any]]
    expected_tools: list[dict[str, Any]]
    tool_count: int


def run_tool_calling_tier(
    provider: BaseProvider,
    test_case: dict[str, Any],
    all_tools: list[dict[str, Any]],
    tool_count: int,
) -> ToolCallingTestResult:
    """
    Present *tool_count* tools to the model and measure which ones it calls.

    The first *tool_count* tools are selected from *all_tools*.  The test case
    supplies the expected tools; if they are not in the selected subset the tier
    is still executed (surfacing selection difficulty with a larger catalog).
    """
    selected_tools = all_tools[:tool_count]
    expected = test_case.get("expected_tools", [])

    actual_output, tools_called_raw = provider.generate_with_tools(
        prompt=test_case["input"],
        tools=selected_tools,
    )

    tools_called = [
        {"name": t.get("name", ""), "input": t.get("input", {})}
        for t in tools_called_raw
    ]

    return ToolCallingTestResult(
        input_text=test_case["input"],
        actual_output=actual_output,
        tools_called=tools_called,
        expected_tools=expected,
        tool_count=tool_count,
    )
