from sqlalchemy import CheckConstraint, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from agenteval.models.base import Base

AGENT_TYPES = ("chatbot", "rag", "tool_calling")


class BenchmarkDataset(Base):
    __tablename__ = "benchmark_dataset"
    __table_args__ = (
        UniqueConstraint("agent_type", "name", "version", name="uq_dataset_version"),
        CheckConstraint(
            "agent_type IN ('chatbot', 'rag', 'tool_calling')", name="ck_agent_type_ds"
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    agent_type: Mapped[str] = mapped_column(String, nullable=False)
    name: Mapped[str] = mapped_column(String, nullable=False)
    version: Mapped[str] = mapped_column(String, nullable=False)
    content_hash: Mapped[str] = mapped_column(String, nullable=False)
    source_path: Mapped[str] = mapped_column(String, nullable=False)

    runs: Mapped[list["EvaluationRun"]] = relationship(  # noqa: F821
        "EvaluationRun", back_populates="dataset", lazy="dynamic"
    )

    def __repr__(self) -> str:
        return (
            f"<BenchmarkDataset id={self.id} agent_type={self.agent_type!r}"
            f" name={self.name!r} version={self.version!r}>"
        )
