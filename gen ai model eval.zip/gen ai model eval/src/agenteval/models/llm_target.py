from datetime import datetime, timezone

from sqlalchemy import DateTime, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from agenteval.models.base import Base


class LLMTarget(Base):
    __tablename__ = "llm_target"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    provider: Mapped[str] = mapped_column(String, nullable=False)
    model_identifier: Mapped[str] = mapped_column(String, nullable=False)
    version_snapshot: Mapped[str | None] = mapped_column(String, nullable=True)
    config_json: Mapped[str] = mapped_column(String, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )

    runs: Mapped[list["EvaluationRun"]] = relationship(  # noqa: F821
        "EvaluationRun", back_populates="llm_target", lazy="dynamic"
    )

    def __repr__(self) -> str:
        return f"<LLMTarget id={self.id} name={self.name!r} provider={self.provider!r}>"
