from datetime import datetime, timezone

from sqlalchemy import CheckConstraint, DateTime, ForeignKey, Index, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from agenteval.models.base import Base


class TierResult(Base):
    __tablename__ = "tier_result"
    __table_args__ = (
        UniqueConstraint("run_id", "tier_kind", "tier_value", name="uq_tier_per_run"),
        CheckConstraint(
            "tier_kind IN ('context_tokens', 'tool_count')", name="ck_tier_kind"
        ),
        CheckConstraint(
            "status IN ('scored', 'skipped', 'failed')", name="ck_tier_status"
        ),
        Index("idx_tier_run", "run_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    run_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("evaluation_run.id"), nullable=False
    )
    tier_kind: Mapped[str] = mapped_column(String, nullable=False)
    tier_value: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[str] = mapped_column(String, nullable=False)
    skip_reason: Mapped[str | None] = mapped_column(String, nullable=True)
    metrics_json: Mapped[str | None] = mapped_column(String, nullable=True)
    measured_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )

    run: Mapped["EvaluationRun"] = relationship(  # noqa: F821
        "EvaluationRun", back_populates="tier_results"
    )

    def __repr__(self) -> str:
        return (
            f"<TierResult id={self.id} tier_kind={self.tier_kind!r}"
            f" tier_value={self.tier_value} status={self.status!r}>"
        )
