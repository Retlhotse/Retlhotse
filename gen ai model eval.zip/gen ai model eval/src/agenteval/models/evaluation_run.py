from datetime import datetime, timezone

from sqlalchemy import CheckConstraint, DateTime, ForeignKey, Integer, String, Index
from sqlalchemy.orm import Mapped, mapped_column, relationship

from agenteval.models.base import Base


class EvaluationRun(Base):
    __tablename__ = "evaluation_run"
    __table_args__ = (
        CheckConstraint(
            "agent_type IN ('chatbot', 'rag', 'tool_calling')", name="ck_agent_type_run"
        ),
        CheckConstraint(
            "status IN ('running', 'completed', 'partial', 'failed')", name="ck_status_run"
        ),
        Index("idx_run_filter", "llm_target_id", "agent_type", "started_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    llm_target_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("llm_target.id"), nullable=False
    )
    dataset_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("benchmark_dataset.id"), nullable=False
    )
    agent_type: Mapped[str] = mapped_column(String, nullable=False)
    status: Mapped[str] = mapped_column(String, nullable=False, default="running")
    run_manifest: Mapped[str] = mapped_column(String, nullable=False)
    started_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    llm_target: Mapped["LLMTarget"] = relationship(  # noqa: F821
        "LLMTarget", back_populates="runs"
    )
    dataset: Mapped["BenchmarkDataset"] = relationship(  # noqa: F821
        "BenchmarkDataset", back_populates="runs"
    )
    tier_results: Mapped[list["TierResult"]] = relationship(  # noqa: F821
        "TierResult", back_populates="run", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return (
            f"<EvaluationRun id={self.id} agent_type={self.agent_type!r}"
            f" status={self.status!r}>"
        )
