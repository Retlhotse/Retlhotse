"""Build the run manifest required by constitution Principle V."""

from __future__ import annotations

import importlib.metadata
import os
from datetime import datetime, timezone

from agenteval.models import BenchmarkDataset, LLMTarget


_JUDGE_MODEL_ENV = "AGENTEVAL_JUDGE_MODEL"
_DEFAULT_JUDGE_MODEL = "gpt-4o-mini"
_JUDGE_TEMPERATURE = 0
_JUDGE_SEED = 12345


def _deepeval_version() -> str:
    try:
        return importlib.metadata.version("deepeval")
    except importlib.metadata.PackageNotFoundError:
        return "unknown"


def build_run_manifest(
    target: LLMTarget,
    dataset: BenchmarkDataset,
    agent_type: str,
    tier_values: list[int],
    tier_kind: str,
    metrics: list[str],
) -> dict:
    """
    Build the run manifest dict per the data-model contract (constitution V).
    Judge model is pinned at temperature=0, seed=12345 for reproducibility.
    """
    judge_model = os.getenv(_JUDGE_MODEL_ENV, _DEFAULT_JUDGE_MODEL)
    return {
        "llm_target": {
            "name": target.name,
            "provider": target.provider,
            "model_identifier": target.model_identifier,
            "version_snapshot": target.version_snapshot,
        },
        "agent_type": agent_type,
        "dataset": {
            "name": dataset.name,
            "version": dataset.version,
            "content_hash": dataset.content_hash,
        },
        "judge_model": {
            "model_identifier": judge_model,
            "temperature": _JUDGE_TEMPERATURE,
            "seed": _JUDGE_SEED,
        },
        "scorer_versions": {
            "deepeval": _deepeval_version(),
            "metrics": metrics,
        },
        "tier_kind": tier_kind,
        "tiers_requested": tier_values,
        "started_at": datetime.now(timezone.utc).isoformat(),
    }
