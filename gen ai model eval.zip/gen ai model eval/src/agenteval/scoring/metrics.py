"""deepeval metric configuration registry per agent type."""

from __future__ import annotations

import os
from typing import Any

_JUDGE_MODEL_ENV = "AGENTEVAL_JUDGE_MODEL"
_DEFAULT_JUDGE_MODEL = "gpt-4o-mini"
_JUDGE_THRESHOLD = 0.5


def _judge_model() -> str:
    return os.getenv(_JUDGE_MODEL_ENV, _DEFAULT_JUDGE_MODEL)


def score_chatbot(input_text: str, actual_output: str) -> dict[str, float]:
    """Score a chatbot response using deepeval AnswerRelevancyMetric."""
    from deepeval.metrics import AnswerRelevancyMetric
    from deepeval.test_case import LLMTestCase

    test_case = LLMTestCase(input=input_text, actual_output=actual_output)
    metric = AnswerRelevancyMetric(
        threshold=_JUDGE_THRESHOLD, model=_judge_model(), include_reason=False
    )
    metric.measure(test_case)
    return {"answer_relevancy": round(float(metric.score), 4)}


def score_rag(
    input_text: str,
    actual_output: str,
    retrieval_context: list[str],
) -> dict[str, float]:
    """Score a RAG response for faithfulness and answer relevancy."""
    from deepeval.metrics import AnswerRelevancyMetric, FaithfulnessMetric
    from deepeval.test_case import LLMTestCase

    test_case = LLMTestCase(
        input=input_text,
        actual_output=actual_output,
        retrieval_context=retrieval_context,
    )
    faithfulness = FaithfulnessMetric(
        threshold=_JUDGE_THRESHOLD, model=_judge_model(), include_reason=False
    )
    relevancy = AnswerRelevancyMetric(
        threshold=_JUDGE_THRESHOLD, model=_judge_model(), include_reason=False
    )
    faithfulness.measure(test_case)
    relevancy.measure(test_case)
    return {
        "faithfulness": round(float(faithfulness.score), 4),
        "answer_relevancy": round(float(relevancy.score), 4),
    }


def score_tool_calling(
    input_text: str,
    actual_output: str,
    tools_called: list[dict[str, Any]],
    expected_tools: list[dict[str, Any]],
) -> dict[str, float]:
    """Score tool-calling using deepeval's deterministic ToolCorrectnessMetric."""
    from deepeval.metrics import ToolCorrectnessMetric
    from deepeval.test_case import LLMTestCase, ToolCall

    def _to_tool_call(t: dict) -> ToolCall:
        return ToolCall(name=t["name"], input_parameters=t.get("input", {}))

    test_case = LLMTestCase(
        input=input_text,
        actual_output=actual_output,
        tools_called=[_to_tool_call(t) for t in tools_called],
        expected_tools=[_to_tool_call(t) for t in expected_tools],
    )
    metric = ToolCorrectnessMetric()
    metric.measure(test_case)
    score = round(float(metric.score), 4)
    return {"tool_correctness": score}


AGENT_METRIC_NAMES: dict[str, list[str]] = {
    "chatbot": ["AnswerRelevancyMetric"],
    "rag": ["FaithfulnessMetric", "AnswerRelevancyMetric"],
    "tool_calling": ["ToolCorrectnessMetric"],
}
