"""
Main evaluation orchestrator.

Exports:
  register_model()      — onboard a new LLMTarget (FR-008)
  run_evaluation()      — run one agent type across tiers (FR-002/003/004/005/010)
  get_results()         — query stored runs (FR-006)
  compare_runs()        — side-by-side tier alignment (FR-009)
  load_dataset()        — register a benchmark dataset from disk
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Generator

from agenteval.config.model_config import ModelConfig, parse_model_config
from agenteval.config.tiers import tier_kind_for, tier_values_for
from agenteval.db.engine import session_scope
from agenteval.db.repository import ComparisonView, IncomparableRunsError, Repository, ResultFilter
from agenteval.models import BenchmarkDataset, EvaluationRun, LLMTarget, TierResult
from agenteval.providers.factory import build_provider
from agenteval.scoring.manifest import build_run_manifest
from agenteval.scoring.metrics import (
    AGENT_METRIC_NAMES,
    score_chatbot,
    score_rag,
    score_tool_calling,
)


def _hash_file(path: Path) -> str:
    sha = hashlib.sha256()
    sha.update(path.read_bytes())
    return sha.hexdigest()[:16]


def register_model(config_data: dict) -> LLMTarget:
    """Validate and persist a new LLMTarget. Raises on invalid config or duplicate name."""
    with session_scope() as session:
        repo = Repository(session)
        return repo.register_model(config_data)


def load_dataset(source_path: Path | str) -> BenchmarkDataset:
    """Register a benchmark dataset from a JSON file on disk."""
    path = Path(source_path)
    data = json.loads(path.read_text(encoding="utf-8"))
    content_hash = _hash_file(path)
    with session_scope() as session:
        repo = Repository(session)
        return repo.upsert_dataset(
            agent_type=data["agent_type"],
            name=data["name"],
            version=data["version"],
            content_hash=content_hash,
            source_path=str(path),
        )


def list_models() -> list[LLMTarget]:
    with session_scope() as session:
        return Repository(session).list_llm_targets()


def list_datasets(agent_type: str | None = None) -> list[BenchmarkDataset]:
    with session_scope() as session:
        return Repository(session).list_datasets(agent_type)


def get_results(filters: ResultFilter | None = None) -> list[EvaluationRun]:
    with session_scope() as session:
        return Repository(session).get_results(filters or ResultFilter())


def compare_runs(run_id_a: int, run_id_b: int) -> ComparisonView:
    with session_scope() as session:
        return Repository(session).compare_runs(run_id_a, run_id_b)


def run_evaluation(
    target_id: int,
    agent_type: str,
    dataset_id: int,
) -> Generator[TierResult, None, None]:
    """
    Evaluate *target_id* on *agent_type* across all tiers.

    Yields each TierResult immediately after it is persisted so the UI can
    render live progress.  Completed tiers are never lost if a later tier fails
    (FR-010 / SC-005).
    """
    tier_kind = tier_kind_for(agent_type)
    tier_values = tier_values_for(agent_type)
    metric_names = AGENT_METRIC_NAMES[agent_type]

    with session_scope() as session:
        repo = Repository(session)
        target = repo.get_llm_target(target_id)
        dataset = repo.get_dataset(dataset_id)

    if not target:
        raise ValueError(f"LLMTarget {target_id} not found.")
    if not dataset:
        raise ValueError(f"BenchmarkDataset {dataset_id} not found.")

    dataset_data = json.loads(Path(dataset.source_path).read_text(encoding="utf-8"))
    cfg = parse_model_config(json.loads(target.config_json))
    provider = build_provider(cfg)
    max_ctx = cfg.max_context_tokens

    manifest = build_run_manifest(
        target=target,
        dataset=dataset,
        agent_type=agent_type,
        tier_values=tier_values,
        tier_kind=tier_kind,
        metrics=metric_names,
    )

    with session_scope() as session:
        repo = Repository(session)
        run = repo.create_run(target_id, dataset_id, agent_type, manifest)
        run_id = run.id

    completed = 0
    failed_tiers: list[int] = []

    for tier_value in tier_values:
        try:
            tier_result = _execute_tier(
                provider=provider,
                agent_type=agent_type,
                dataset_data=dataset_data,
                tier_value=tier_value,
                tier_kind=tier_kind,
                max_context_tokens=max_ctx,
                run_id=run_id,
            )
            if tier_result.status == "scored":
                completed += 1
        except Exception as exc:
            with session_scope() as session:
                repo = Repository(session)
                tier_result = repo.persist_tier_result(
                    run_id=run_id,
                    tier_kind=tier_kind,
                    tier_value=tier_value,
                    status="failed",
                    skip_reason=str(exc),
                )
            failed_tiers.append(tier_value)

        yield tier_result

    if completed == len(tier_values):
        final_status = "completed"
    elif completed > 0:
        final_status = "partial"
    else:
        final_status = "failed"

    with session_scope() as session:
        Repository(session).update_run_status(run_id, final_status)


def _execute_tier(
    provider: Any,
    agent_type: str,
    dataset_data: dict,
    tier_value: int,
    tier_kind: str,
    max_context_tokens: int | None,
    run_id: int,
) -> TierResult:
    if tier_kind == "context_tokens" and max_context_tokens and tier_value > max_context_tokens:
        with session_scope() as session:
            return Repository(session).persist_tier_result(
                run_id=run_id,
                tier_kind=tier_kind,
                tier_value=tier_value,
                status="skipped",
                skip_reason=(
                    f"Payload of {tier_value} tokens exceeds model max context "
                    f"({max_context_tokens} tokens)."
                ),
            )

    if agent_type == "chatbot":
        metrics, measured = _run_chatbot(provider, dataset_data, tier_value)
    elif agent_type == "rag":
        metrics, measured = _run_rag(provider, dataset_data, tier_value)
    elif agent_type == "tool_calling":
        metrics, measured = _run_tool_calling(provider, dataset_data, tier_value)
    else:
        raise ValueError(f"Unknown agent type: {agent_type!r}")

    with session_scope() as session:
        return Repository(session).persist_tier_result(
            run_id=run_id,
            tier_kind=tier_kind,
            tier_value=tier_value,
            status="scored",
            metrics=metrics,
            measured_tokens=measured,
        )


def _run_chatbot(provider: Any, dataset_data: dict, target_tokens: int) -> tuple[dict, int | None]:
    from agenteval.agents.chatbot import build_filler_chunks, run_chatbot_tier

    test_cases = dataset_data.get("test_cases", [])
    if not test_cases:
        raise ValueError("Chatbot dataset has no test cases.")

    all_scores: list[dict] = []
    last_measured = None
    for tc in test_cases[:3]:
        filler = build_filler_chunks(tc)
        result = run_chatbot_tier(provider, tc, target_tokens, filler)
        scores = score_chatbot(result.input_text, result.actual_output)
        all_scores.append(scores)
        last_measured = result.measured_tokens

    merged: dict[str, float] = {}
    for key in all_scores[0]:
        merged[key] = round(sum(s[key] for s in all_scores) / len(all_scores), 4)
    return merged, last_measured


def _run_rag(provider: Any, dataset_data: dict, target_tokens: int) -> tuple[dict, int | None]:
    from agenteval.agents.rag import run_rag_tier

    test_cases = dataset_data.get("test_cases", [])
    knowledge_chunks = dataset_data.get("knowledge_chunks", [])
    if not test_cases:
        raise ValueError("RAG dataset has no test cases.")

    all_scores: list[dict] = []
    last_measured = None
    for tc in test_cases[:3]:
        result = run_rag_tier(provider, tc, knowledge_chunks, target_tokens)
        scores = score_rag(result.input_text, result.actual_output, result.retrieval_context)
        all_scores.append(scores)
        last_measured = result.measured_tokens

    merged: dict[str, float] = {}
    for key in all_scores[0]:
        merged[key] = round(sum(s[key] for s in all_scores) / len(all_scores), 4)
    return merged, last_measured


def _run_tool_calling(
    provider: Any, dataset_data: dict, tool_count: int
) -> tuple[dict, None]:
    from agenteval.agents.tool_calling import run_tool_calling_tier

    test_cases = dataset_data.get("test_cases", [])
    all_tools = dataset_data.get("base_tools", [])
    if not test_cases:
        raise ValueError("Tool-calling dataset has no test cases.")

    all_scores: list[dict] = []
    for tc in test_cases[:5]:
        result = run_tool_calling_tier(provider, tc, all_tools, tool_count)
        scores = score_tool_calling(
            result.input_text,
            result.actual_output,
            result.tools_called,
            result.expected_tools,
        )
        all_scores.append(scores)

    merged: dict[str, float] = {}
    for key in all_scores[0]:
        merged[key] = round(sum(s[key] for s in all_scores) / len(all_scores), 4)
    return merged, None
