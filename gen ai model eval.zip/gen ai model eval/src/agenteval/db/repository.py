"""Repository layer — all DB queries and persists go through here."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from agenteval.models import BenchmarkDataset, EvaluationRun, LLMTarget, TierResult
from agenteval.config.model_config import ConfigValidationError, DuplicateModelError, parse_model_config


@dataclass
class ResultFilter:
    llm_target_id: int | None = None
    agent_type: str | None = None
    tier_value: int | None = None
    date_from: datetime | None = None
    date_to: datetime | None = None


@dataclass
class ComparisonView:
    run_a: EvaluationRun
    run_b: EvaluationRun
    tiers: list[dict[str, Any]] = field(default_factory=list)


class IncomparableRunsError(Exception):
    """Raised when two runs have different agent_types and cannot be compared."""


class Repository:
    def __init__(self, session: Session) -> None:
        self._session = session

    # ── LLM Targets ──────────────────────────────────────────────────────────

    def register_model(self, config_data: dict) -> LLMTarget:
        """Validate, deduplicate, and persist a new LLMTarget."""
        cfg = parse_model_config(config_data)

        existing = self._session.scalar(
            select(LLMTarget).where(LLMTarget.name == cfg.name)
        )
        if existing:
            raise DuplicateModelError(
                f"A model named '{cfg.name}' is already registered. "
                "What to do: choose a unique name or delete the existing entry first."
            )

        target = LLMTarget(
            name=cfg.name,
            provider=cfg.provider,
            model_identifier=cfg.model_identifier,
            version_snapshot=cfg.version_snapshot,
            config_json=json.dumps(config_data),
            created_at=datetime.now(timezone.utc),
        )
        self._session.add(target)
        self._session.commit()
        return target

    def get_llm_target(self, target_id: int) -> LLMTarget | None:
        return self._session.get(LLMTarget, target_id)

    def list_llm_targets(self) -> list[LLMTarget]:
        return list(self._session.scalars(select(LLMTarget).order_by(LLMTarget.name)))

    # ── Datasets ──────────────────────────────────────────────────────────────

    def get_dataset(self, dataset_id: int) -> BenchmarkDataset | None:
        return self._session.get(BenchmarkDataset, dataset_id)

    def list_datasets(self, agent_type: str | None = None) -> list[BenchmarkDataset]:
        stmt = select(BenchmarkDataset).order_by(BenchmarkDataset.name)
        if agent_type:
            stmt = stmt.where(BenchmarkDataset.agent_type == agent_type)
        return list(self._session.scalars(stmt))

    def upsert_dataset(
        self,
        agent_type: str,
        name: str,
        version: str,
        content_hash: str,
        source_path: str,
    ) -> BenchmarkDataset:
        existing = self._session.scalar(
            select(BenchmarkDataset).where(
                BenchmarkDataset.agent_type == agent_type,
                BenchmarkDataset.name == name,
                BenchmarkDataset.version == version,
            )
        )
        if existing:
            return existing
        ds = BenchmarkDataset(
            agent_type=agent_type,
            name=name,
            version=version,
            content_hash=content_hash,
            source_path=source_path,
        )
        self._session.add(ds)
        self._session.commit()
        return ds

    # ── Evaluation Runs ───────────────────────────────────────────────────────

    def create_run(
        self,
        llm_target_id: int,
        dataset_id: int,
        agent_type: str,
        run_manifest: dict,
    ) -> EvaluationRun:
        run = EvaluationRun(
            llm_target_id=llm_target_id,
            dataset_id=dataset_id,
            agent_type=agent_type,
            status="running",
            run_manifest=json.dumps(run_manifest),
            started_at=datetime.now(timezone.utc),
        )
        self._session.add(run)
        self._session.commit()
        return run

    def get_run(self, run_id: int) -> EvaluationRun | None:
        return self._session.scalar(
            select(EvaluationRun)
            .options(selectinload(EvaluationRun.tier_results))
            .where(EvaluationRun.id == run_id)
        )

    def update_run_status(self, run_id: int, status: str) -> None:
        run = self._session.get(EvaluationRun, run_id)
        if run:
            run.status = status
            run.completed_at = datetime.now(timezone.utc)
            self._session.commit()

    # ── Tier Results ──────────────────────────────────────────────────────────

    def persist_tier_result(
        self,
        run_id: int,
        tier_kind: str,
        tier_value: int,
        status: str,
        metrics: dict | None = None,
        skip_reason: str | None = None,
        measured_tokens: int | None = None,
    ) -> TierResult:
        """Persist a single TierResult in its own transaction (FR-005, FR-010)."""
        tier = TierResult(
            run_id=run_id,
            tier_kind=tier_kind,
            tier_value=tier_value,
            status=status,
            skip_reason=skip_reason,
            metrics_json=json.dumps(metrics) if metrics else None,
            measured_tokens=measured_tokens,
            created_at=datetime.now(timezone.utc),
        )
        self._session.add(tier)
        self._session.commit()
        return tier

    def get_tier_results(self, run_id: int) -> list[TierResult]:
        return list(
            self._session.scalars(
                select(TierResult)
                .where(TierResult.run_id == run_id)
                .order_by(TierResult.tier_value)
            )
        )

    # ── Queries & Comparison ──────────────────────────────────────────────────

    def get_results(self, filters: ResultFilter) -> list[EvaluationRun]:
        """Retrieve runs matching the given filters, newest first (FR-006)."""
        stmt = (
            select(EvaluationRun)
            .options(selectinload(EvaluationRun.tier_results))
            .order_by(EvaluationRun.started_at.desc())
        )
        if filters.llm_target_id is not None:
            stmt = stmt.where(EvaluationRun.llm_target_id == filters.llm_target_id)
        if filters.agent_type:
            stmt = stmt.where(EvaluationRun.agent_type == filters.agent_type)
        if filters.date_from:
            stmt = stmt.where(EvaluationRun.started_at >= filters.date_from)
        if filters.date_to:
            stmt = stmt.where(EvaluationRun.started_at <= filters.date_to)
        return list(self._session.scalars(stmt))

    def compare_runs(self, run_id_a: int, run_id_b: int) -> ComparisonView:
        """Align TierResults from two runs by (tier_kind, tier_value) (FR-009)."""
        run_a = self.get_run(run_id_a)
        run_b = self.get_run(run_id_b)
        if run_a is None or run_b is None:
            raise ValueError("One or both run IDs do not exist.")
        if run_a.agent_type != run_b.agent_type:
            raise IncomparableRunsError(
                f"Cannot compare runs with different agent types: "
                f"'{run_a.agent_type}' vs '{run_b.agent_type}'. "
                "What to do: select two runs that share the same agent type."
            )

        tiers_a = {(t.tier_kind, t.tier_value): t for t in run_a.tier_results}
        tiers_b = {(t.tier_kind, t.tier_value): t for t in run_b.tier_results}
        all_keys = sorted(set(tiers_a) | set(tiers_b), key=lambda k: k[1])

        aligned = [
            {
                "tier_kind": k[0],
                "tier_value": k[1],
                "run_a": tiers_a.get(k),
                "run_b": tiers_b.get(k),
            }
            for k in all_keys
        ]
        return ComparisonView(run_a=run_a, run_b=run_b, tiers=aligned)
