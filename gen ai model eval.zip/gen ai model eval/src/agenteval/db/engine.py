"""SQLite engine, session factory, and database initialisation."""

from __future__ import annotations

import argparse
import os
from contextlib import contextmanager
from pathlib import Path
from typing import Generator

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from agenteval.models.base import Base
import agenteval.models  # noqa: F401 — registers ORM classes with Base

_DEFAULT_DB_PATH = Path(__file__).resolve().parents[4] / "data" / "evaluations.db"


def _get_db_url(db_path: Path | None = None) -> str:
    path = db_path or Path(os.getenv("AGENTEVAL_DB_PATH", str(_DEFAULT_DB_PATH)))
    path.parent.mkdir(parents=True, exist_ok=True)
    return f"sqlite:///{path}"


@event.listens_for(Engine, "connect")
def _set_sqlite_pragma(dbapi_conn, _connection_record) -> None:
    cursor = dbapi_conn.cursor()
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.close()


def make_engine(db_path: Path | None = None) -> Engine:
    return create_engine(_get_db_url(db_path), connect_args={"check_same_thread": False})


def init_db(db_path: Path | None = None) -> Engine:
    """Create all tables. Safe to call multiple times (no-op if tables exist)."""
    engine = make_engine(db_path)
    Base.metadata.create_all(engine)
    return engine


_engine: Engine | None = None
_SessionLocal: sessionmaker | None = None


def get_engine() -> Engine:
    global _engine
    if _engine is None:
        _engine = init_db()
    return _engine


def get_session_factory() -> sessionmaker:
    global _SessionLocal
    if _SessionLocal is None:
        _SessionLocal = sessionmaker(bind=get_engine(), expire_on_commit=False)
    return _SessionLocal


@contextmanager
def session_scope() -> Generator[Session, None, None]:
    """Provide a transactional scope; commits on success, rolls back on error."""
    factory = get_session_factory()
    session: Session = factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Manage the AgentEval SQLite database")
    parser.add_argument("--init", action="store_true", help="Create tables")
    parser.add_argument("--db-path", type=Path, default=None)
    args = parser.parse_args()
    if args.init:
        engine = init_db(args.db_path)
        print(f"Database initialised at: {engine.url}")
    else:
        parser.print_help()
