"""Build provider instances from onboarding config."""

from __future__ import annotations

import os

from agenteval.config.model_config import ModelConfig
from agenteval.providers.base import BaseProvider, ProviderError


class AnthropicProvider(BaseProvider):
    def __init__(
        self, model_identifier: str, api_key: str, base_url: str | None = None, **kwargs
    ) -> None:
        super().__init__(model_identifier, **kwargs)
        try:
            import anthropic

            self._client = anthropic.Anthropic(api_key=api_key, base_url=base_url)
        except ImportError as exc:
            raise ProviderError("anthropic package is not installed.") from exc
        self._max_tokens = kwargs.get("max_tokens", 1024)

    def generate(self, prompt: str) -> str:
        try:
            msg = self._client.messages.create(
                model=self._model_identifier,
                max_tokens=self._max_tokens,
                messages=[{"role": "user", "content": prompt}],
            )
            return msg.content[0].text
        except Exception as exc:
            raise ProviderError(f"Anthropic call failed: {exc}") from exc

    def generate_with_tools(self, prompt: str, tools: list[dict]) -> tuple[str, list[dict]]:
        anthropic_tools = [
            {
                "name": t["name"],
                "description": t.get("description", ""),
                "input_schema": t.get("input_schema", {"type": "object", "properties": {}}),
            }
            for t in tools
        ]
        try:
            msg = self._client.messages.create(
                model=self._model_identifier,
                max_tokens=self._max_tokens,
                tools=anthropic_tools,
                messages=[{"role": "user", "content": prompt}],
            )
            called = [
                {"name": b.name, "input": b.input}
                for b in msg.content
                if b.type == "tool_use"
            ]
            text_blocks = [b.text for b in msg.content if b.type == "text"]
            return " ".join(text_blocks), called
        except Exception as exc:
            raise ProviderError(f"Anthropic tool call failed: {exc}") from exc


class OpenAIProvider(BaseProvider):
    def __init__(
        self, model_identifier: str, api_key: str, base_url: str | None = None, **kwargs
    ) -> None:
        super().__init__(model_identifier, **kwargs)
        try:
            from openai import OpenAI

            self._client = OpenAI(api_key=api_key, base_url=base_url)
        except ImportError as exc:
            raise ProviderError("openai package is not installed.") from exc
        self._max_tokens = kwargs.get("max_tokens", 1024)

    def generate(self, prompt: str) -> str:
        try:
            resp = self._client.chat.completions.create(
                model=self._model_identifier,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=self._max_tokens,
            )
            return resp.choices[0].message.content or ""
        except Exception as exc:
            raise ProviderError(f"OpenAI call failed: {exc}") from exc

    def generate_with_tools(self, prompt: str, tools: list[dict]) -> tuple[str, list[dict]]:
        openai_tools = [
            {
                "type": "function",
                "function": {
                    "name": t["name"],
                    "description": t.get("description", ""),
                    "parameters": t.get("input_schema", {"type": "object", "properties": {}}),
                },
            }
            for t in tools
        ]
        try:
            resp = self._client.chat.completions.create(
                model=self._model_identifier,
                messages=[{"role": "user", "content": prompt}],
                tools=openai_tools,
                max_tokens=self._max_tokens,
            )
            msg = resp.choices[0].message
            called = []
            if msg.tool_calls:
                import json

                called = [
                    {"name": tc.function.name, "input": json.loads(tc.function.arguments or "{}")}
                    for tc in msg.tool_calls
                ]
            return msg.content or "", called
        except Exception as exc:
            raise ProviderError(f"OpenAI tool call failed: {exc}") from exc


class CustomHttpProvider(BaseProvider):
    """Generic OpenAI-compatible HTTP endpoint."""

    def __init__(self, model_identifier: str, api_key: str, endpoint: str, **kwargs) -> None:
        super().__init__(model_identifier, **kwargs)
        try:
            from openai import OpenAI

            self._client = OpenAI(api_key=api_key, base_url=endpoint)
        except ImportError as exc:
            raise ProviderError("openai package required for custom HTTP provider.") from exc
        self._max_tokens = kwargs.get("max_tokens", 1024)

    def generate(self, prompt: str) -> str:
        try:
            resp = self._client.chat.completions.create(
                model=self._model_identifier,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=self._max_tokens,
            )
            return resp.choices[0].message.content or ""
        except Exception as exc:
            raise ProviderError(f"Custom HTTP call failed: {exc}") from exc

    def generate_with_tools(self, prompt: str, tools: list[dict]) -> tuple[str, list[dict]]:
        raise ProviderError("Tool calling not supported for custom HTTP provider in v1.")


def _resolve_api_key(cfg: ModelConfig) -> str:
    """Return the API key from the config — raw value takes precedence over env var lookup."""
    if cfg.credentials.api_key:
        return cfg.credentials.api_key
    env_var = cfg.credentials.api_key_env or ""
    key = os.environ.get(env_var, "")
    if not key:
        raise ProviderError(
            f"Environment variable '{env_var}' is not set or empty. "
            "What to do: set the variable before starting the application, "
            "or supply 'api_key' directly in the config."
        )
    return key


def build_provider(cfg: ModelConfig) -> BaseProvider:
    """Instantiate the appropriate provider from a validated ModelConfig."""
    api_key = _resolve_api_key(cfg)

    extra = {}
    if cfg.request_params.max_tokens:
        extra["max_tokens"] = cfg.request_params.max_tokens

    if cfg.provider == "anthropic":
        return AnthropicProvider(
            cfg.model_identifier, api_key=api_key, base_url=cfg.endpoint, **extra
        )
    if cfg.provider in ("openai", "azure_openai"):
        return OpenAIProvider(
            cfg.model_identifier,
            api_key=api_key,
            base_url=cfg.endpoint,
            **extra,
        )
    if cfg.provider == "custom":
        return CustomHttpProvider(
            cfg.model_identifier,
            api_key=api_key,
            endpoint=cfg.endpoint,  # type: ignore[arg-type]
            **extra,
        )
    raise ProviderError(
        f"Unsupported provider: '{cfg.provider}'. "
        "What to do: use one of anthropic, openai, azure_openai, google, custom."
    )
