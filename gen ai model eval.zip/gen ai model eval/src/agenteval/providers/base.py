"""Abstract base for all LLM provider adapters."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class ProviderError(Exception):
    """Raised when a provider call fails."""


class BaseProvider(ABC):
    """Common interface for calling a target LLM and wrapping it for deepeval."""

    def __init__(self, model_identifier: str, **kwargs: Any) -> None:
        self._model_identifier = model_identifier
        self._kwargs = kwargs

    @property
    def model_identifier(self) -> str:
        return self._model_identifier

    @abstractmethod
    def generate(self, prompt: str) -> str:
        """Call the model and return the response text."""

    @abstractmethod
    def generate_with_tools(
        self,
        prompt: str,
        tools: list[dict],
    ) -> tuple[str, list[dict]]:
        """
        Call the model with a tool catalog.
        Returns (response_text, tools_actually_called).
        tools_actually_called is a list of dicts: {"name": ..., "input": ...}
        """

    def get_model_name(self) -> str:
        return self._model_identifier
