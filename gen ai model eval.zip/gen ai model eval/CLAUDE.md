# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

<!-- SPECKIT START -->
Active feature: **001-llm-agent-eval** — LLM Agent Evaluation Framework.
For technologies, project structure, and design details, read the current plan:
`specs/001-llm-agent-eval/plan.md` (and its `research.md`, `data-model.md`, `contracts/`,
`quickstart.md`).

Stack: Python 3.11+ · Streamlit (UI) · deepeval (metrics) · SQLite + SQLAlchemy.
Evaluates Chatbot / RAG / Tool-Calling agents across context-token tiers
(5k/10k/30k/50k) and tool-count tiers (5/15/30/50). Models onboarded via JSON config.
<!-- SPECKIT END -->

## Development Commands

The package uses a `src/` layout, so it must be installed (editable) or have `src/` on
`PYTHONPATH` before `import agenteval` resolves.

```powershell
pip install -e .                          # editable install (preferred — resolves `agenteval`)
# or, without installing:  $env:PYTHONPATH = "src"

python -m agenteval.db.engine --init      # create data/agenteval.db with all tables (run once)
streamlit run app/Home.py                 # launch the multipage dashboard

pytest                                    # full suite; enforces --cov-fail-under=80 (constitution II)
pytest tests/unit/test_repository.py      # one file
pytest tests/unit/test_repository.py::TestPersistTierResult::test_x   # one test
pytest tests/benchmark/                   # perf gate: ≥500 payloads/min (constitution IV)

ruff check . ; black --check .            # lint + format gates (constitution I)
```

There is no live-API test: every provider test uses mocks/recorded fixtures (constitution II).
Running an actual evaluation needs a credential — either an env var named by the config's
`api_key_env`, or a raw `api_key` embedded in the config (see Onboarding below).

## Runtime Architecture

The application is a thin Streamlit UI over a layered Python service package. **All data access
goes through `Repository`; pages and the runner never touch the ORM session directly.**

```
app/pages/*.py  →  agenteval/runner.py  →  Repository (db/)  →  SQLAlchemy ORM (models/)
                          │
                          ├─ config/      ModelConfig validation + tier definitions + tiktoken counting
                          ├─ providers/   factory builds Anthropic/OpenAI/CustomHttp client from config
                          ├─ agents/      per-archetype payload assembly + model call (chatbot/rag/tool_calling)
                          └─ scoring/     deepeval metrics + run manifest
```

Key cross-cutting patterns (each requires reading several files to grasp):

- **`runner.py` is the orchestrator and the only public entry point** the UI calls
  (`register_model`, `load_dataset`, `run_evaluation`, `get_results`, `compare_runs`). It wraps
  every operation in `db.engine.session_scope()`.
- **`run_evaluation()` is a generator** that `yield`s each `TierResult` immediately after it is
  persisted in **its own transaction**. This drives live UI updates *and* guarantees completed
  tiers survive a later tier's failure (FR-010). Final run status is `completed` / `partial` /
  `failed` based on how many tiers scored. The Run Evaluation page iterates this generator and
  re-renders an `st.empty()` table per tier.
- **Tier system (`config/tiers.py`)** is the core domain concept. `tier_kind_for(agent_type)`
  returns `context_tokens` (chatbot/rag → 5k/10k/30k/50k) or `tool_count` (tool_calling →
  5/15/30/50). Context tiers exceeding the model's `max_context_tokens` are persisted as
  `skipped`, not run (SC-006). `build_context_payload()` uses tiktoken to pad filler text up to a
  target token count.
- **Provider factory (`providers/factory.py`)** maps `provider` → client adapter. `anthropic`,
  `openai`/`azure_openai`, and `custom` all accept an `endpoint`/`base_url`, so on-prem
  OpenAI-/Anthropic-compatible deployments work. Tool-calling is unsupported on `CustomHttpProvider`.
- **Scoring (`scoring/metrics.py`)** picks deepeval metrics per archetype: chatbot → answer
  relevancy; RAG → faithfulness + answer relevancy; tool_calling → `ToolCorrectnessMetric`
  (deterministic). `AGENT_METRIC_NAMES` is the registry. Every run records a manifest
  (`scoring/manifest.py`) pinning the judge model at temperature 0 + fixed seed (constitution V).
- **Datasets live on disk** under `datasets/<agent_type>/v*.json`; `load_dataset()` hashes the file
  and upserts a `BenchmarkDataset` row pointing at the path. The runner re-reads the JSON at run time.

### Onboarding config (model registration)

A model is registered by uploading a JSON config (Onboard Model page → `register_model`). Validation
is **Pydantic-only** (`config/model_config.py` → `parse_model_config`); the JSON Schema under
`contracts/` is documentation, not an enforced runtime gate. Credentials accept **exactly one** of:

- `api_key_env` — name of an environment variable holding the key (key value never stored), or
- `api_key` — the raw token inline, for on-prem models without env-var provisioning.

> ⚠️ The whole config (including a raw `api_key`) is persisted to SQLite in `LLMTarget.config_json`.
> This conflicts with the constitution's "keys by env-var name only, never stored as values" rule,
> and the `contracts/model-config.schema.json` still requires `api_key_env` only — both are now out
> of sync with the code and should be reconciled.

## Project Overview

This is a **generative AI model evaluation** project built using **spec-kit** (SDD — Spec-Driven Development) with Claude as the AI integration. Features are developed through a structured pipeline: specify → clarify → plan → tasks → analyze → implement.

- spec-kit version: `0.10.3`
- Integration: `claude` (PowerShell script invocation)
- Feature numbering: `sequential` (e.g., `001-feature-name`, `002-feature-name`)
- Features are created under `specs/`

## Before Starting the First Feature

1. Fill in `.specify/memory/constitution.md` with project governance principles (use `/speckit-constitution` to do this interactively). Constitution rules are non-negotiable — violations are always CRITICAL findings in `/speckit-analyze`.
2. Run `/speckit-specify <description>` to create the first feature.

## SDD Workflow Commands

Run these skills in order for each new feature:

| Step | Skill | When to use |
|------|-------|-------------|
| 1 | `/speckit-specify <description>` | Create a new feature spec in `specs/NNN-name/spec.md` |
| 2 | `/speckit-clarify` | Reduce ambiguity in the spec (max 5 questions) — run before planning |
| 3 | `/speckit-plan` | Generate `plan.md`, `research.md`, `data-model.md`, `contracts/`, `quickstart.md` |
| 4 | `/speckit-tasks` | Generate `tasks.md` with ordered, phase-organized task list |
| 5 | `/speckit-analyze` | Cross-artifact quality check (read-only, identifies gaps before coding) |
| 6 | `/speckit-implement` | Execute all tasks in `tasks.md` phase-by-phase |

The full SDD cycle can also be run as a single workflow via `speckit` workflow (specify → gate → plan → gate → tasks → implement).

## Active Feature State

`.specify/feature.json` tracks the active feature so downstream commands (`/speckit-plan`, `/speckit-tasks`, etc.) can locate it without a branch name convention. When switching between features, be aware that only one feature is "active" at a time.

## Key Scripts

The `.specify/scripts/powershell/` directory contains helper scripts used internally by the skill commands — you generally do not need to invoke them manually.

| Script | Purpose |
|--------|---------|
| `check-prerequisites.ps1 -Json` | Returns `FEATURE_DIR`, `FEATURE_SPEC`, `IMPL_PLAN`, `TASKS`, `AVAILABLE_DOCS` |
| `setup-plan.ps1 -Json` | Returns `FEATURE_SPEC`, `IMPL_PLAN`, `SPECS_DIR`, `BRANCH` |
| `setup-tasks.ps1 -Json` | Returns `FEATURE_DIR`, `TASKS_TEMPLATE`, `AVAILABLE_DOCS` |
| `create-new-feature.ps1` | Used during specify to scaffold a new feature directory |

## Project Structure for Each Feature

```
specs/
  NNN-feature-name/
    spec.md            # Business requirements (written by /speckit-specify)
    plan.md            # Technical design (written by /speckit-plan)
    research.md        # Technology decisions and rationale
    data-model.md      # Entities and relationships
    contracts/         # Interface/API contracts
    quickstart.md      # End-to-end validation guide
    tasks.md           # Ordered implementation checklist (written by /speckit-tasks)
    checklists/
      requirements.md  # Spec quality checklist (created by /speckit-specify)
```

## Architecture Notes

### Artifact Responsibilities

- **spec.md** — what users need and why; no implementation details; written for non-technical stakeholders
- **plan.md** — tech stack, architecture, file structure; primary technical reference for `/speckit-tasks` and `/speckit-implement`
- **tasks.md** — actionable checklist organized by phase (Setup → Foundational → User Stories → Polish); every task has an ID (T001...), optional `[P]` parallel marker, and `[USN]` story label; tasks marked `[X]` when complete
- **CLAUDE.md** — the `<!-- SPECKIT START/END -->` block is auto-managed by the `agent-context` extension after each `/speckit-plan` run; do not edit inside those markers manually

### Extensions

The `agent-context` extension is installed (`.specify/extensions.yml`). It fires optional hooks after `/speckit-specify` and `/speckit-plan` to refresh the `<!-- SPECKIT START/END -->` block above. When prompted by the hook, run `/speckit-agent-context-update`.
