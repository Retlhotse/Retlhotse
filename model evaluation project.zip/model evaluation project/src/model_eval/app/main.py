"""Streamlit application shell (FR-070).

Entry point: ``streamlit run src/model_eval/app/main.py``. Initializes the
database, reaps stale runs, and renders the landing page. The three pages
(Onboarding, Evaluation, Results) live in ``app/pages/`` and are added in
their respective user-story phases; Streamlit auto-discovers them.
"""

from __future__ import annotations

import os

import streamlit as st

from model_eval.db.repository import Repository


def db_path() -> str:
    return os.environ.get("MODEL_EVAL_DB_PATH", "model_eval.sqlite3")


@st.cache_resource
def _bootstrap() -> dict:
    """Initialize DB + reap stale runs once per process."""
    with Repository(db_path()) as repo:
        reaped = repo.reap_stale_running()
    return {"reaped": reaped, "db": db_path()}


def main() -> None:
    st.set_page_config(page_title="Model Evaluation Platform", page_icon="🧪", layout="wide")
    state = _bootstrap()

    st.title("Enterprise Model Evaluation Platform")
    st.caption("Any provider, local or remote • one connectivity layer • fail-loud")

    st.markdown(
        """
        Use the pages in the sidebar:

        1. **Onboarding** — register a model from any provider via JSON config.
        2. **Evaluation** — run the combined LLM suite or text-extraction.
        3. **Results** — browse and compare past runs.
        """
    )

    with st.expander("Status", expanded=False):
        st.write(f"Database: `{state['db']}`")
        if state["reaped"]:
            st.info(f"Reaped {state['reaped']} interrupted run(s) from a prior session.")


if __name__ == "__main__":
    main()
