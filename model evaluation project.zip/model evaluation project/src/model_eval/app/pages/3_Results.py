"""Results page (US4, FR-062/063).

Lists historical runs, drills into per-axis-point / per-document scores, and
compares two runs of the same suite type on identical axes. API keys are never
shown here (FR-009) — the Results page reads scores, never credentials.
"""

from __future__ import annotations

import os

import streamlit as st

from model_eval.db.repository import Repository
from model_eval.db.results import (
    axis_drilldown,
    compare_axis,
    document_drilldown,
    list_run_summaries,
)


def db_path() -> str:
    return os.environ.get("MODEL_EVAL_DB_PATH", "model_eval.sqlite3")


def render() -> None:
    st.set_page_config(page_title="Results", page_icon="📊", layout="wide")
    st.header("Results")

    with Repository(db_path()) as repo:
        summaries = list_run_summaries(repo)
    if not summaries:
        st.info("No runs yet. Start one on the Evaluation page.")
        return

    st.subheader("Runs")
    st.dataframe(
        [
            {
                "run": s.run_id,
                "model": s.model_name,
                "suite": s.suite_type,
                "status": s.status,
                "started": s.started_at,
                "ended": s.ended_at,
            }
            for s in summaries
        ],
        use_container_width=True,
        hide_index=True,
    )

    _render_drilldown(summaries)
    st.divider()
    _render_compare(summaries)


def _render_drilldown(summaries) -> None:
    st.subheader("Drill-down")
    run_id = st.selectbox("Run", [s.run_id for s in summaries], key="drill_run")
    summary = next(s for s in summaries if s.run_id == run_id)
    with Repository(db_path()) as repo:
        if summary.suite_type == "llm-combined":
            rows = axis_drilldown(repo, run_id)
        else:
            rows = document_drilldown(repo, run_id)
    if rows:
        st.dataframe(rows, use_container_width=True, hide_index=True)
    else:
        st.info("No result rows for this run.")


def _render_compare(summaries) -> None:
    st.subheader("Compare two runs (same suite, same axis)")
    combined = [s.run_id for s in summaries if s.suite_type == "llm-combined"]
    if len(combined) < 2:
        st.caption("Need at least two combined LLM-suite runs to compare.")
        return
    col_a, col_b = st.columns(2)
    run_a = col_a.selectbox("Run A", combined, key="cmp_a")
    run_b = col_b.selectbox("Run B", combined, index=1, key="cmp_b")
    if run_a == run_b:
        st.caption("Pick two different runs.")
        return
    with Repository(db_path()) as repo:
        try:
            rows = compare_axis(repo, run_a, run_b)
        except ValueError as exc:
            st.error(str(exc))
            return
    st.dataframe(rows, use_container_width=True, hide_index=True)


render()
