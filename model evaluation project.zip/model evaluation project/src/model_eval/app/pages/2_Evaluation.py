"""Evaluation page (US2, FR-020/071/072/073).

Exposes the combined LLM suite as a single action (chatbot + RAG + tool-calling,
not individually selectable). Checks preconditions (capability, judge, dataset
presence), enqueues a run, and shows live status from the background worker.
Text-extraction is added as a separate action in US3 (T046).
"""

from __future__ import annotations

import json
import os

import streamlit as st

from model_eval.config.judge import get_global_judge
from model_eval.datasets.registry import DatasetRegistry, repository_resolver
from model_eval.db.repository import Repository
from model_eval.eval.extraction.runner import make_extraction_handler
from model_eval.eval.llm_suite.base import CONTEXT_SIZES, TOOL_COUNTS
from model_eval.eval.llm_suite.handler import make_llm_combined_handler
from model_eval.eval.runner import RunWorker


def db_path() -> str:
    return os.environ.get("MODEL_EVAL_DB_PATH", "model_eval.sqlite3")


@st.cache_resource
def worker() -> RunWorker:
    w = RunWorker(
        db_path(),
        {
            "llm-combined": make_llm_combined_handler(),
            "text-extraction": make_extraction_handler(),
        },
    )
    w.start()
    return w


def _caps(row) -> dict:
    try:
        return json.loads(row["capabilities"])
    except Exception:  # noqa: BLE001
        return {}


def render() -> None:
    st.set_page_config(page_title="Evaluation", page_icon="🧪", layout="wide")
    st.header("Evaluation")
    worker()  # ensure the background worker is running

    with Repository(db_path()) as repo:
        chat_models = [r for r in repo.list_models() if _caps(r).get("chat_suite")]
        judge = get_global_judge(repo)
        names = [m["name"] for m in chat_models]

    st.subheader("Combined LLM suite")
    st.caption(
        f"Runs chatbot + RAG (context windows {list(CONTEXT_SIZES)}) and "
        f"tool-calling (tool counts {list(TOOL_COUNTS)}) as one job (FR-020)."
    )

    if not names:
        st.info("Onboard a chat-capable model first.")
    else:
        model_name = st.selectbox("Model under test", names)
        _render_dataset_report()
        judge_ok = judge is not None
        if not judge_ok:
            st.warning("No global judge configured — set one on the Onboarding page (FR-041).")
        if st.button("Run combined LLM suite", type="primary", disabled=not judge_ok):
            _enqueue(model_name)

    st.divider()
    _render_extraction_action()

    st.divider()
    _render_runs()


def _render_extraction_action() -> None:
    st.subheader("Text-extraction (standalone)")
    st.caption("Scores document-to-Markdown accuracy with OmniDocBench (FR-050/054).")
    with Repository(db_path()) as repo:
        doc_models = [r for r in repo.list_models() if _caps(r).get("extraction")]
    names = [m["name"] for m in doc_models]
    if not names:
        st.info("Onboard a document/extraction-capable model to run this evaluation.")
        return
    model_name = st.selectbox("Document-capable model", names, key="extract_model")
    if st.button("Run text-extraction"):
        _enqueue_extraction(model_name)


def _enqueue_extraction(model_name: str) -> None:
    with Repository(db_path()) as repo:
        model = next(m for m in repo.list_models() if m["name"] == model_name)
        snapshot = {
            "model": {"name": model["name"], "provider": model["provider"], "model": model["model"]},
            "scoring_method": "omnidocbench_end2end",
        }
        run_id = repo.create_run(
            model_config_id=model["id"], suite_type="text-extraction", config_snapshot=snapshot
        )
    st.success(f"Queued text-extraction run #{run_id}.")


def _render_dataset_report() -> None:
    with Repository(db_path()) as repo:
        registry = DatasetRegistry(repository_resolver(repo))
        report = registry.report("llm-combined")
    rows = [{"dataset": s.name, "present": s.present, "path": s.local_path} for s in report]
    st.caption("Required datasets (must be present locally — FR-073):")
    st.dataframe(rows, use_container_width=True, hide_index=True)


def _enqueue(model_name: str) -> None:
    with Repository(db_path()) as repo:
        model = next(m for m in repo.list_models() if m["name"] == model_name)
        snapshot = {
            "model": {"name": model["name"], "provider": model["provider"], "model": model["model"]},
            "axis": {"context_window": list(CONTEXT_SIZES), "tool_count": list(TOOL_COUNTS)},
            "scoring_method": "bfcl_ast_native",
            "reference_tokenizer": "tiktoken/cl100k_base",
        }
        run_id = repo.create_run(
            model_config_id=model["id"], suite_type="llm-combined", config_snapshot=snapshot
        )
    st.success(f"Queued run #{run_id}. Watch status below.")


def _render_runs() -> None:
    st.subheader("Runs")
    with Repository(db_path()) as repo:
        runs = repo.list_runs()
    if not runs:
        st.info("No runs yet.")
        return
    rows = []
    for r in runs:
        progress = json.loads(r["progress"]) if r["progress"] else {}
        rows.append(
            {
                "run": r["id"],
                "suite": r["suite_type"],
                "status": r["status"],
                "progress": f"{progress.get('done', 0)}/{progress.get('total', '?')}",
                "reason": r["failure_reason"] or "",
            }
        )
    st.dataframe(rows, use_container_width=True, hide_index=True)
    if st.button("Refresh"):
        st.rerun()


render()
