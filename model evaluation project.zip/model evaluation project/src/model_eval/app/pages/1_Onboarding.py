"""Onboarding page (US1, FR-004/005/006/008/009).

Register a model from any LangChain-supported provider via a JSON config.
Shows copyable templates, submits the config through the onboarding service
(validate → persist), reports field-level errors, and lists onboarded models
with masked credentials.
"""

from __future__ import annotations

import json
import os

import streamlit as st

from model_eval.config.judge import (
    JudgeConfigError,
    clear_global_judge,
    get_global_judge,
    set_global_judge,
)
from model_eval.config.onboarding import OnboardingError, onboard_model
from model_eval.config.secret import SecretRef
from model_eval.config.templates import template_json
from model_eval.db.repository import Repository


def db_path() -> str:
    return os.environ.get("MODEL_EVAL_DB_PATH", "model_eval.sqlite3")


def _capabilities(row) -> dict:
    try:
        return json.loads(row["capabilities"])
    except Exception:  # noqa: BLE001
        return {}


def render() -> None:
    st.set_page_config(page_title="Onboarding", page_icon="➕", layout="wide")
    st.header("Onboarding")
    st.caption("Register a model from any provider — local or remote — via JSON config.")

    with st.expander("Show config templates", expanded=False):
        tab_local, tab_remote, tab_azure = st.tabs(
            ["Local (OpenAI-compatible)", "Remote provider", "Azure OpenAI"]
        )
        with tab_local:
            st.code(template_json("local"), language="json")
        with tab_remote:
            st.code(template_json("remote"), language="json")
        with tab_azure:
            st.code(template_json("azure"), language="json")

    st.subheader("Submit a configuration")
    raw_text = st.text_area(
        "Model configuration (JSON)",
        height=260,
        placeholder='{ "name": "...", "provider": "openai", "model": "...", ... }',
    )
    if st.button("Onboard model", type="primary"):
        _handle_submit(raw_text)

    st.divider()
    _render_model_list()

    st.divider()
    _render_judge_config()


def _handle_submit(raw_text: str) -> None:
    if not raw_text.strip():
        st.warning("Paste a JSON configuration first.")
        return
    try:
        data = json.loads(raw_text)
    except json.JSONDecodeError as exc:
        st.error(f"Invalid JSON: {exc}")
        return
    try:
        with Repository(db_path()) as repo:
            result = onboard_model(repo, data)
    except OnboardingError as exc:
        # Field-naming validation / duplicate-name message (nothing persisted).
        st.error(str(exc))
        return
    st.success(f"Onboarded '{result.name}' ({result.provider}). It is now selectable for evaluation.")


def _render_model_list() -> None:
    st.subheader("Onboarded models")
    with Repository(db_path()) as repo:
        rows = repo.list_models()
    if not rows:
        st.info("No models onboarded yet.")
        return
    table = []
    for r in rows:
        caps = _capabilities(r)
        table.append(
            {
                "name": r["name"],
                "provider": r["provider"],
                "model": r["model"],
                "endpoint": r["endpoint_url"],
                "api_key": SecretRef(r["api_key"]).masked(),  # never plaintext (FR-009)
                "chat_suite": caps.get("chat_suite", False),
                "extraction": caps.get("extraction", False),
                "max_context": r["max_context_window"],
            }
        )
    st.dataframe(table, use_container_width=True, hide_index=True)


def _render_judge_config() -> None:
    st.subheader("Global judge")
    st.caption(
        "A single, explicitly-configured model (any provider) grades all LLM-as-judge "
        "metrics. Without it, the LLM suite's chatbot/RAG metrics will not run (FR-041)."
    )
    with Repository(db_path()) as repo:
        chat_models = [
            r["name"] for r in repo.list_models() if _capabilities(r).get("chat_suite")
        ]
        current = get_global_judge(repo)
        current_name = current["name"] if current else None

    if not chat_models:
        st.info("Onboard a chat-capable model to designate it as judge.")
        return

    options = ["(none)", *chat_models]
    idx = options.index(current_name) if current_name in options else 0
    choice = st.selectbox("Judge model", options, index=idx)
    if st.button("Set judge"):
        with Repository(db_path()) as repo:
            if choice == "(none)":
                clear_global_judge(repo)
                st.success("Judge cleared. LLM-as-judge metrics are disabled.")
            else:
                model = next(m for m in repo.list_models() if m["name"] == choice)
                try:
                    set_global_judge(repo, model["id"])
                    st.success(f"Judge set to '{choice}'.")
                except JudgeConfigError as exc:
                    st.error(str(exc))


render()
