"""Onboarding service: validate a JSON config, then persist it (FR-005/007/007a).

Single entry point used by the Onboarding page and tests. Validation runs first
(pydantic, FR-005/006); only a valid config is persisted. The repository's unique
constraint enforces unique logical names (FR-007a). Nothing is persisted on any
failure.
"""

from __future__ import annotations

from dataclasses import dataclass

from model_eval.config.schema import ModelConfig, parse_model_config
from model_eval.db.repository import Repository


class OnboardingError(ValueError):
    """A human-facing onboarding failure (validation or uniqueness)."""


@dataclass(frozen=True)
class OnboardResult:
    model_id: int
    name: str
    provider: str


def onboard_model(repo: Repository, raw: dict) -> OnboardResult:
    """Validate ``raw`` and persist it; raise OnboardingError on any problem.

    On validation failure the pydantic error is wrapped with a field-naming
    message (FR-005). On a duplicate name the repository raises and we surface a
    clear message (FR-007a). Either way, nothing is persisted.
    """
    try:
        cfg = parse_model_config(raw)
    except Exception as exc:  # pydantic.ValidationError or type errors
        raise OnboardingError(_format_validation_error(exc)) from exc

    try:
        model_id = repo.add_model(
            name=cfg.name,
            provider=cfg.provider,
            model=cfg.model,
            endpoint_url=cfg.endpoint_url,
            api_key=cfg.api_key,
            azure_deployment=cfg.azure_deployment,
            azure_api_version=cfg.azure_api_version,
            capabilities={
                "chat_suite": cfg.capabilities.chat_suite,
                "extraction": cfg.capabilities.extraction,
            },
            max_context_window=cfg.max_context_window,
        )
    except ValueError as exc:  # unique-name collision (FR-007a)
        raise OnboardingError(str(exc)) from exc

    return OnboardResult(model_id=model_id, name=cfg.name, provider=cfg.provider)


def _format_validation_error(exc: Exception) -> str:
    """Turn a pydantic ValidationError into a concise field-naming message."""
    errors = getattr(exc, "errors", None)
    if not callable(errors):
        return f"invalid configuration: {exc}"
    parts: list[str] = []
    for err in exc.errors():
        loc = ".".join(str(p) for p in err.get("loc", ()) if p not in ("root",))
        msg = err.get("msg", "invalid")
        parts.append(f"{loc or '(root)'}: {msg}")
    return "invalid configuration — " + "; ".join(parts)


__all__ = ["ModelConfig", "OnboardResult", "OnboardingError", "onboard_model"]
