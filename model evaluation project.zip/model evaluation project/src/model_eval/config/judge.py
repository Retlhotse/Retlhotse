"""Global judge configuration service (FR-040/041, Constitution Principle III).

The judge is a single, globally-configured model used for all LLM-as-judge
metrics. It may be **any provider** (local or remote) — what matters is that
exactly one judge is explicitly configured and chat-capable, never an
unspecified default. Persistence lives in the repository (judge_config
singleton).
"""

from __future__ import annotations

import json


class JudgeConfigError(ValueError):
    """An invalid global-judge selection."""


def set_global_judge(repo, model_id: int) -> None:
    """Designate ``model_id`` as the single global judge, validating eligibility."""
    model = repo.get_model(model_id)
    if model is None:
        raise JudgeConfigError(f"model {model_id} not found")
    caps = json.loads(model["capabilities"]) if model["capabilities"] else {}
    if not caps.get("chat_suite"):
        raise JudgeConfigError("judge must be a chat-capable model")
    repo.set_judge(model_id)


def clear_global_judge(repo) -> None:
    repo.set_judge(None)


def get_global_judge(repo):
    """Return the judge ModelConfig row, or None if unset."""
    judge_id = repo.get_judge_model_id()
    return None if judge_id is None else repo.get_model(judge_id)
