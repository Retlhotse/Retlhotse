"""Credential masking (FR-009, Constitution Principle VI).

A ``SecretRef`` holds an API key but never reveals it through any string,
repr, or serialization path — the realistic leak vectors (UI, logs, exports).
The raw value is reachable only via the explicit ``reveal()`` method, which is
called solely where a provider client is constructed.
"""

from __future__ import annotations


class SecretRef:
    """A string-like holder that masks its value everywhere except reveal()."""

    __slots__ = ("_value",)

    def __init__(self, value: str | None) -> None:
        self._value = value or ""

    def reveal(self) -> str:
        """Return the raw secret. Use ONLY when building a provider client."""
        return self._value

    @property
    def is_set(self) -> bool:
        return bool(self._value)

    def masked(self) -> str:
        if not self._value:
            return "(none)"
        tail = self._value[-4:] if len(self._value) >= 4 else ""
        return f"••••{tail}"

    # Every implicit stringification path returns the mask, not the secret.
    def __str__(self) -> str:
        return self.masked()

    def __repr__(self) -> str:
        return f"SecretRef({self.masked()})"

    def __format__(self, _spec: str) -> str:
        return self.masked()

    # Defang accidental JSON/serialization attempts.
    def __reduce__(self):
        # Pickling yields a masked, non-recoverable SecretRef.
        return (SecretRef, (self.masked(),))

    def __eq__(self, other: object) -> bool:
        # Constant-ish comparison against another SecretRef's raw value only.
        if isinstance(other, SecretRef):
            return self._value == other._value
        return NotImplemented

    def __hash__(self) -> int:
        return hash(("SecretRef", self._value))

    def __bool__(self) -> bool:
        return self.is_set
