"""Model-config onboarding schema (FR-001/002/002a/005/006/008/010).

Mirrors contracts/model-config.schema.json. A single ``ModelConfig`` schema
covers every LangChain-supported provider via ``provider`` + ``model``; only
``azure_openai`` requires the extra deployment/api_version/endpoint fields
(FR-006). Adding a new provider needs no schema change — it's just a new
``provider`` enum value pointed through the same fields.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, model_validator

#: LangChain provider keys this platform onboards. "local" targets any
#: OpenAI-compatible endpoint (vLLM, LM Studio, Ollama's OpenAI shim) via
#: endpoint_url, routed through the "openai" LangChain integration.
PROVIDERS = ("openai", "anthropic", "azure_openai", "google_genai", "ollama", "local")


class Capabilities(BaseModel):
    """Eligibility flags (FR-008). At least one must be true."""

    model_config = ConfigDict(extra="forbid")

    chat_suite: bool = False
    extraction: bool = False

    @model_validator(mode="after")
    def _at_least_one(self) -> "Capabilities":
        if not (self.chat_suite or self.extraction):
            raise ValueError(
                "capabilities: at least one of chat_suite/extraction must be true"
            )
        return self


class ModelConfig(BaseModel):
    """A model onboarding document, valid for any LangChain-supported provider."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, description="Unique logical model name (FR-007a)")
    provider: str = Field(description="LangChain provider key (FR-002)")
    model: str = Field(min_length=1, description="Model identifier passed to the provider")
    endpoint_url: str | None = None
    api_key: str | None = None
    azure_deployment: str | None = None
    azure_api_version: str | None = None
    capabilities: Capabilities
    max_context_window: int | None = Field(default=None, gt=0)

    @model_validator(mode="after")
    def _validate_provider_fields(self) -> "ModelConfig":
        if self.provider not in PROVIDERS:
            raise ValueError(
                f"provider: unknown provider {self.provider!r}; expected one of {PROVIDERS}"
            )
        if self.provider == "azure_openai":
            missing = [
                field
                for field in ("azure_deployment", "azure_api_version", "endpoint_url")
                if not getattr(self, field)
            ]
            if missing:
                raise ValueError(
                    "azure_openai requires: " + ", ".join(missing)
                )
        return self


def parse_model_config(data: dict) -> ModelConfig:
    """Validate a raw onboarding dict; raise pydantic ValidationError on failure.

    Nothing is persisted by this function — callers persist only on success
    (FR-005).
    """
    return ModelConfig(**data)
