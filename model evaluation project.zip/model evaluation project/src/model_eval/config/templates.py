"""Copyable onboarding JSON templates (FR-004).

Returned by the Onboarding page so users have a complete, valid starting point
for a local endpoint, Azure OpenAI, or any remote provider. Kept in sync with
contracts/model-config.*.example.json.
"""

from __future__ import annotations

import json

LOCAL_TEMPLATE: dict = {
    "name": "my-local-model",
    "provider": "local",
    "model": "llama3:70b",
    "endpoint_url": "http://<HOST>:<PORT>/v1",
    "api_key": "<API_KEY_OR_OMIT>",
    "capabilities": {"chat_suite": True, "extraction": False},
    "max_context_window": 65536,
}

AZURE_TEMPLATE: dict = {
    "name": "my-azure-model",
    "provider": "azure_openai",
    "model": "gpt-4o",
    "endpoint_url": "https://<RESOURCE>.openai.azure.com",
    "api_key": "<API_KEY>",
    "azure_deployment": "<DEPLOYMENT_NAME>",
    "azure_api_version": "2024-06-01",
    "capabilities": {"chat_suite": True, "extraction": True},
    "max_context_window": 128000,
}

REMOTE_TEMPLATE: dict = {
    "name": "my-remote-model",
    "provider": "anthropic",
    "model": "claude-opus-4-8",
    "api_key": "<API_KEY>",
    "capabilities": {"chat_suite": True, "extraction": False},
    "max_context_window": 1000000,
}


def template_json(provider: str) -> str:
    """Return a pretty-printed JSON template for ``local``, ``azure``, or ``remote``."""
    if provider == "local":
        return json.dumps(LOCAL_TEMPLATE, indent=2)
    if provider == "azure":
        return json.dumps(AZURE_TEMPLATE, indent=2)
    if provider == "remote":
        return json.dumps(REMOTE_TEMPLATE, indent=2)
    raise ValueError(f"unknown provider: {provider!r}")
