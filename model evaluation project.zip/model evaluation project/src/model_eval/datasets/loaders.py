"""Local dataset loaders (read-only, from provisioned paths).

Phase 2 provides the loading surface used by the sub-evaluations (added in
later phases). Every loader reads from a local path and never reaches the
network (Principle I/II). Concrete parsing of each benchmark format is filled in
when its consuming sub-evaluation is implemented (US2/US3).
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class QAItem:
    """A short-answer QA pair used as the needle-in-haystack base (R2)."""

    id: str
    question: str
    answer: str
    context: str


def load_jsonl(path: str | Path) -> Iterator[dict]:
    """Yield records from a local JSON Lines file."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"dataset file not present locally: {p}")
    with p.open("r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line:
                yield json.loads(line)


def load_qa_base(path: str | Path) -> list[QAItem]:
    """Load the chatbot QA base set (used to synthesize the context axis)."""
    items: list[QAItem] = []
    for rec in load_jsonl(path):
        items.append(
            QAItem(
                id=str(rec.get("id", len(items))),
                question=rec["question"],
                answer=rec["answer"],
                context=rec.get("context", ""),
            )
        )
    return items
