"""Local dataset registry + presence verification (FR-012/013/073, Principle II).

Datasets are provisioned out-of-band. This module resolves required datasets to
local paths and verifies their presence *live* before a run. A required-but-
absent dataset raises ``DatasetNotProvisioned`` — there is no fetch path.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

# Which logical datasets each run type requires.
REQUIRED_BY_SUITE: dict[str, tuple[str, ...]] = {
    "llm-combined": ("chatbot_qa_base", "filler_corpus", "rag_corpus", "bfcl_ast"),
    "text-extraction": ("omnidocbench",),
}


class DatasetNotProvisioned(RuntimeError):
    """Raised when a required dataset is not present locally (no fetch attempted)."""


@dataclass(frozen=True)
class DatasetStatus:
    name: str
    local_path: str
    present: bool


class DatasetRegistry:
    """Resolves dataset names to local paths and checks presence.

    ``resolver`` maps a logical name to its configured local path (typically
    backed by the ``dataset`` table via the repository). Presence is checked on
    the filesystem at call time, never cached.
    """

    def __init__(self, resolver) -> None:
        self._resolve_path = resolver

    def status(self, name: str) -> DatasetStatus:
        path = self._resolve_path(name)
        present = bool(path) and Path(path).exists()
        return DatasetStatus(name=name, local_path=path or "", present=present)

    def report(self, suite_type: str) -> list[DatasetStatus]:
        """Presence report for every dataset a suite requires (FR-073)."""
        names = REQUIRED_BY_SUITE.get(suite_type, ())
        return [self.status(n) for n in names]

    def ensure_present(self, suite_type: str) -> None:
        """Raise if any required dataset is missing — fail fast, no fetch (FR-013)."""
        missing = [s.name for s in self.report(suite_type) if not s.present]
        if missing:
            raise DatasetNotProvisioned(
                "dataset not provisioned locally: " + ", ".join(missing)
            )


def repository_resolver(repo) -> "callable":
    """Build a resolver that looks up a dataset's local_path via the repository."""

    def _resolve(name: str) -> str | None:
        row = repo.get_dataset(name)
        return None if row is None else row["local_path"]

    return _resolve
