"""Universal chat provider backed by LangChain (FR-002/002a, research.md R4/R8).

One implementation covers every LangChain-supported backend — OpenAI, Anthropic,
Azure OpenAI, Google, Ollama, or any OpenAI-compatible local server — via
``init_chat_model(model, model_provider=..., **kwargs)``. Adding a new provider
is therefore a configuration concern (a new ``provider`` value onboarded through
the UI), never a code change to this module, the engine, scoring, or persistence
(Constitution Principle I).
"""

from __future__ import annotations

from model_eval.config.secret import SecretRef
from model_eval.providers.base import ChatMessage, ChatProvider


class LangChainProvider(ChatProvider):
    def __init__(
        self,
        *,
        name: str,
        provider: str,
        model: str,
        endpoint_url: str | None = None,
        api_key: str | SecretRef | None = None,
        azure_deployment: str | None = None,
        azure_api_version: str | None = None,
    ) -> None:
        self.name = name
        self.provider = provider
        self.model = model
        self.endpoint_url = endpoint_url or ""

        # Imported lazily so the package imports without the langchain deps at rest.
        from langchain.chat_models import init_chat_model

        kwargs: dict = {}
        key = self._key(api_key)
        if key:
            kwargs["api_key"] = key
        elif provider == "local":
            # Local servers often don't require auth, but the underlying client
            # still validates for a non-empty key string.
            kwargs["api_key"] = "not-needed"

        # "local" is this platform's onboarding label for "any OpenAI-compatible
        # endpoint" (vLLM, LM Studio, Ollama's OpenAI shim, ...) — it is not a
        # LangChain provider key. Route it through LangChain's "openai" chat
        # integration with base_url overridden to the local server.
        lc_provider = "openai" if provider == "local" else provider

        if provider == "azure_openai":
            kwargs["azure_endpoint"] = endpoint_url
            kwargs["azure_deployment"] = azure_deployment
            kwargs["api_version"] = azure_api_version
        elif endpoint_url:
            # Local / custom-hosted OpenAI-compatible servers, Ollama, etc.
            kwargs["base_url"] = endpoint_url

        self._model = init_chat_model(model, model_provider=lc_provider, **kwargs)

    def complete(
        self,
        messages: list[ChatMessage],
        *,
        tools: list[dict] | None = None,
        temperature: float = 0.0,
        max_tokens: int | None = None,
    ) -> str:
        model = self._model
        if tools:
            model = model.bind_tools(tools)
        response = model.invoke(self._to_langchain_messages(messages))
        return response.content or ""

    def complete_with_tools(
        self,
        messages: list[ChatMessage],
        tools: list[dict],
        *,
        temperature: float = 0.0,
    ) -> list[dict]:
        response = self._model.bind_tools(tools).invoke(self._to_langchain_messages(messages))
        calls = getattr(response, "tool_calls", None) or []
        return [{"name": c["name"], "arguments": c["args"]} for c in calls]

    @staticmethod
    def _to_langchain_messages(messages: list[ChatMessage]) -> list[tuple[str, str]]:
        return [(m.role, m.content) for m in messages]
