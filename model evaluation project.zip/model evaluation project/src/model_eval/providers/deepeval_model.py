"""deepeval judge wrapper (FR-040, Constitution Principle III, research.md R5).

deepeval defaults its LLM-as-judge to an external provider unless one is
supplied explicitly. Wrapping any ``ChatProvider`` (LangChain-backed, any
provider) as a ``DeepEvalBaseLLM`` and passing the instance as ``model=`` to
every metric makes the judge explicit rather than defaulted. One shared
instance encodes the single global judge (FR-040); its identity is captured in
each run's snapshot (FR-042).
"""

from __future__ import annotations

from model_eval.providers.base import ChatMessage, ChatProvider


def _base_llm_class():
    """Import deepeval's base lazily so the package imports without deepeval."""
    from deepeval.models.base_model import DeepEvalBaseLLM

    return DeepEvalBaseLLM


def make_local_judge(provider: ChatProvider):
    """Build a deepeval judge model backed by a ``ChatProvider`` (any provider).

    Named for the caller-facing concept ("the configured judge"), not the
    provider's location — the wrapped provider may be local or remote.
    """

    DeepEvalBaseLLM = _base_llm_class()

    class DeepEvalLangChainModel(DeepEvalBaseLLM):
        def __init__(self, prov: ChatProvider) -> None:
            self._provider = prov
            super().__init__()

        def load_model(self):
            return self._provider

        def generate(self, prompt: str) -> str:
            return self._provider.complete([ChatMessage(role="user", content=prompt)])

        async def a_generate(self, prompt: str) -> str:
            return self.generate(prompt)

        def get_model_name(self) -> str:
            return f"judge:{self._provider.name}"

    return DeepEvalLangChainModel(provider)
