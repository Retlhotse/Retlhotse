"""Common chat-provider interface (research.md R4/R8).

Every backend (any LangChain-supported provider) implements ``ChatProvider``.
The evaluation engine and the deepeval judge wrapper talk only to this
interface, so candidate models and the judge are invoked uniformly regardless
of which provider or host serves them (Constitution Principle I).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass

from model_eval.config.secret import SecretRef


@dataclass(frozen=True)
class ChatMessage:
    role: str  # "system" | "user" | "assistant" | "tool"
    content: str


class ChatProvider(ABC):
    """Minimal chat/completions surface used across the platform."""

    #: Human-readable model/deployment name for provenance (config_snapshot).
    name: str
    #: Endpoint/base URL, if any (local/custom-hosted servers); informational only.
    endpoint_url: str

    @abstractmethod
    def complete(
        self,
        messages: list[ChatMessage],
        *,
        tools: list[dict] | None = None,
        temperature: float = 0.0,
        max_tokens: int | None = None,
    ) -> str:
        """Return the assistant text for a chat request.

        Tool/function schemas may be passed via ``tools``; tool-calling
        evaluation reads the structured tool calls via ``complete_with_tools``.
        """

    @abstractmethod
    def complete_with_tools(
        self,
        messages: list[ChatMessage],
        tools: list[dict],
        *,
        temperature: float = 0.0,
    ) -> list[dict]:
        """Return the model's tool/function calls as a list of {name, arguments}."""

    @staticmethod
    def _key(api_key: str | SecretRef | None) -> str:
        if isinstance(api_key, SecretRef):
            return api_key.reveal()
        return api_key or ""
