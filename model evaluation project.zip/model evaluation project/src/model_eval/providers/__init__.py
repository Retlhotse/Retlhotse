"""Model providers + a factory to build one from stored config (FR-002/002a)."""

from __future__ import annotations

from typing import Any

from model_eval.config.secret import SecretRef
from model_eval.providers.base import ChatMessage, ChatProvider


def build_provider(config: dict[str, Any]) -> ChatProvider:
    """Construct a ChatProvider from a ModelConfig-shaped mapping.

    Accepts either a sqlite3.Row-derived dict or a validated config dict.
    ``api_key`` may be a raw string or a SecretRef. Works uniformly for any
    LangChain-supported ``provider`` value — adding a new backend never
    requires a code change here (Constitution Principle I).
    """
    from model_eval.providers.langchain_provider import LangChainProvider

    api_key = config.get("api_key")
    if isinstance(api_key, str):
        api_key = SecretRef(api_key)

    return LangChainProvider(
        name=config["name"],
        provider=config["provider"],
        model=config["model"],
        endpoint_url=config.get("endpoint_url"),
        api_key=api_key,
        azure_deployment=config.get("azure_deployment"),
        azure_api_version=config.get("azure_api_version"),
    )


__all__ = ["ChatMessage", "ChatProvider", "build_provider"]
