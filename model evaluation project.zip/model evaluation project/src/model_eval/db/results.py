"""Results read queries for the Results page (FR-062/063, US4).

Read-only views over the repository: a run list with model names, per-axis and
per-document drill-downs, and same-axis comparison of two runs. Kept separate
from the write-side repository for clarity.
"""

from __future__ import annotations

from dataclasses import dataclass

from model_eval.db.repository import Repository


@dataclass(frozen=True)
class RunSummary:
    run_id: int
    model_name: str
    suite_type: str
    status: str
    started_at: str | None
    ended_at: str | None


def list_run_summaries(repo: Repository) -> list[RunSummary]:
    """Runs with their model name for the Results list (FR-062)."""
    summaries: list[RunSummary] = []
    models = {m["id"]: m["name"] for m in repo.list_models()}
    for r in repo.list_runs():
        summaries.append(
            RunSummary(
                run_id=r["id"],
                model_name=models.get(r["model_config_id"], "(deleted)"),
                suite_type=r["suite_type"],
                status=r["status"],
                started_at=r["started_at"],
                ended_at=r["ended_at"],
            )
        )
    return summaries


def axis_drilldown(repo: Repository, run_id: int) -> list[dict]:
    """Per-axis-point rows for a combined run (FR-062)."""
    return [
        {
            "sub_evaluation": r["sub_evaluation"],
            "axis_kind": r["axis_kind"],
            "axis_value": r["axis_value"],
            "metric": r["metric_name"],
            "score": r["score"],
            "threshold": r["threshold"],
            "passed": None if r["passed"] is None else bool(r["passed"]),
            "status": r["status"],
            "reason": r["reason"],
        }
        for r in repo.list_axis_results(run_id)
    ]


def document_drilldown(repo: Repository, run_id: int) -> list[dict]:
    """Per-document rows for an extraction run (FR-062)."""
    return [
        {
            "document_id": r["document_id"],
            "text_edit_distance": r["text_edit_distance"],
            "reading_order_edit_distance": r["reading_order_edit_distance"],
            "table_teds": r["table_teds"],
            "formula_score": r["formula_score"],
            "overall": r["overall"],
            "status": r["status"],
            "reason": r["reason"],
        }
        for r in repo.list_extraction_results(run_id)
    ]


def compare_axis(repo: Repository, run_id_a: int, run_id_b: int) -> list[dict]:
    """Align two combined runs on identical (sub, axis_value, metric) keys (FR-063).

    Returns one row per axis key present in either run, with both scores, so two
    models can be compared on the same axis. Raises if the two runs are not the
    same suite_type.
    """
    a, b = repo.get_run(run_id_a), repo.get_run(run_id_b)
    if a is None or b is None:
        raise ValueError("both runs must exist")
    if a["suite_type"] != b["suite_type"]:
        raise ValueError("runs must be the same suite type to compare on the same axis")

    def keyed(run_id: int) -> dict:
        return {
            (r["sub_evaluation"], r["axis_kind"], r["axis_value"], r["metric_name"]): r["score"]
            for r in repo.list_axis_results(run_id)
        }

    ka, kb = keyed(run_id_a), keyed(run_id_b)
    rows = []
    for key in sorted(set(ka) | set(kb)):
        sub, axis_kind, axis_value, metric = key
        rows.append(
            {
                "sub_evaluation": sub,
                "axis_kind": axis_kind,
                "axis_value": axis_value,
                "metric": metric,
                f"run_{run_id_a}": ka.get(key),
                f"run_{run_id_b}": kb.get(key),
            }
        )
    return rows
