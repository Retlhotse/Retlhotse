"""SQLite persistence for the evaluation platform.

Single embedded datastore (CON-003/FR-064). WAL mode lets the background worker
write run/result rows while the Streamlit UI thread reads (research.md R10).
This module is stdlib-only so the constitution's persistence + state-machine
guarantees (Principle V/VII) are testable without third-party deps.
"""

from __future__ import annotations

import json
import sqlite3
from collections.abc import Iterable
from datetime import datetime, timezone
from pathlib import Path

SCHEMA_PATH = Path(__file__).with_name("schema.sql")

# EvaluationRun.status values (data-model.md state machine).
RUN_STATUSES = ("queued", "running", "completed", "failed", "interrupted", "partial")

# Allowed transitions out of each status. Terminal states have none.
_TRANSITIONS: dict[str, set[str]] = {
    "queued": {"running", "failed"},
    "running": {"completed", "partial", "failed", "interrupted"},
    "completed": set(),
    "failed": set(),
    "interrupted": set(),
    "partial": set(),
}


class InvalidStateTransition(ValueError):
    """Raised when an EvaluationRun status change violates the state machine."""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class Repository:
    """Thin data-access layer over a single SQLite file."""

    def __init__(self, db_path: str | Path) -> None:
        self.db_path = str(db_path)
        self._conn = sqlite3.connect(self.db_path)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._bootstrap()

    def _bootstrap(self) -> None:
        self._conn.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()

    def __enter__(self) -> Repository:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    # ------------------------------------------------------------------ models
    def add_model(
        self,
        *,
        name: str,
        provider: str,
        model: str,
        capabilities: dict[str, bool],
        endpoint_url: str | None = None,
        api_key: str | None = None,
        azure_deployment: str | None = None,
        azure_api_version: str | None = None,
        max_context_window: int | None = None,
    ) -> int:
        """Insert a ModelConfig for any LangChain-supported provider.

        Unique name enforced by the DB (FR-007a).
        """
        try:
            cur = self._conn.execute(
                """
                INSERT INTO model_config
                    (name, provider, model, endpoint_url, api_key, azure_deployment,
                     azure_api_version, capabilities, max_context_window, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    name,
                    provider,
                    model,
                    endpoint_url,
                    api_key,
                    azure_deployment,
                    azure_api_version,
                    json.dumps(capabilities),
                    max_context_window,
                    _utc_now(),
                ),
            )
            self._conn.commit()
            return int(cur.lastrowid)
        except sqlite3.IntegrityError as exc:
            raise ValueError(f"model name already exists: {name!r}") from exc

    def get_model(self, model_id: int) -> sqlite3.Row | None:
        return self._conn.execute(
            "SELECT * FROM model_config WHERE id = ?", (model_id,)
        ).fetchone()

    def list_models(self) -> list[sqlite3.Row]:
        return self._conn.execute(
            "SELECT * FROM model_config ORDER BY name"
        ).fetchall()

    # ------------------------------------------------------------------- judge
    def set_judge(self, model_config_id: int | None) -> None:
        """Set (or clear) the single global judge (FR-040)."""
        self._conn.execute(
            """
            INSERT INTO judge_config (id, model_config_id, updated_at)
            VALUES (1, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                model_config_id = excluded.model_config_id,
                updated_at = excluded.updated_at
            """,
            (model_config_id, _utc_now()),
        )
        self._conn.commit()

    def get_judge_model_id(self) -> int | None:
        row = self._conn.execute(
            "SELECT model_config_id FROM judge_config WHERE id = 1"
        ).fetchone()
        return None if row is None else row["model_config_id"]

    # ----------------------------------------------------------------- datasets
    def upsert_dataset(
        self, *, name: str, suite: str, local_path: str, version: str | None = None
    ) -> None:
        self._conn.execute(
            """
            INSERT INTO dataset (name, suite, local_path, version)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(name) DO UPDATE SET
                suite = excluded.suite,
                local_path = excluded.local_path,
                version = excluded.version
            """,
            (name, suite, local_path, version),
        )
        self._conn.commit()

    def get_dataset(self, name: str) -> sqlite3.Row | None:
        return self._conn.execute(
            "SELECT * FROM dataset WHERE name = ?", (name,)
        ).fetchone()

    # --------------------------------------------------------------------- runs
    def create_run(
        self, *, model_config_id: int, suite_type: str, config_snapshot: dict
    ) -> int:
        cur = self._conn.execute(
            """
            INSERT INTO evaluation_run
                (model_config_id, suite_type, status, config_snapshot)
            VALUES (?, ?, 'queued', ?)
            """,
            (model_config_id, suite_type, json.dumps(config_snapshot)),
        )
        self._conn.commit()
        return int(cur.lastrowid)

    def get_run(self, run_id: int) -> sqlite3.Row | None:
        return self._conn.execute(
            "SELECT * FROM evaluation_run WHERE id = ?", (run_id,)
        ).fetchone()

    def list_runs(self, *, suite_type: str | None = None) -> list[sqlite3.Row]:
        if suite_type is None:
            return self._conn.execute(
                "SELECT * FROM evaluation_run ORDER BY id DESC"
            ).fetchall()
        return self._conn.execute(
            "SELECT * FROM evaluation_run WHERE suite_type = ? ORDER BY id DESC",
            (suite_type,),
        ).fetchall()

    def transition_run(
        self, run_id: int, new_status: str, *, failure_reason: str | None = None
    ) -> None:
        """Move a run to ``new_status`` if the transition is legal (Principle V)."""
        if new_status not in RUN_STATUSES:
            raise ValueError(f"unknown status: {new_status!r}")
        row = self.get_run(run_id)
        if row is None:
            raise ValueError(f"run {run_id} not found")
        current = row["status"]
        if new_status not in _TRANSITIONS[current]:
            raise InvalidStateTransition(f"{current} -> {new_status} not allowed")

        sets = ["status = ?"]
        params: list[object] = [new_status]
        if new_status == "running":
            sets.append("started_at = ?")
            params.append(_utc_now())
        if new_status in ("completed", "failed", "interrupted", "partial"):
            sets.append("ended_at = ?")
            params.append(_utc_now())
        if failure_reason is not None:
            sets.append("failure_reason = ?")
            params.append(failure_reason)
        params.append(run_id)
        self._conn.execute(
            f"UPDATE evaluation_run SET {', '.join(sets)} WHERE id = ?", params
        )
        self._conn.commit()

    def update_progress(self, run_id: int, progress: dict) -> None:
        self._conn.execute(
            "UPDATE evaluation_run SET progress = ? WHERE id = ?",
            (json.dumps(progress), run_id),
        )
        self._conn.commit()

    def reap_stale_running(self) -> int:
        """Mark any 'running' run as 'interrupted' (Principle V).

        Called at startup: a 'running' row with no live worker means the process
        died mid-run. Returns the number of runs reaped.
        """
        rows = self._conn.execute(
            "SELECT id FROM evaluation_run WHERE status = 'running'"
        ).fetchall()
        for r in rows:
            self.transition_run(
                r["id"], "interrupted", failure_reason="process restarted mid-run"
            )
        return len(rows)

    # ------------------------------------------------------------------ results
    def add_axis_result(
        self,
        *,
        run_id: int,
        sub_evaluation: str,
        axis_kind: str,
        axis_value: int,
        metric_name: str,
        status: str,
        score: float | None = None,
        threshold: float | None = None,
        passed: bool | None = None,
        reason: str | None = None,
    ) -> int:
        cur = self._conn.execute(
            """
            INSERT INTO axis_result
                (run_id, sub_evaluation, axis_kind, axis_value, metric_name,
                 score, threshold, passed, status, reason)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                run_id,
                sub_evaluation,
                axis_kind,
                axis_value,
                metric_name,
                score,
                threshold,
                None if passed is None else int(passed),
                status,
                reason,
            ),
        )
        self._conn.commit()
        return int(cur.lastrowid)

    def list_axis_results(self, run_id: int) -> list[sqlite3.Row]:
        return self._conn.execute(
            """
            SELECT * FROM axis_result WHERE run_id = ?
            ORDER BY sub_evaluation, axis_kind, axis_value, metric_name
            """,
            (run_id,),
        ).fetchall()

    def add_extraction_result(
        self,
        *,
        run_id: int,
        document_id: str,
        status: str,
        text_edit_distance: float | None = None,
        reading_order_edit_distance: float | None = None,
        table_teds: float | None = None,
        formula_score: float | None = None,
        overall: float | None = None,
        reason: str | None = None,
    ) -> int:
        cur = self._conn.execute(
            """
            INSERT INTO extraction_result
                (run_id, document_id, text_edit_distance, reading_order_edit_distance,
                 table_teds, formula_score, overall, status, reason)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                run_id,
                document_id,
                text_edit_distance,
                reading_order_edit_distance,
                table_teds,
                formula_score,
                overall,
                status,
                reason,
            ),
        )
        self._conn.commit()
        return int(cur.lastrowid)

    def list_extraction_results(self, run_id: int) -> list[sqlite3.Row]:
        return self._conn.execute(
            "SELECT * FROM extraction_result WHERE run_id = ? ORDER BY document_id",
            (run_id,),
        ).fetchall()

    # ------------------------------------------------------------------ helpers
    def finalize_run(self, run_id: int) -> str:
        """Derive completed vs partial from recorded axis/extraction results.

        A run with any skipped/failed result point but >=1 scored point is
        'partial', never 'completed' (Principle V). With zero scored points it
        is 'failed'.
        """
        statuses = self._collect_result_statuses(run_id)
        scored = sum(1 for s in statuses if s == "scored")
        degraded = any(s in ("skipped", "failed") for s in statuses)
        if scored == 0:
            target = "failed"
        elif degraded:
            target = "partial"
        else:
            target = "completed"
        self.transition_run(run_id, target)
        return target

    def _collect_result_statuses(self, run_id: int) -> Iterable[str]:
        axis = self._conn.execute(
            "SELECT status FROM axis_result WHERE run_id = ?", (run_id,)
        ).fetchall()
        extraction = self._conn.execute(
            "SELECT status FROM extraction_result WHERE run_id = ?", (run_id,)
        ).fetchall()
        return [r["status"] for r in axis] + [r["status"] for r in extraction]
