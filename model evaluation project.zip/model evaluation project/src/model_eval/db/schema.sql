-- Enterprise Model Evaluation Platform — SQLite schema.
-- Mirrors specs/001-model-evaluation-platform/data-model.md.
-- Single embedded local datastore (CON-003 / FR-064). WAL mode set by the
-- repository connection, not here.

PRAGMA foreign_keys = ON;

-- A registered model available for evaluation, from any LangChain-supported
-- provider (FR-001/002/002a/006/007/007a/008/009/010).
CREATE TABLE IF NOT EXISTS model_config (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    name                TEXT    NOT NULL,
    provider            TEXT    NOT NULL CHECK (provider IN (
                            'openai', 'anthropic', 'azure_openai', 'google_genai', 'ollama', 'local')),
    model               TEXT    NOT NULL,           -- model id passed to the provider (FR-002)
    endpoint_url        TEXT,                       -- base URL for local/custom servers, or azure_endpoint
    api_key             TEXT,                       -- stored; surfaced only via SecretRef (FR-009)
    azure_deployment    TEXT,                       -- required when provider = 'azure_openai' (FR-006)
    azure_api_version   TEXT,                       -- required when provider = 'azure_openai' (FR-006)
    capabilities        TEXT    NOT NULL,           -- JSON: {"chat_suite": bool, "extraction": bool}
    max_context_window  INTEGER,                    -- optional declared cap (FR-010 -> FR-024)
    created_at          TEXT    NOT NULL
);

-- Unique logical name protects reproducibility of prior runs (FR-007a).
CREATE UNIQUE INDEX IF NOT EXISTS ux_model_config_name ON model_config (name);

-- The single, global judge model (FR-040/041/042). Enforced to one row (id = 1).
CREATE TABLE IF NOT EXISTS judge_config (
    id              INTEGER PRIMARY KEY CHECK (id = 1),
    model_config_id INTEGER REFERENCES model_config (id) ON DELETE SET NULL,
    updated_at      TEXT    NOT NULL
);

-- A locally-provisioned benchmark dataset (FR-012/013/073). Presence is verified
-- live at run time, not trusted from this row.
CREATE TABLE IF NOT EXISTS dataset (
    name        TEXT PRIMARY KEY,
    suite       TEXT NOT NULL CHECK (suite IN ('chatbot', 'rag', 'tool-calling', 'extraction')),
    local_path  TEXT NOT NULL,
    version     TEXT
);

-- One execution of a job (FR-055/060/072).
CREATE TABLE IF NOT EXISTS evaluation_run (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    model_config_id INTEGER NOT NULL REFERENCES model_config (id) ON DELETE CASCADE,
    suite_type      TEXT    NOT NULL CHECK (suite_type IN ('llm-combined', 'text-extraction')),
    status          TEXT    NOT NULL CHECK (status IN (
                        'queued', 'running', 'completed', 'failed', 'interrupted', 'partial')),
    started_at      TEXT,
    ended_at        TEXT,
    progress        TEXT,                           -- JSON {current_sub,current_axis_point,done,total}
    config_snapshot TEXT    NOT NULL,               -- JSON provenance (FR-IV/042)
    failure_reason  TEXT
);

CREATE INDEX IF NOT EXISTS ix_run_model  ON evaluation_run (model_config_id);
CREATE INDEX IF NOT EXISTS ix_run_status ON evaluation_run (status);
CREATE INDEX IF NOT EXISTS ix_run_suite  ON evaluation_run (suite_type);

-- A result at one axis point of an LLM-suite sub-evaluation (FR-021/022/023/026b/028/061).
CREATE TABLE IF NOT EXISTS axis_result (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id          INTEGER NOT NULL REFERENCES evaluation_run (id) ON DELETE CASCADE,
    sub_evaluation  TEXT    NOT NULL CHECK (sub_evaluation IN ('chatbot', 'rag', 'tool-calling')),
    axis_kind       TEXT    NOT NULL CHECK (axis_kind IN ('context-window', 'tool-count')),
    axis_value      INTEGER NOT NULL,
    metric_name     TEXT    NOT NULL,
    score           REAL,                           -- raw native-scale score (FR-028)
    threshold       REAL,                           -- applied cutoff (FR-028)
    passed          INTEGER,                        -- 0/1; NULL when skipped
    status          TEXT    NOT NULL CHECK (status IN ('scored', 'skipped', 'failed')),
    reason          TEXT                            -- skip/fail reason (FR-023/024)
);

CREATE INDEX IF NOT EXISTS ix_axis_run  ON axis_result (run_id);
CREATE INDEX IF NOT EXISTS ix_axis_group ON axis_result (run_id, sub_evaluation, axis_kind);

-- A per-document text-extraction result (FR-051/053/061).
CREATE TABLE IF NOT EXISTS extraction_result (
    id                          INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id                      INTEGER NOT NULL REFERENCES evaluation_run (id) ON DELETE CASCADE,
    document_id                 TEXT    NOT NULL,
    text_edit_distance          REAL,
    reading_order_edit_distance REAL,
    table_teds                  REAL,
    formula_score               REAL,
    overall                     REAL,
    status                      TEXT    NOT NULL CHECK (status IN ('scored', 'failed')),
    reason                      TEXT
);

CREATE INDEX IF NOT EXISTS ix_extraction_run ON extraction_result (run_id);
