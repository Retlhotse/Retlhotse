"""BFCL task loader — AST categories ONLY (FR-026/026a, Constitution Principle I).

Loads single-turn AST tasks from local storage. Executable categories and V3
multi-turn categories are hard-rejected because they require live API execution
or a stateful backend that would breach the air-gap.

Expected local record shape (one JSON object per line), as provisioned
out-of-band:
    {
      "id": "simple_0",
      "question": "What's the weather in Paris?",
      "function": [ {<OpenAI/JSON tool schema>}, ... ],
      "ground_truth": [ {"name": "...", "arguments": {"param": ["accepted", ...]}} ]
    }

Real BFCL function names may contain characters some providers reject as tool
names (e.g. ``math.factorial`` — Anthropic requires ``^[a-zA-Z0-9_-]{1,128}$``,
a dot is not allowed). Names are sanitized at load time, consistently across
both the tool schema sent to the model AND the ground-truth call it's scored
against, so scoring stays correct while the request stays provider-compatible.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from model_eval.datasets.loaders import load_jsonl

AST_CATEGORIES = ("simple", "multiple", "parallel", "parallel_multiple")

# Substrings that mark a forbidden (non-AST) category.
_FORBIDDEN_MARKERS = ("exec", "multi_turn", "multiturn", "multi-turn")

# The strictest widely-used tool-name constraint across providers (Anthropic):
# only letters, digits, underscore, and hyphen, max 128 chars.
_INVALID_NAME_CHARS = re.compile(r"[^a-zA-Z0-9_-]")


class ForbiddenCategory(ValueError):
    """Raised for a non-AST BFCL category (Executable / multi-turn)."""


def sanitize_tool_name(name: str) -> str:
    """Map a raw function name to a name every supported provider accepts."""
    cleaned = _INVALID_NAME_CHARS.sub("_", name)[:128]
    return cleaned or "_"


@dataclass(frozen=True)
class BfclTask:
    id: str
    question: str
    tools: list[dict]          # available tool schemas (the ground-truth tool included)
    ground_truth: list[dict]   # accepted calls: [{"name", "arguments": {param: [values]}}]

    def ground_truth_tool(self) -> dict:
        """Return the tool schema matching the (first) ground-truth call name."""
        gt_name = self.ground_truth[0]["name"]
        for schema in self.tools:
            fn = schema.get("function")
            name = fn["name"] if isinstance(fn, dict) else schema.get("name")
            if name == gt_name:
                return schema
        raise KeyError(f"ground-truth tool {gt_name!r} not found in task {self.id!r}")


def assert_ast_category(category: str) -> None:
    """Raise ForbiddenCategory unless ``category`` is a permitted AST category."""
    lowered = category.lower()
    if any(marker in lowered for marker in _FORBIDDEN_MARKERS):
        raise ForbiddenCategory(
            f"category {category!r} requires live execution or state; "
            "only BFCL AST categories are permitted (FR-026a)"
        )
    if category not in AST_CATEGORIES:
        raise ForbiddenCategory(
            f"category {category!r} is not a BFCL AST category "
            f"(allowed: {', '.join(AST_CATEGORIES)})"
        )


def _sanitize_tools(tools: list[dict]) -> list[dict]:
    sanitized = []
    for schema in tools:
        fn = dict(schema.get("function", {}))
        if "name" in fn:
            fn["name"] = sanitize_tool_name(fn["name"])
        sanitized.append({**schema, "function": fn} if "function" in schema else schema)
    return sanitized


def _sanitize_ground_truth(ground_truth: list[dict]) -> list[dict]:
    return [{**call, "name": sanitize_tool_name(call["name"])} for call in ground_truth]


def load_ast_tasks(path: str | Path, category: str) -> list[BfclTask]:
    """Load AST tasks for ``category`` from a local JSONL file."""
    assert_ast_category(category)
    tasks: list[BfclTask] = []
    for rec in load_jsonl(path):
        tasks.append(
            BfclTask(
                id=str(rec["id"]),
                question=rec["question"],
                tools=_sanitize_tools(list(rec["function"])),
                ground_truth=_sanitize_ground_truth(list(rec["ground_truth"])),
            )
        )
    return tasks
