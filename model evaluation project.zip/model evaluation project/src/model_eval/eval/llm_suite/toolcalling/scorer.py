"""Tool-calling sub-evaluation (FR-022/025/026b).

For a fixed BFCL AST task, sweeps the tool-count axis: at each N the model is
offered the ground-truth tool plus distractors (total = N), and its tool call is
scored deterministically by the BFCL native AST checker (no judge). Insufficient
distractors for a given N are recorded skipped-with-reason.
"""

from __future__ import annotations

from collections.abc import Callable

from model_eval.eval.axis.tool_count import (
    InsufficientDistractors,
    build_tool_set,
)
from model_eval.eval.llm_suite.base import TOOL_COUNTS, TOOL_METRIC, AxisPoint
from model_eval.eval.llm_suite.toolcalling.ast_scorer import score as ast_score
from model_eval.eval.llm_suite.toolcalling.bfcl_loader import BfclTask
from model_eval.providers.base import ChatMessage, ChatProvider

ProgressCb = Callable[[str, int], None] | None

# Tool-call correctness is binary per BFCL AST; pass means score == 1.0.
TOOL_THRESHOLD = 1.0


def evaluate(
    *,
    provider: ChatProvider,
    task: BfclTask,
    distractor_pool: list[dict],
    counts: tuple[int, ...] = TOOL_COUNTS,
    seed: int = 0,
    progress: ProgressCb = None,
) -> list[AxisPoint]:
    points: list[AxisPoint] = []
    gt_tool = task.ground_truth_tool()
    for n in counts:
        try:
            tool_set = build_tool_set(
                ground_truth_tool=gt_tool,
                distractor_pool=distractor_pool,
                n=n,
                seed=seed,
            )
        except InsufficientDistractors as exc:
            points.append(
                AxisPoint(
                    "tool-calling", "tool-count", n, TOOL_METRIC,
                    status="skipped", reason=str(exc),
                )
            )
            if progress:
                progress("tool-calling", n)
            continue

        calls = provider.complete_with_tools(
            [ChatMessage(role="user", content=task.question)],
            tools=tool_set.tools,
        )
        result = ast_score(task.ground_truth, calls)
        s = 1.0 if result.correct else 0.0
        points.append(
            AxisPoint(
                "tool-calling", "tool-count", n, TOOL_METRIC,
                status="scored", score=s, threshold=TOOL_THRESHOLD,
                passed=result.correct,
                reason=None if result.correct else result.reason,
            )
        )
        if progress:
            progress("tool-calling", n)
    return points
