# BFCL AST scorer — provenance

This module implements the **AST (Abstract Syntax Tree) checking** methodology of
the **Berkeley Function Calling Leaderboard (BFCL)** / Gorilla project
(https://github.com/ShishirPatil/gorilla), which is licensed under **Apache 2.0**.

It is a self-contained re-implementation of BFCL's AST scoring semantics for the
single-turn AST categories (`simple`, `multiple`, `parallel`, `parallel_multiple`)
so the platform can score tool calls **offline** with no live API execution
(Constitution Principle I; spec FR-026a/FR-026b). It deliberately does NOT include
BFCL's Executable categories or multi-turn harness, which require network/stateful
execution.

AST semantics implemented (matching BFCL):
- The predicted function **name** must equal the ground-truth name.
- Each ground-truth parameter's value must equal one of the **accepted values**
  (BFCL "possible answers" allow a list of acceptable values per parameter).
- A parameter may be omitted only if an empty/absent value is among its accepted
  values (i.e. it is optional).
- For `parallel` / `parallel_multiple`, the set of predicted calls must match the
  set of ground-truth calls one-to-one (order-independent).

If the upstream Apache-2.0 source is later vendored verbatim, retain its LICENSE
alongside this NOTICE.
