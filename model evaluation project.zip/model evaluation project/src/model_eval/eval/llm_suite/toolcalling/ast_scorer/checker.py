"""BFCL AST checker (FR-026b, Q2). See NOTICE.md for provenance.

Deterministic, no judge LLM. Validates the predicted function name AND argument
values against BFCL "possible answers" (a list of acceptable values per param).
Leaderboard-faithful for the single-turn AST categories.
"""

from __future__ import annotations

import json
from dataclasses import dataclass


@dataclass(frozen=True)
class AstResult:
    correct: bool
    reason: str = ""


def _parse_arguments(args: object) -> dict:
    """Normalize a model's tool-call arguments to a dict (may arrive as JSON str)."""
    if isinstance(args, str):
        try:
            parsed = json.loads(args or "{}")
        except json.JSONDecodeError:
            return {}
        return parsed if isinstance(parsed, dict) else {}
    if isinstance(args, dict):
        return args
    return {}


def _accepted_values(value: object) -> list:
    """A ground-truth param maps to either a single value or a list of acceptable ones."""
    return value if isinstance(value, list) else [value]


def _omittable(accepted: list) -> bool:
    """True if the parameter may be omitted (empty/None is acceptable)."""
    return any(v in ("", None) for v in accepted)


def match_call(expected: dict, actual: dict) -> bool:
    """True if ``actual`` satisfies the ground-truth call ``expected``."""
    if expected.get("name") != actual.get("name"):
        return False
    exp_args: dict = expected.get("arguments", {}) or {}
    act_args = _parse_arguments(actual.get("arguments", {}))
    for param, gt_value in exp_args.items():
        accepted = _accepted_values(gt_value)
        if param not in act_args:
            if _omittable(accepted):
                continue
            return False
        if act_args[param] not in accepted:
            return False
    return True


def score(expected_calls: list[dict], actual_calls: list[dict]) -> AstResult:
    """Score a (possibly parallel) AST entry. 1.0 only if all calls match one-to-one.

    ``expected_calls`` and ``actual_calls`` are lists of {"name", "arguments"}.
    For ``simple`` each list has one element; for ``parallel*`` several.
    """
    if len(expected_calls) != len(actual_calls):
        return AstResult(
            False,
            f"expected {len(expected_calls)} call(s), got {len(actual_calls)}",
        )
    remaining = list(actual_calls)
    for expected in expected_calls:
        idx = next(
            (i for i, act in enumerate(remaining) if match_call(expected, act)),
            None,
        )
        if idx is None:
            return AstResult(False, f"no matching call for {expected.get('name')!r}")
        remaining.pop(idx)
    return AstResult(True, "")
