"""Shared types for the LLM suite (axis points, scorer protocol, metric sets).

Keeping the scoring backend behind a Protocol lets the orchestrator and the
sub-evaluations run end-to-end in tests with a fake scorer/provider, while the
production path uses deepeval with the local judge (FR-040, Principle III).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

DEFAULT_THRESHOLD = 0.5

# Axis points (FR-021/022).
CONTEXT_SIZES: tuple[int, ...] = (5000, 10000, 20000, 30000, 50000)
TOOL_COUNTS: tuple[int, ...] = (5, 10, 20, 30, 50)

# LLM-as-judge quality metrics per sub-evaluation (FR-027/030). Each becomes one
# AxisResult per axis point.
CHATBOT_METRICS: tuple[str, ...] = ("answer_relevancy", "knowledge_retention")
RAG_METRICS: tuple[str, ...] = ("faithfulness", "contextual_relevancy")

# The deterministic tool-calling metric (BFCL native AST, no judge).
TOOL_METRIC = "bfcl_ast"


@dataclass(frozen=True)
class AxisPoint:
    """One result row to be persisted as an AxisResult."""

    sub_evaluation: str            # chatbot | rag | tool-calling
    axis_kind: str                 # context-window | tool-count
    axis_value: int
    metric_name: str
    status: str                    # scored | skipped | failed
    score: float | None = None
    threshold: float | None = None
    passed: bool | None = None
    reason: str | None = None


class QualityScorer(Protocol):
    """Scores an LLM-as-judge quality metric on a 0–1 scale (the local judge)."""

    def score(
        self,
        *,
        sub_evaluation: str,
        metric_name: str,
        prompt: str,
        output: str,
        context: str,
        expected: str,
    ) -> float:
        ...
