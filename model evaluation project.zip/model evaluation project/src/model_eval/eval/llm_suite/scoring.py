"""Production quality scorer backed by deepeval + the local judge (R5, FR-040).

Builds deepeval metrics with the local judge model passed explicitly as
``model=`` so no external grader is ever contacted (Constitution Principle III).
This module is only exercised in real runs; tests inject a fake QualityScorer.
"""

from __future__ import annotations


class DeepEvalQualityScorer:
    """Scores chatbot/RAG quality metrics with a deepeval local judge."""

    def __init__(self, judge_model) -> None:
        # ``judge_model`` is a deepeval DeepEvalBaseLLM (see providers.deepeval_model).
        self._judge = judge_model

    def score(
        self,
        *,
        sub_evaluation: str,
        metric_name: str,
        prompt: str,
        output: str,
        context: str,
        expected: str,
    ) -> float:
        from deepeval.test_case import LLMTestCase

        test_case = LLMTestCase(
            input=prompt,
            actual_output=output,
            expected_output=expected or None,
            retrieval_context=[context] if context else None,
        )
        metric = self._build_metric(metric_name)
        metric.measure(test_case)
        return float(metric.score)

    def _build_metric(self, metric_name: str):
        """Map a metric name to a deepeval metric bound to the local judge."""
        from deepeval.metrics import (
            AnswerRelevancyMetric,
            ContextualRelevancyMetric,
            FaithfulnessMetric,
            GEval,
        )
        from deepeval.test_case import LLMTestCaseParams

        judge = self._judge
        if metric_name == "answer_relevancy":
            return AnswerRelevancyMetric(model=judge)
        if metric_name == "faithfulness":
            return FaithfulnessMetric(model=judge)
        if metric_name == "contextual_relevancy":
            return ContextualRelevancyMetric(model=judge)
        if metric_name == "knowledge_retention":
            # No native single-turn metric; use a G-Eval rubric on needle recall.
            return GEval(
                name="knowledge_retention",
                criteria=(
                    "Does the output correctly recall and use the key fact present "
                    "in the provided context (the 'needle'), without contradicting it?"
                ),
                evaluation_params=[
                    LLMTestCaseParams.INPUT,
                    LLMTestCaseParams.ACTUAL_OUTPUT,
                    LLMTestCaseParams.RETRIEVAL_CONTEXT,
                ],
                model=judge,
            )
        raise ValueError(f"unknown quality metric: {metric_name!r}")
