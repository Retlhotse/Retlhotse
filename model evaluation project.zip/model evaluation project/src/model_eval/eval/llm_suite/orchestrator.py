"""Combined LLM-suite orchestrator (FR-020).

Runs chatbot + RAG + tool-calling as ONE indivisible job and persists every
axis point via the repository. The three sub-evaluations cannot be run alone.
If no judge is configured, the LLM-as-judge sub-evaluations (chatbot, RAG) do
not run and are recorded skipped-with-reason (FR-041); tool-calling is
deterministic and always runs.
"""

from __future__ import annotations

from model_eval.datasets.loaders import QAItem
from model_eval.eval.axis.needle import Tokenizer
from model_eval.eval.llm_suite import chatbot, rag
from model_eval.eval.llm_suite import scoring  # noqa: F401  (re-export convenience)
from model_eval.eval.llm_suite.base import (
    CHATBOT_METRICS,
    CONTEXT_SIZES,
    RAG_METRICS,
    TOOL_COUNTS,
    AxisPoint,
    QualityScorer,
)
from model_eval.eval.llm_suite.toolcalling import scorer as tool_scorer
from model_eval.eval.llm_suite.toolcalling.bfcl_loader import BfclTask
from model_eval.providers.base import ChatProvider


def run_llm_combined(
    *,
    run_id: int,
    repo,
    provider: ChatProvider,
    scorer: QualityScorer | None,
    qa_item: QAItem,
    chatbot_filler: str,
    rag_corpus: str,
    bfcl_task: BfclTask,
    distractor_pool: list[dict],
    judge_configured: bool,
    max_context: int | None = None,
    tokenizer: Tokenizer | None = None,
    seed: int = 0,
) -> list[AxisPoint]:
    total = len(CONTEXT_SIZES) * 2 + len(TOOL_COUNTS)  # axis points (not metrics)
    counter = {"done": 0}

    def progress(sub: str, axis: int) -> None:
        counter["done"] += 1
        repo.update_progress(
            run_id,
            {"current_sub": sub, "current_axis_point": axis,
             "done": counter["done"], "total": total},
        )

    if judge_configured and scorer is not None:
        chatbot_points = chatbot.evaluate(
            provider=provider, scorer=scorer, qa_item=qa_item,
            filler=chatbot_filler, max_context=max_context,
            tokenizer=tokenizer, progress=progress,
        )
        rag_points = rag.evaluate(
            provider=provider, scorer=scorer, qa_item=qa_item,
            distractor_corpus=rag_corpus, max_context=max_context,
            tokenizer=tokenizer, progress=progress,
        )
    else:
        chatbot_points = _judge_unavailable("chatbot", CHATBOT_METRICS)
        rag_points = _judge_unavailable("rag", RAG_METRICS)
        for size in CONTEXT_SIZES:
            progress("chatbot", size)
        for size in CONTEXT_SIZES:
            progress("rag", size)

    tool_points = tool_scorer.evaluate(
        provider=provider, task=bfcl_task, distractor_pool=distractor_pool,
        seed=seed, progress=progress,
    )

    all_points = [*chatbot_points, *rag_points, *tool_points]
    for p in all_points:
        repo.add_axis_result(
            run_id=run_id,
            sub_evaluation=p.sub_evaluation,
            axis_kind=p.axis_kind,
            axis_value=p.axis_value,
            metric_name=p.metric_name,
            status=p.status,
            score=p.score,
            threshold=p.threshold,
            passed=p.passed,
            reason=p.reason,
        )
    return all_points


def _judge_unavailable(sub: str, metrics: tuple[str, ...]) -> list[AxisPoint]:
    return [
        AxisPoint(sub, "context-window", size, metric,
                  status="skipped", reason="no judge configured (FR-041)")
        for size in CONTEXT_SIZES
        for metric in metrics
    ]
