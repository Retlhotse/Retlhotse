"""Chatbot sub-evaluation (FR-021/027/028).

Sweeps the context-window axis via needle-in-haystack: at each size the
answer-bearing needle is embedded in filler, the model answers, and the local
judge scores conversational quality metrics. Oversized needles or sizes beyond
the model's declared max are recorded skipped-with-reason (FR-023/024).
"""

from __future__ import annotations

from collections.abc import Callable

from model_eval.datasets.loaders import QAItem
from model_eval.eval.axis.needle import (
    NeedleTooLarge,
    Tokenizer,
    synthesize_context,
)
from model_eval.eval.llm_suite.base import (
    CHATBOT_METRICS,
    CONTEXT_SIZES,
    DEFAULT_THRESHOLD,
    AxisPoint,
    QualityScorer,
)
from model_eval.providers.base import ChatMessage, ChatProvider

ProgressCb = Callable[[str, int], None] | None


def _needle_text(item: QAItem) -> str:
    """The answer-bearing content to plant. Prefer the context, else Q+A."""
    return item.context or f"Note: the answer to '{item.question}' is {item.answer}."


def evaluate(
    *,
    provider: ChatProvider,
    scorer: QualityScorer,
    qa_item: QAItem,
    filler: str,
    sizes: tuple[int, ...] = CONTEXT_SIZES,
    threshold: float = DEFAULT_THRESHOLD,
    max_context: int | None = None,
    tokenizer: Tokenizer | None = None,
    progress: ProgressCb = None,
) -> list[AxisPoint]:
    points: list[AxisPoint] = []
    for size in sizes:
        if max_context is not None and size > max_context:
            points.extend(
                _skip_all(size, "exceeds model max context window")
            )
            if progress:
                progress("chatbot", size)
            continue
        try:
            ctx = synthesize_context(
                needle=_needle_text(qa_item),
                filler=filler,
                target_tokens=size,
                tokenizer=tokenizer,
            )
        except NeedleTooLarge as exc:
            points.extend(_skip_all(size, str(exc)))
            if progress:
                progress("chatbot", size)
            continue

        prompt = f"Context:\n{ctx.text}\n\nQuestion: {qa_item.question}"
        output = provider.complete([ChatMessage(role="user", content=prompt)])
        for metric in CHATBOT_METRICS:
            s = scorer.score(
                sub_evaluation="chatbot",
                metric_name=metric,
                prompt=qa_item.question,
                output=output,
                context=ctx.text,
                expected=qa_item.answer,
            )
            points.append(
                AxisPoint(
                    "chatbot", "context-window", size, metric,
                    status="scored", score=s, threshold=threshold,
                    passed=s >= threshold,
                )
            )
        if progress:
            progress("chatbot", size)
    return points


def _skip_all(size: int, reason: str) -> list[AxisPoint]:
    return [
        AxisPoint("chatbot", "context-window", size, metric, status="skipped", reason=reason)
        for metric in CHATBOT_METRICS
    ]
