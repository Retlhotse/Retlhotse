"""Runner handler for the combined LLM suite (FR-020/072, Principle II).

Bridges the background worker (eval/runner.py) and the orchestrator: gathers
inputs (provider, judge/scorer, datasets) and enforces dataset presence (fail
fast, Principle II), then runs the suite. The worker derives
completed/partial/failed from the persisted points afterwards.

``build_inputs`` is injectable so integration tests can drive the full
worker→handler→orchestrator path with fakes (no live models/datasets/network).
"""

from __future__ import annotations

from collections.abc import Callable

from model_eval.datasets.loaders import QAItem, load_jsonl, load_qa_base
from model_eval.datasets.registry import DatasetRegistry, repository_resolver
from model_eval.eval.llm_suite.orchestrator import run_llm_combined
from model_eval.eval.llm_suite.scoring import DeepEvalQualityScorer
from model_eval.eval.llm_suite.toolcalling.bfcl_loader import load_ast_tasks
from model_eval.providers import build_provider
from model_eval.providers.deepeval_model import make_local_judge

# build_inputs(repo, run) -> dict of kwargs for run_llm_combined (minus run_id/repo)
BuildInputs = Callable[[object, object], dict]


def make_llm_combined_handler(*, build_inputs: BuildInputs | None = None):
    """Return a RunHandler for ``suite_type == 'llm-combined'``."""
    gather = build_inputs or default_build_inputs

    def handler(run_id: int, repo) -> None:
        run = repo.get_run(run_id)
        inputs = gather(repo, run)  # may raise DatasetNotProvisioned -> worker -> failed
        run_llm_combined(run_id=run_id, repo=repo, **inputs)

    return handler


def default_build_inputs(repo, run) -> dict:
    """Production input gathering: real provider, judge, and local datasets."""
    model = repo.get_model(run["model_config_id"])
    provider = build_provider(_row_to_dict(model))

    # Datasets must be present locally — fail fast, never fetch (FR-013).
    registry = DatasetRegistry(repository_resolver(repo))
    registry.ensure_present("llm-combined")

    qa_path = repo.get_dataset("chatbot_qa_base")["local_path"]
    filler_path = repo.get_dataset("filler_corpus")["local_path"]
    rag_path = repo.get_dataset("rag_corpus")["local_path"]
    bfcl_path = repo.get_dataset("bfcl_ast")["local_path"]

    qa_items = load_qa_base(qa_path)
    qa_item = qa_items[0]
    chatbot_filler = _read_text(filler_path)
    rag_corpus = _read_text(rag_path)

    tasks = load_ast_tasks(bfcl_path, "simple")
    bfcl_task = tasks[0]
    distractor_pool = [tool for t in tasks for tool in t.tools]

    judge_id = repo.get_judge_model_id()
    judge_configured = judge_id is not None
    scorer = None
    if judge_configured:
        judge_cfg = repo.get_model(judge_id)
        judge_provider = build_provider(_row_to_dict(judge_cfg))
        scorer = DeepEvalQualityScorer(make_local_judge(judge_provider))

    return {
        "provider": provider,
        "scorer": scorer,
        "qa_item": qa_item,
        "chatbot_filler": chatbot_filler,
        "rag_corpus": rag_corpus,
        "bfcl_task": bfcl_task,
        "distractor_pool": distractor_pool,
        "judge_configured": judge_configured,
        "max_context": model["max_context_window"],
    }


def _row_to_dict(row) -> dict:
    return {k: row[k] for k in row.keys()}


def _read_text(path: str) -> str:
    from pathlib import Path

    return Path(path).read_text(encoding="utf-8")


__all__ = ["QAItem", "load_jsonl", "make_llm_combined_handler", "default_build_inputs"]
