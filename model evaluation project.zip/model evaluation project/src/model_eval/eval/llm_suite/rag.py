"""RAG sub-evaluation (FR-030/031/032).

Mirrors the chatbot context axis but varies the injected *retrieval-context*
token budget, holding a fixed relevant:distractor ratio (default ~10% relevant /
~90% distractor) so growth measures retrieval robustness, not relevance density.
The relevant chunk is the answer-bearing content; distractors come from the
local corpus. LLM-as-judge RAG metrics are scored by the local judge.
"""

from __future__ import annotations

from collections.abc import Callable

from model_eval.datasets.loaders import QAItem
from model_eval.eval.axis.needle import (
    NeedleTooLarge,
    Tokenizer,
    synthesize_context,
)
from model_eval.eval.llm_suite.base import (
    CONTEXT_SIZES,
    DEFAULT_THRESHOLD,
    RAG_METRICS,
    AxisPoint,
    QualityScorer,
)
from model_eval.providers.base import ChatMessage, ChatProvider

ProgressCb = Callable[[str, int], None] | None

# Fixed relevant-content fraction held constant across sizes (FR-031).
RELEVANT_FRACTION = 0.10


def evaluate(
    *,
    provider: ChatProvider,
    scorer: QualityScorer,
    qa_item: QAItem,
    distractor_corpus: str,
    sizes: tuple[int, ...] = CONTEXT_SIZES,
    threshold: float = DEFAULT_THRESHOLD,
    max_context: int | None = None,
    tokenizer: Tokenizer | None = None,
    progress: ProgressCb = None,
) -> list[AxisPoint]:
    points: list[AxisPoint] = []
    relevant = qa_item.context or f"{qa_item.question} {qa_item.answer}"
    for size in sizes:
        if max_context is not None and size > max_context:
            points.extend(_skip_all(size, "exceeds model max context window"))
            if progress:
                progress("rag", size)
            continue
        # The relevant chunk occupies ~RELEVANT_FRACTION of the budget; distractors
        # fill the rest. Reuse needle synthesis with a depth derived from the ratio.
        try:
            ctx = synthesize_context(
                needle=relevant,
                filler=distractor_corpus,
                target_tokens=size,
                position_ratio=RELEVANT_FRACTION,
                tokenizer=tokenizer,
            )
        except NeedleTooLarge as exc:
            points.extend(_skip_all(size, str(exc)))
            if progress:
                progress("rag", size)
            continue

        prompt = qa_item.question
        output = provider.complete(
            [
                ChatMessage(role="system", content=f"Use only this context:\n{ctx.text}"),
                ChatMessage(role="user", content=prompt),
            ]
        )
        for metric in RAG_METRICS:
            s = scorer.score(
                sub_evaluation="rag",
                metric_name=metric,
                prompt=prompt,
                output=output,
                context=ctx.text,
                expected=qa_item.answer,
            )
            points.append(
                AxisPoint(
                    "rag", "context-window", size, metric,
                    status="scored", score=s, threshold=threshold,
                    passed=s >= threshold,
                )
            )
        if progress:
            progress("rag", size)
    return points


def _skip_all(size: int, reason: str) -> list[AxisPoint]:
    return [
        AxisPoint("rag", "context-window", size, metric, status="skipped", reason=reason)
        for metric in RAG_METRICS
    ]
