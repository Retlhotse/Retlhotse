"""Background run worker + run lifecycle (FR-072, research.md R3).

A single worker thread serializes runs (one ``running`` at a time; others
``queued``) and writes state/progress to SQLite so the UI can observe progress
without blocking and survive navigation (SC-007). Suite-specific execution is
provided by handlers registered per ``suite_type`` (filled in for US2/US3); this
module owns only orchestration and the fail-loud transitions (Principle V).

On startup the worker reaps any stale ``running`` row as ``interrupted`` — a
``running`` run with no live worker means the process died mid-run.
"""

from __future__ import annotations

import threading
import time
from collections.abc import Callable

from model_eval.db.repository import Repository

# A handler drives one run to completion, recording results via the repository.
# It MUST raise on fatal failure; the worker maps that to a `failed` transition.
RunHandler = Callable[[int, Repository], None]


class RunWorker:
    def __init__(
        self,
        db_path: str,
        handlers: dict[str, RunHandler],
        *,
        poll_interval: float = 1.0,
    ) -> None:
        self._db_path = db_path
        self._handlers = handlers
        self._poll = poll_interval
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()

    # -------------------------------------------------------------- lifecycle
    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        # Reap stale runs from a prior crashed process before accepting work.
        with Repository(self._db_path) as repo:
            repo.reap_stale_running()
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="run-worker", daemon=True)
        self._thread.start()

    def stop(self, timeout: float | None = None) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout)

    # ------------------------------------------------------------------- loop
    def _loop(self) -> None:
        while not self._stop.is_set():
            run_id = self._claim_next_queued()
            if run_id is None:
                time.sleep(self._poll)
                continue
            self._execute(run_id)

    def _claim_next_queued(self) -> int | None:
        with Repository(self._db_path) as repo:
            rows = repo.list_runs()
            queued = [r for r in rows if r["status"] == "queued"]
            if not queued:
                return None
            # FIFO: lowest id first.
            run_id = min(r["id"] for r in queued)
            repo.transition_run(run_id, "running")
            return run_id

    def _execute(self, run_id: int) -> None:
        with Repository(self._db_path) as repo:
            run = repo.get_run(run_id)
            handler = self._handlers.get(run["suite_type"])
            if handler is None:
                repo.transition_run(
                    run_id, "failed",
                    failure_reason=f"no handler for suite_type {run['suite_type']!r}",
                )
                return
            try:
                handler(run_id, repo)
            except Exception as exc:  # noqa: BLE001 - fail loud, never swallow
                # If results were already recorded, finalize to partial; else failed.
                statuses = list(repo._collect_result_statuses(run_id))
                if any(s == "scored" for s in statuses):
                    repo.transition_run(run_id, "partial", failure_reason=str(exc))
                else:
                    repo.transition_run(run_id, "failed", failure_reason=str(exc))
                return
            # Handler succeeded: derive completed vs partial from recorded points.
            repo.finalize_run(run_id)
