"""Per-document extraction scoring adapter (FR-051/053).

Scores a model's predicted Markdown against OmniDocBench ground truth using the
end2end metrics. Malformed/empty model output is scored as-is (not crashed);
a missing latexml when formulas are present fails loud (Principle V).
"""

from __future__ import annotations

from dataclasses import dataclass

from model_eval.eval.extraction.omnidocbench import (
    formula_similarity,
    normalized_edit_distance,
    reading_order_distance,
    teds,
)


@dataclass(frozen=True)
class DocumentGroundTruth:
    """Local OmniDocBench ground truth for one document."""

    document_id: str
    text: str
    reading_order: list[str]
    tables_html: list[str]
    formulas_latex: list[str]


@dataclass(frozen=True)
class DocumentScore:
    document_id: str
    text_edit_distance: float
    reading_order_edit_distance: float
    table_teds: float | None
    formula_score: float | None
    overall: float


def _split_blocks(markdown: str) -> list[str]:
    return [ln.strip() for ln in markdown.splitlines() if ln.strip()]


def score_document(
    *,
    predicted_markdown: str,
    ground_truth: DocumentGroundTruth,
    predicted_tables_html: list[str] | None = None,
    predicted_formulas_latex: list[str] | None = None,
) -> DocumentScore:
    """Score one document. Raises LatexmlUnavailable if formulas need latexml."""
    text_dist = normalized_edit_distance(predicted_markdown, ground_truth.text)
    ro_dist = reading_order_distance(
        _split_blocks(predicted_markdown), ground_truth.reading_order
    )

    # Tables (skip metric if the GT document has no tables).
    table_teds: float | None = None
    if ground_truth.tables_html:
        pred_tables = predicted_tables_html or [""] * len(ground_truth.tables_html)
        scores = [
            teds(p, g)
            for p, g in zip(
                pred_tables + [""] * len(ground_truth.tables_html),
                ground_truth.tables_html,
            )
        ]
        table_teds = sum(scores) / len(scores)

    # Formulas (latexml-gated; absence is fatal — Principle V).
    formula_score: float | None = None
    if ground_truth.formulas_latex:
        pred_formulas = predicted_formulas_latex or [""] * len(ground_truth.formulas_latex)
        scores = [
            formula_similarity(p, g)
            for p, g in zip(
                pred_formulas + [""] * len(ground_truth.formulas_latex),
                ground_truth.formulas_latex,
            )
        ]
        formula_score = sum(scores) / len(scores)

    # Overall = mean of present element similarities (distances -> 1 - distance).
    components = [1.0 - text_dist, 1.0 - ro_dist]
    if table_teds is not None:
        components.append(table_teds)
    if formula_score is not None:
        components.append(formula_score)
    overall = sum(components) / len(components)

    return DocumentScore(
        document_id=ground_truth.document_id,
        text_edit_distance=text_dist,
        reading_order_edit_distance=ro_dist,
        table_teds=table_teds,
        formula_score=formula_score,
        overall=overall,
    )
