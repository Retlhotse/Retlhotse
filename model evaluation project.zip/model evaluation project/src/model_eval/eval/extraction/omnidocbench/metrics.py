"""OmniDocBench end2end metric implementations (FR-053). See NOTICE.md.

Pure-Python and offline. ``latexml`` (external binary) is required only when a
document actually contains formulas; its absence is surfaced loudly.
"""

from __future__ import annotations

import shutil
from collections.abc import Sequence


class LatexmlUnavailable(RuntimeError):
    """Raised when formula scoring is needed but the latexml binary is absent."""


def levenshtein(a: Sequence, b: Sequence) -> int:
    """Edit distance between two sequences (strings or lists of tokens)."""
    if a == b:
        return 0
    la, lb = len(a), len(b)
    if la == 0:
        return lb
    if lb == 0:
        return la
    prev = list(range(lb + 1))
    for i in range(1, la + 1):
        cur = [i] + [0] * lb
        for j in range(1, lb + 1):
            cost = 0 if a[i - 1] == b[j - 1] else 1
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
        prev = cur
    return prev[lb]


def normalized_edit_distance(pred: str, gt: str) -> float:
    """Normalized edit distance in [0, 1] (0 = identical). Char-level."""
    if not pred and not gt:
        return 0.0
    dist = levenshtein(pred, gt)
    return dist / max(len(pred), len(gt))


def reading_order_distance(pred_blocks: Sequence[str], gt_blocks: Sequence[str]) -> float:
    """Normalized block-sequence edit distance in [0, 1] (0 = same order)."""
    if not pred_blocks and not gt_blocks:
        return 0.0
    dist = levenshtein(list(pred_blocks), list(gt_blocks))
    return dist / max(len(pred_blocks), len(gt_blocks))


# --------------------------------------------------------------------- tables
from html.parser import HTMLParser  # noqa: E402


class _TableTreeBuilder(HTMLParser):
    """Build a nested [tag, text, children] tree from HTML using only stdlib."""

    def __init__(self) -> None:
        super().__init__()
        self.root: list = ["root", "", []]
        self._stack: list = [self.root]

    def handle_starttag(self, tag, attrs):  # noqa: ANN001
        node = [tag, "", []]
        self._stack[-1][2].append(node)
        self._stack.append(node)

    def handle_startendtag(self, tag, attrs):  # noqa: ANN001
        self._stack[-1][2].append([tag, "", []])

    def handle_endtag(self, tag):  # noqa: ANN001
        if len(self._stack) > 1:
            self._stack.pop()

    def handle_data(self, data):  # noqa: ANN001
        text = data.strip()
        if text:
            self._stack[-1][1] = (self._stack[-1][1] + text).strip()


def _table_tree(html: str):
    """Parse an HTML table into a nested [tag, text, children] tree (stdlib only)."""
    builder = _TableTreeBuilder()
    builder.feed(html)
    builder.close()
    return builder.root


def _tree_size(node) -> int:
    return 1 + sum(_tree_size(c) for c in node[2])


def _tree_edit_distance(a, b) -> int:
    """A simple structural tree edit distance (label+text match, recursive)."""
    if a is None:
        return _tree_size(b)
    if b is None:
        return _tree_size(a)
    label_cost = 0 if (a[0], a[1]) == (b[0], b[1]) else 1
    ca, cb = a[2], b[2]
    # Sequence-align children with a DP over insert/delete/substitute subtrees.
    n, m = len(ca), len(cb)
    dp = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(1, n + 1):
        dp[i][0] = dp[i - 1][0] + _tree_size(ca[i - 1])
    for j in range(1, m + 1):
        dp[0][j] = dp[0][j - 1] + _tree_size(cb[j - 1])
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            dp[i][j] = min(
                dp[i - 1][j] + _tree_size(ca[i - 1]),
                dp[i][j - 1] + _tree_size(cb[j - 1]),
                dp[i - 1][j - 1] + _tree_edit_distance(ca[i - 1], cb[j - 1]),
            )
    return label_cost + dp[n][m]


def teds(pred_html: str, gt_html: str) -> float:
    """Tree-Edit-Distance-based Similarity in [0, 1] (1 = identical tables)."""
    if not pred_html.strip() and not gt_html.strip():
        return 1.0
    try:
        ta, tb = _table_tree(pred_html), _table_tree(gt_html)
    except Exception:  # noqa: BLE001 - malformed HTML scores 0, never crashes
        return 0.0
    dist = _tree_edit_distance(ta, tb)
    denom = max(_tree_size(ta), _tree_size(tb))
    return 1.0 - dist / denom if denom else 1.0


# ------------------------------------------------------------------- formulas
def latexml_available() -> bool:
    return shutil.which("latexml") is not None


def formula_similarity(pred_latex: str, gt_latex: str) -> float:
    """Formula similarity in [0, 1]. Requires latexml (fail loud if missing)."""
    if not latexml_available():
        raise LatexmlUnavailable(
            "latexml binary not found; cannot score formulas (Principle V: fail loud)"
        )
    # With latexml present, compare canonicalized forms. We use normalized edit
    # distance on the (whitespace-normalized) latex as a stand-in for the rendered
    # comparison; a verbatim OmniDocBench vendoring would render to MathML first.
    pred = " ".join(pred_latex.split())
    gt = " ".join(gt_latex.split())
    return 1.0 - normalized_edit_distance(pred, gt)
