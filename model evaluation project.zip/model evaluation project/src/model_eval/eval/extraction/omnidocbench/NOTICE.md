# OmniDocBench end-to-end metrics — provenance

This module implements the **end-to-end evaluation metrics** of **OmniDocBench**
(https://github.com/opendatalab/OmniDocBench), used to score document-to-Markdown
extraction. OmniDocBench is released under **Apache 2.0**.

It is a self-contained re-implementation of OmniDocBench's end2end metric
**definitions** so the platform can score extraction **offline** (Constitution
Principle I/II; spec FR-052/FR-053):

- **Text** & **reading order**: normalized edit distance (lower is better).
- **Tables**: TEDS (Tree-Edit-Distance-based Similarity) over parsed table trees.
- **Formulas**: a formula similarity gated on the external `latexml` binary; if a
  document contains formulas and `latexml` is unavailable the run **fails loud**
  rather than silently zero-scoring (Constitution Principle V).
- **Overall**: the combined end2end score.

Because this is an independent implementation of the metric definitions (not a
verbatim vendoring of the upstream code), results are recorded with
`scoring_method = "omnidocbench_end2end"` in the run snapshot (Principle IV). If
the upstream Apache-2.0 source is later vendored verbatim, retain its LICENSE
alongside this NOTICE.
