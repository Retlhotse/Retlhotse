"""Text-extraction runner + handler (FR-050/052/054/055, US3).

Runs OmniDocBench document-to-Markdown scoring independently of the LLM suite.
Enforces the document/extraction capability (FR-054) and dataset presence
(Principle II), persists ExtractionResults, and fails loud on a missing latexml.

``build_inputs`` is injectable so integration tests can drive the full
worker -> handler path with fakes (no live model/network required).
"""

from __future__ import annotations

from collections.abc import Callable

from model_eval.datasets.registry import DatasetRegistry, repository_resolver
from model_eval.eval.extraction.omnidocbench import LatexmlUnavailable
from model_eval.eval.extraction.scorer import (
    DocumentGroundTruth,
    score_document,
)

BuildInputs = Callable[[object, object], dict]


class ExtractionCapabilityError(ValueError):
    """The selected model does not declare document/extraction capability (FR-054)."""


def assert_extraction_capable(capabilities: dict) -> None:
    if not capabilities.get("extraction"):
        raise ExtractionCapabilityError(
            "this model is not document/extraction-capable; onboard or select a "
            "model whose capabilities include 'extraction' (FR-054)"
        )


def make_extraction_handler(*, build_inputs: BuildInputs | None = None):
    """Return a RunHandler for ``suite_type == 'text-extraction'``."""
    gather = build_inputs or default_build_inputs

    def handler(run_id: int, repo) -> None:
        run = repo.get_run(run_id)
        inputs = gather(repo, run)  # may raise capability/dataset errors -> failed
        extract_fn = inputs["extract_fn"]
        documents: list[DocumentGroundTruth] = inputs["documents"]
        provider = inputs["provider"]

        for gt in documents:
            predicted = extract_fn(provider, gt)
            try:
                score = score_document(
                    predicted_markdown=predicted.get("markdown", ""),
                    ground_truth=gt,
                    predicted_tables_html=predicted.get("tables"),
                    predicted_formulas_latex=predicted.get("formulas"),
                )
            except LatexmlUnavailable:
                # Fail loud, run-wide (Principle V) — re-raise to the worker.
                raise
            repo.add_extraction_result(
                run_id=run_id,
                document_id=score.document_id,
                status="scored",
                text_edit_distance=score.text_edit_distance,
                reading_order_edit_distance=score.reading_order_edit_distance,
                table_teds=score.table_teds,
                formula_score=score.formula_score,
                overall=score.overall,
            )

    return handler


def default_build_inputs(repo, run) -> dict:
    """Production input gathering: provider, capability gate, local documents."""
    import json

    model = repo.get_model(run["model_config_id"])
    capabilities = json.loads(model["capabilities"]) if model["capabilities"] else {}
    assert_extraction_capable(capabilities)  # FR-054

    registry = DatasetRegistry(repository_resolver(repo))
    registry.ensure_present("text-extraction")  # Principle II

    from model_eval.datasets.loaders import load_jsonl
    from model_eval.providers import build_provider

    docs_path = repo.get_dataset("omnidocbench")["local_path"]
    documents = [
        DocumentGroundTruth(
            document_id=str(rec["id"]),
            text=rec.get("text", ""),
            reading_order=rec.get("reading_order", []),
            tables_html=rec.get("tables", []),
            formulas_latex=rec.get("formulas", []),
        )
        for rec in load_jsonl(docs_path)
    ]

    provider = build_provider({k: model[k] for k in model.keys()})

    def extract_fn(prov, gt: DocumentGroundTruth) -> dict:
        from model_eval.providers.base import ChatMessage

        md = prov.complete(
            [ChatMessage(role="user", content=f"Convert document {gt.document_id} to Markdown.")]
        )
        return {"markdown": md}

    return {
        "provider": provider,
        "documents": documents,
        "extract_fn": extract_fn,
    }


__all__ = [
    "ExtractionCapabilityError",
    "assert_extraction_capable",
    "default_build_inputs",
    "make_extraction_handler",
]
