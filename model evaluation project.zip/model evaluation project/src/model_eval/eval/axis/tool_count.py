"""Tool-count axis synthesis (FR-025).

For a fixed AST task, hold the query + ground-truth tool fixed and pad the
available-tools list with distractor tool *schemas* sampled from other BFCL
entries, so the total number of tools equals the axis point (5/10/20/30/50).
Distractors are de-duplicated by function name and the ground-truth function is
excluded from the distractor pool. Sampling is seeded for reproducibility (FR-IV).
"""

from __future__ import annotations

import random
from dataclasses import dataclass


class InsufficientDistractors(ValueError):
    """Not enough unique distractor tools to reach the requested count."""


@dataclass(frozen=True)
class ToolSet:
    tools: list[dict]
    ground_truth_name: str
    count: int


def tool_name(schema: dict) -> str:
    """Extract the function name from an OpenAI-style or bare tool schema."""
    fn = schema.get("function")
    if isinstance(fn, dict) and "name" in fn:
        return fn["name"]
    return schema["name"]


def build_tool_set(
    *,
    ground_truth_tool: dict,
    distractor_pool: list[dict],
    n: int,
    seed: int = 0,
) -> ToolSet:
    """Return exactly ``n`` tools: the ground-truth tool + (n-1) distractors."""
    if n < 1:
        raise ValueError("n must be >= 1")
    gt_name = tool_name(ground_truth_tool)

    # De-dup distractors by name; never include the ground-truth function.
    seen = {gt_name}
    pool: list[dict] = []
    for schema in distractor_pool:
        name = tool_name(schema)
        if name in seen:
            continue
        seen.add(name)
        pool.append(schema)

    needed = n - 1
    if needed > len(pool):
        raise InsufficientDistractors(
            f"need {needed} distractors for n={n}, have {len(pool)} unique"
        )

    rng = random.Random(seed)
    chosen = rng.sample(pool, needed) if needed > 0 else []
    tools = [ground_truth_tool, *chosen]
    rng.shuffle(tools)  # ground-truth tool not always first
    return ToolSet(tools=tools, ground_truth_name=gt_name, count=len(tools))
