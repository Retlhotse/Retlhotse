"""Single reference tokenizer for the context-window axis (FR-021, R1).

One fixed tokenizer (tiktoken ``cl100k_base``) counts "N tokens" for ALL models
so axis points are cross-model comparable (Q3). The encoding is loaded from the
local ``TIKTOKEN_CACHE_DIR``; if it is not pre-provisioned we fail loud rather
than letting tiktoken attempt a download (Principle II/V).
"""

from __future__ import annotations

import functools

REFERENCE_ENCODING = "cl100k_base"


class TokenizerNotProvisioned(RuntimeError):
    """Raised when the reference tokenizer encoding is not available offline."""


@functools.lru_cache(maxsize=1)
def _encoding():
    try:
        import tiktoken

        return tiktoken.get_encoding(REFERENCE_ENCODING)
    except Exception as exc:  # noqa: BLE001 - surface any offline/cache failure loudly
        raise TokenizerNotProvisioned(
            f"reference tokenizer {REFERENCE_ENCODING!r} unavailable offline; "
            "pre-provision TIKTOKEN_CACHE_DIR"
        ) from exc


def count_tokens(text: str) -> int:
    """Count tokens with the single reference tokenizer."""
    return len(_encoding().encode(text))


def encode(text: str) -> list[int]:
    return _encoding().encode(text)


def decode(tokens: list[int]) -> str:
    return _encoding().decode(tokens)


def truncate_to_tokens(text: str, max_tokens: int) -> str:
    """Return ``text`` trimmed to at most ``max_tokens`` reference tokens.

    Used by filler assembly (NOT for the answer-bearing needle, which is never
    truncated — see FR-023 / needle.py).
    """
    toks = encode(text)
    if len(toks) <= max_tokens:
        return text
    return decode(toks[:max_tokens])
