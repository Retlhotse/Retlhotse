"""Needle-in-haystack context synthesis (FR-023, research.md R2).

deepeval datasets do not vary by length, so the chatbot context-window axis is
synthesized: the answer-bearing "needle" is embedded at a controlled depth
within filler padded to each target token count, measured by the single
reference tokenizer (FR-021/Q3).

If the needle itself exceeds the target size N, the item is skipped at that axis
point (``NeedleTooLarge``) — the answer-bearing content is NEVER truncated
(FR-023, Constitution Principle V).

The tokenizer is injectable so unit tests run without the tiktoken cache; the
default is the single reference tokenizer.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass


class NeedleTooLarge(RuntimeError):
    """The answer-bearing needle does not fit within the target token budget."""


@dataclass(frozen=True)
class Tokenizer:
    count: Callable[[str], int]
    encode: Callable[[str], list[int]]
    decode: Callable[[list[int]], str]


def reference_tokenizer() -> Tokenizer:
    """The production single reference tokenizer (tiktoken cl100k_base)."""
    from model_eval.eval.axis import tokenizer as t

    return Tokenizer(count=t.count_tokens, encode=t.encode, decode=t.decode)


@dataclass(frozen=True)
class SynthesizedContext:
    text: str
    target_tokens: int
    needle_tokens: int
    total_tokens: int
    position_ratio: float


def synthesize_context(
    *,
    needle: str,
    filler: str,
    target_tokens: int,
    position_ratio: float = 0.5,
    tokenizer: Tokenizer | None = None,
) -> SynthesizedContext:
    """Build a context of ~``target_tokens`` with ``needle`` at ``position_ratio`` depth.

    ``position_ratio`` 0.0 = needle at the very start, 1.0 = at the very end.
    Raises ``NeedleTooLarge`` if the needle alone exceeds the budget (skip rule).
    """
    tk = tokenizer or reference_tokenizer()
    needle_tokens = tk.count(needle)
    if needle_tokens > target_tokens:
        raise NeedleTooLarge(
            f"needle ({needle_tokens} tok) exceeds target context {target_tokens} tok"
        )
    remaining = target_tokens - needle_tokens
    before_budget = int(round(remaining * position_ratio))
    after_budget = remaining - before_budget
    before = _fill(filler, before_budget, tk)
    after = _fill(filler, after_budget, tk)
    text = "\n".join(p for p in (before, needle, after) if p)
    return SynthesizedContext(
        text=text,
        target_tokens=target_tokens,
        needle_tokens=needle_tokens,
        total_tokens=tk.count(text),
        position_ratio=position_ratio,
    )


def _fill(filler: str, n_tokens: int, tk: Tokenizer) -> str:
    """Return filler decoded to exactly ``n_tokens`` tokens, repeating as needed."""
    if n_tokens <= 0 or not filler:
        return ""
    base = tk.encode(filler)
    if not base:
        return ""
    out: list[int] = []
    while len(out) < n_tokens:
        out.extend(base)
    return tk.decode(out[:n_tokens])
