"""Enterprise Model Evaluation Platform.

Air-gapped Streamlit application that onboards local/Azure models and runs
LLM-suite (chatbot + RAG + tool-calling via deepeval) and text-extraction
(OmniDocBench) evaluations against locally-provisioned datasets.

See specs/001-model-evaluation-platform/ for the spec, plan, and tasks.
Governed by .specify/memory/constitution.md (v1.0.0) — air-gap and local-judge
are non-negotiable.
"""

__version__ = "0.1.0"
