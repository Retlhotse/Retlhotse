<!--
SYNC IMPACT REPORT
==================
Version change: 1.0.0 → 2.0.0
Bump rationale: MAJOR — backward-incompatible redefinition of two principles.
The enterprise air-gap requirement was relaxed at the owner's direction: the
platform must be able to evaluate models hosted ANYWHERE (local or remote),
connected through a universal provider layer (LangChain). This removes the
non-negotiable air-gap (old Principle I) and local-judge-only (old Principle III)
constraints.

Principles changed:
  I.   Air-Gapped Operation (NON-NEGOTIABLE)  →  I. Provider Neutrality & Connectivity
  III. Local Judge Only                       →  III. Single Configurable Judge (any provider)
  VII. Verifiability of Critical Paths        →  reworded: egress-guard test removed;
        provider-abstraction test added.
Principles retained unchanged in intent: II (Datasets Provisioned — reframed to
  reproducibility, no longer air-gap), IV (Traceability), V (Fail Loud), VI
  (Credential Safety).

Technology constraints changed:
  - Model connectivity: openai SDK (local + Azure)  →  LangChain (universal:
    OpenAI, Anthropic, Azure, Google, Ollama, any OpenAI-compatible endpoint).
  - BFCL AST-only retained, but justified by scope/determinism, not air-gap.

Removed: the egress guard, offline-mode enforcement, and the per-feature
  "no waiver" rule for the old air-gap/local-judge principles.

Template / artifact consistency:
  ✅ .specify/templates/plan-template.md  — dynamic Constitution Check; no edit.
  ✅ .specify/templates/spec-template.md  — generic; no edit.
  ✅ .specify/templates/tasks-template.md — generic; Principle VII still makes
        critical-path tests mandatory (provider abstraction, scoring adapters,
        axis construction, persistence) — egress-guard test no longer applies.
  ⚠ specs/001-model-evaluation-platform/ (spec, plan, research, data-model,
        contracts, tasks) — UPDATED in the same change to match (remove air-gap
        FRs, switch to LangChain, judge any provider).
  ⚠ CLAUDE.md — UPDATED to reflect LangChain + open connectivity.

Deferred / TODO items:
  - TODO(ACCOUNTABLE_OWNER): Amendment Procedure step 2 still names no approving
        role/team.
-->

# Enterprise Model Evaluation Platform Constitution

**Version**: 2.0.0 | **Ratified**: 2026-06-30 | **Last Amended**: 2026-07-01

This constitution defines the binding principles governing the Enterprise Model Evaluation Platform. Every specification, plan, and implementation MUST comply. The `/speckit.analyze` gate evaluates artifacts against these principles; violations must be resolved or explicitly justified before implementation.

Detailed contracts, schemas, and axis definitions live in feature specifications (`specs/[feature]/`), not here. This document states the rules and the reasons for them.

---

## Core Principles

### I. Provider Neutrality & Connectivity

The platform MUST be able to evaluate models hosted anywhere — locally, in a private cloud, or behind a public API — through a single, uniform provider abstraction.

- All model access (candidate models AND the judge) goes through one universal provider layer (LangChain), so onboarding a new backend is configuration, not code: a `provider` + `model` (+ optional endpoint/credentials) is enough.
- Outbound network access to model endpoints is permitted. The platform does NOT enforce an air-gap or an egress allowlist. *(An optional offline/restricted deployment may be re-introduced by amendment if an enterprise needs it; it is not a default.)*
- Adding a model provider MUST NOT require changes to the evaluation engine, scoring, or persistence — only the provider/config layer.

**Rationale**: The platform's value is comparing many candidate models on equal footing. Universality of connection — "test a model from anywhere with the same workflow" — is the point. A provider abstraction makes that an onboarding detail rather than an engineering project.

### II. Datasets Are Provisioned, Not Fetched

All benchmark and evaluation data is provisioned ahead of time and read from local storage at run time.

- The platform MUST NOT download, fetch, or remotely resolve a benchmark dataset during a run.
- A required dataset that is absent locally MUST cause a fast, explicit failure naming the missing dataset — never a silent fallback and never a partial run presented as complete.
- Before a run starts, the platform MUST be able to report which datasets are required and whether each is present locally.

**Rationale**: Reproducibility depends on data being a fixed, local, auditable input rather than something resolved over the network at unpredictable times. (This is about *data* provenance, independent of model connectivity.)

### III. Single Configurable Judge

LLM-as-judge metrics (RAG and conversational quality, G-Eval-style metrics) MUST be graded by a single, globally-configured judge model, which MAY be local or remote.

- Exactly one judge is in effect at a time; it is configured explicitly, never defaulted silently.
- If no judge is configured, judge-dependent metrics MUST NOT run (and MUST report why) rather than grading with an unspecified model.
- The judge model in effect MUST be captured in each run's snapshot (see Principle IV).
- Deterministic metrics (tool-call AST correctness, OmniDocBench edit-distance/TEDS) require no judge and are unaffected.

**Rationale**: Comparability requires that every judged metric in a run used the *same, named* grader. Which model that is, is the operator's choice — what matters is that it is explicit and recorded.

### IV. Faithful and Traceable Measurement

Every result MUST be reproducible from recorded inputs, and every deviation from a benchmark's native methodology MUST be disclosed, not hidden.

- Each run MUST persist enough provenance to reproduce it: model configuration snapshot (provider, model, endpoint), dataset identity and version, judge model, axis points, thresholds, reference tokenizer, and scoring method.
- Where the platform scores a benchmark using a method other than that benchmark's native one, the scoring method MUST be recorded with the result and labeled as not directly comparable to the benchmark's public leaderboard.
- Synthesized evaluation axes (context-window padding, distractor-padded tool counts) MUST record how they were constructed.
- Scores MUST NOT be silently approximated, substituted, or interpolated.

**Rationale**: Results drive model-adoption decisions. A number whose method or inputs cannot be named or reproduced is not evidence. Stated methodology must match what the code actually did.

### V. Fail Loud, Never Silently Degrade

The platform surfaces problems explicitly and never disguises a degraded run as a successful one.

- Runs MUST carry explicit states (queued / running / completed / failed / interrupted / partial). A run missing some axis points is `partial`, never `completed`.
- Failure conditions — missing dataset, unreachable judge or model, context-window overflow beyond a model's capacity, malformed model output — MUST be recorded with a reason at the affected granularity, while unaffected results are retained.
- The platform MUST NOT silently substitute a smaller context, a different dataset, or a different model to "make a run succeed."

**Rationale**: A misleading green result is worse than an honest failure, because it corrupts the decision the platform exists to support.

### VI. Credential Safety

Model configurations carry live credentials (now potentially remote provider keys) and MUST be protected accordingly.

- API keys MUST be stored such that they are never rendered in plaintext in the UI, logs, error messages, or result exports.
- Credentials MUST NOT be embedded in URLs, query strings, or telemetry.

**Rationale**: Onboarding deliberately accepts API keys for many providers; the platform must not become the place they leak.

### VII. Verifiability of Critical Paths

Correctness-critical behavior MUST be covered by automated tests.

- At minimum, automated tests MUST cover: the provider abstraction (a fake provider drives a full run without a live model), scoring adapters (BFCL AST + OmniDocBench), axis construction (context-window and tool-count synthesis), and result persistence (state machine, partial vs completed).
- Tests MUST be able to exercise the full `worker → handler → orchestrator` path with injected fakes, with no network access required.

**Rationale**: The platform's value rests on guarantees (correct scoring, honest persistence, uniform provider behavior) that are invisible at the UI layer; only tests make those guarantees real. *(This principle may be hardened to full test-first/TDD by amendment if the team chooses.)*

---

## Technology & Architecture Constraints

These choices are organizationally mandated and are not subject to per-feature plan negotiation:

- **Language**: Python.
- **Application**: Streamlit, presenting exactly three pages — Onboarding, Evaluation, Results.
- **Persistence**: SQLite (single embedded local datastore; no external datastore). Single-node operation assumed for v1.
- **Model connectivity**: LangChain, providing a universal interface to any supported backend (OpenAI, Anthropic, Azure OpenAI, Google, Ollama, and any OpenAI-compatible endpoint). Used for both candidate models and the judge.
- **LLM-suite evaluation**: deepeval, for chatbot, RAG, and tool-calling. These three run together as one indivisible job.
- **Text-extraction evaluation**: OmniDocBench, run standalone.
- **Tool-calling dataset**: BFCL (Apache 2.0), AST categories only — Executable and V3 multi-turn categories are excluded because they require live API execution or a stateful backend (scope/determinism reasons, not connectivity).
- **Long-running work**: evaluations MUST NOT block the interface; run state and progress live in SQLite so a user can navigate away and return to accurate status.

Deviation from any mandated technology requires a constitutional amendment, not a plan-level exception.

---

## Governance

This constitution supersedes ad-hoc practice. When guidance conflicts, the constitution wins; specifications refine it but may not weaken it.

### Amendment Procedure
1. Propose the change via pull request describing the principle affected and a concrete motivating case.
2. Obtain approval from TODO(ACCOUNTABLE_OWNER): name the accountable role or team responsible for approving amendments.
3. Update the version per the policy below and set **Last Amended** to the change date.
4. Propagate the change to dependent Spec Kit templates and the active feature's spec/plan/tasks so the gate stays consistent.

### Versioning Policy
- **MAJOR**: Backward-incompatible removal or redefinition of a principle or governance rule.
- **MINOR**: New principle/section added or material expansion of guidance.
- **PATCH**: Clarifications, wording, and non-semantic refinements.

### Compliance Review
- `/speckit.analyze` MUST be run before implementation; it checks every spec and plan against these principles.
- Any accepted violation MUST be documented with justification and a remediation item; it MUST NOT be silently merged.

---

**Version**: 2.0.0 | **Ratified**: 2026-06-30 | **Last Amended**: 2026-07-01
