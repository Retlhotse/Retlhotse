"""Integration test for the Results read views (T051, US4, FR-062/063/009)."""

from __future__ import annotations

import pytest

from model_eval.config.secret import SecretRef
from model_eval.db.repository import Repository
from model_eval.db.results import (
    axis_drilldown,
    compare_axis,
    document_drilldown,
    list_run_summaries,
)


@pytest.fixture
def repo(tmp_db_path) -> Repository:
    r = Repository(tmp_db_path)
    yield r
    r.close()


def _combined_run(repo: Repository, model_id: int, *, chatbot_score: float) -> int:
    run_id = repo.create_run(
        model_config_id=model_id, suite_type="llm-combined", config_snapshot={}
    )
    repo.transition_run(run_id, "running")
    for size in (5000, 10000):
        repo.add_axis_result(
            run_id=run_id, sub_evaluation="chatbot", axis_kind="context-window",
            axis_value=size, metric_name="answer_relevancy", status="scored",
            score=chatbot_score, threshold=0.5, passed=chatbot_score >= 0.5,
        )
    repo.add_axis_result(
        run_id=run_id, sub_evaluation="tool-calling", axis_kind="tool-count",
        axis_value=5, metric_name="bfcl_ast", status="scored", score=1.0,
        threshold=1.0, passed=True,
    )
    repo.finalize_run(run_id)
    return run_id


def test_list_and_axis_drilldown(repo: Repository) -> None:
    mid = repo.add_model(
        name="m1", provider="local", model="fake-model", endpoint_url="http://h/v1",
        capabilities={"chat_suite": True},
    )
    run_id = _combined_run(repo, mid, chatbot_score=0.8)
    summaries = list_run_summaries(repo)
    assert summaries[0].model_name == "m1" and summaries[0].suite_type == "llm-combined"
    rows = axis_drilldown(repo, run_id)
    assert len(rows) == 3
    assert {r["sub_evaluation"] for r in rows} == {"chatbot", "tool-calling"}


def test_document_drilldown(repo: Repository) -> None:
    mid = repo.add_model(
        name="doc", provider="local", model="fake-model", endpoint_url="http://h/v1",
        capabilities={"extraction": True},
    )
    run_id = repo.create_run(
        model_config_id=mid, suite_type="text-extraction", config_snapshot={}
    )
    repo.transition_run(run_id, "running")
    repo.add_extraction_result(
        run_id=run_id, document_id="d1", status="scored",
        text_edit_distance=0.1, overall=0.9,
    )
    repo.finalize_run(run_id)
    rows = document_drilldown(repo, run_id)
    assert rows[0]["document_id"] == "d1" and rows[0]["overall"] == 0.9


def test_compare_same_axis(repo: Repository) -> None:
    m1 = repo.add_model(name="a", provider="local", model="fake-model", endpoint_url="http://h/v1",
                        capabilities={"chat_suite": True})
    m2 = repo.add_model(name="b", provider="local", model="fake-model", endpoint_url="http://h/v1",
                        capabilities={"chat_suite": True})
    r1 = _combined_run(repo, m1, chatbot_score=0.8)
    r2 = _combined_run(repo, m2, chatbot_score=0.6)
    rows = compare_axis(repo, r1, r2)
    chatbot_rows = [x for x in rows if x["sub_evaluation"] == "chatbot"]
    assert chatbot_rows
    for row in chatbot_rows:
        assert row[f"run_{r1}"] == 0.8 and row[f"run_{r2}"] == 0.6


def test_compare_rejects_different_suite_types(repo: Repository) -> None:
    mid = repo.add_model(name="x", provider="local", model="fake-model", endpoint_url="http://h/v1",
                         capabilities={"chat_suite": True, "extraction": True})
    r1 = _combined_run(repo, mid, chatbot_score=0.5)
    r2 = repo.create_run(model_config_id=mid, suite_type="text-extraction", config_snapshot={})
    with pytest.raises(ValueError, match="same suite type"):
        compare_axis(repo, r1, r2)


def test_results_never_expose_api_key(repo: Repository) -> None:
    repo.add_model(
        name="secretive", provider="local", model="fake-model", endpoint_url="http://h/v1",
        api_key="sk-topsecret4242", capabilities={"chat_suite": True},
    )
    # The results views expose model names/scores, never the api_key column.
    summaries = list_run_summaries(repo)
    serialized = str([s.__dict__ for s in summaries])
    assert "topsecret" not in serialized
    # And the canonical masking path hides it.
    row = repo.list_models()[0]
    assert "topsecret" not in SecretRef(row["api_key"]).masked()
