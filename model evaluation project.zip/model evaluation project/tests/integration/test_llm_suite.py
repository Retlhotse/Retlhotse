"""Integration test for the combined LLM suite (T041, amended T066, US2).

Drives the full worker -> handler -> orchestrator path with injected fakes (no
live models/datasets/network). Verifies: a complete run produces >=15 axis
results; dataset fail-fast marks the run failed with no fetch; an oversized
needle yields a partial run; and the same workflow works unchanged for a
"different provider" fake (provider neutrality, SC-003).
"""

from __future__ import annotations

import json
import time

from model_eval.config.judge import set_global_judge
from model_eval.datasets.loaders import QAItem
from model_eval.datasets.registry import DatasetNotProvisioned
from model_eval.db.repository import Repository
from model_eval.eval.axis.needle import Tokenizer
from model_eval.eval.llm_suite.handler import make_llm_combined_handler
from model_eval.eval.llm_suite.toolcalling.bfcl_loader import BfclTask
from model_eval.eval.runner import RunWorker
from model_eval.providers.base import ChatMessage, ChatProvider

WORD_TK = Tokenizer(
    count=lambda s: len(s.split()),
    encode=lambda s: s.split(),
    decode=lambda toks: " ".join(toks),
)


def _tool(name: str) -> dict:
    return {"type": "function", "function": {"name": name, "parameters": {}}}


class FakeProvider(ChatProvider):
    name = "fake-candidate"
    endpoint_url = "http://model-host.internal:8000/v1"

    def complete(self, messages, **kwargs):  # noqa: ANN001
        return "The answer is Paris."

    def complete_with_tools(self, messages, tools, **kwargs):  # noqa: ANN001
        # Always emit the ground-truth call so the AST scorer passes.
        return [{"name": "get_weather", "arguments": json.dumps({"city": "Paris"})}]


class OtherProviderFake(FakeProvider):
    """Stands in for a different backend (e.g. a remote provider) — same interface."""

    name = "fake-remote-candidate"
    endpoint_url = "https://api.example-provider.com/v1"


class FakeScorer:
    def score(self, **kwargs) -> float:  # noqa: ANN003
        return 0.9


GT_TASK = BfclTask(
    id="simple_0",
    question="What's the weather in Paris?",
    tools=[_tool("get_weather")],
    ground_truth=[{"name": "get_weather", "arguments": {"city": ["Paris"]}}],
)
DISTRACTORS = [_tool(f"f{i}") for i in range(60)]


def _inputs(*, provider=None, qa_context="Paris is the capital of France.", judge=True):
    qa = QAItem(id="q1", question="capital of France?", answer="Paris", context=qa_context)
    return {
        "provider": provider or FakeProvider(),
        "scorer": FakeScorer(),
        "qa_item": qa,
        "chatbot_filler": " ".join(["filler"] * 500),
        "rag_corpus": " ".join(["distractor"] * 500),
        "bfcl_task": GT_TASK,
        "distractor_pool": DISTRACTORS,
        "judge_configured": judge,
        "max_context": None,
        "tokenizer": WORD_TK,
    }


def _seed_model(repo: Repository) -> int:
    mid = repo.add_model(
        name="cand", provider="local", model="fake-model",
        endpoint_url="http://model-host.internal:8000/v1",
        capabilities={"chat_suite": True, "extraction": False},
    )
    set_global_judge(repo, mid)
    return mid


def _run_and_wait(tmp_db_path, build_inputs, *, timeout=8.0) -> str:
    with Repository(tmp_db_path) as repo:
        mid = _seed_model(repo)
        run_id = repo.create_run(
            model_config_id=mid, suite_type="llm-combined", config_snapshot={}
        )
    worker = RunWorker(
        str(tmp_db_path),
        {"llm-combined": make_llm_combined_handler(build_inputs=build_inputs)},
        poll_interval=0.05,
    )
    worker.start()
    deadline = time.time() + timeout
    status = "queued"
    while time.time() < deadline:
        with Repository(tmp_db_path) as repo:
            status = repo.get_run(run_id)["status"]
        if status in ("completed", "partial", "failed", "interrupted"):
            break
        time.sleep(0.05)
    worker.stop(timeout=2)
    return run_id, status


def test_full_suite_completes_with_15plus_results(tmp_db_path) -> None:
    run_id, status = _run_and_wait(tmp_db_path, lambda repo, run: _inputs())
    assert status == "completed"
    with Repository(tmp_db_path) as repo:
        results = repo.list_axis_results(run_id)
        scored = [r for r in results if r["status"] == "scored"]
        tool_rows = [r for r in results if r["sub_evaluation"] == "tool-calling"]
    assert len(scored) >= 15
    # Tool-calling rows used the BFCL native AST metric and passed.
    assert tool_rows and all(r["metric_name"] == "bfcl_ast" for r in tool_rows)
    assert all(r["passed"] == 1 for r in tool_rows)


def test_dataset_failfast_marks_failed(tmp_db_path) -> None:
    def build(repo, run):
        raise DatasetNotProvisioned("dataset not provisioned locally: bfcl_ast")

    run_id, status = _run_and_wait(tmp_db_path, build)
    assert status == "failed"
    with Repository(tmp_db_path) as repo:
        assert repo.list_axis_results(run_id) == []
        assert "not provisioned" in repo.get_run(run_id)["failure_reason"]


def test_oversized_needle_yields_partial(tmp_db_path) -> None:
    huge = " ".join(["w"] * 60000)  # exceeds every context size in word tokens
    run_id, status = _run_and_wait(
        tmp_db_path, lambda repo, run: _inputs(qa_context=huge)
    )
    assert status == "partial"
    with Repository(tmp_db_path) as repo:
        results = repo.list_axis_results(run_id)
    ctx = [r for r in results if r["axis_kind"] == "context-window"]
    tools = [r for r in results if r["axis_kind"] == "tool-count"]
    assert ctx and all(r["status"] == "skipped" for r in ctx)   # all context points skipped
    assert tools and all(r["status"] == "scored" for r in tools)  # tool points still scored


def test_same_workflow_across_providers(tmp_db_path) -> None:
    # Swap the candidate provider (simulating a different backend/host) — the
    # orchestrator/handler/scoring code path is unchanged (FR-002a, SC-003).
    run_id, status = _run_and_wait(
        tmp_db_path, lambda repo, run: _inputs(provider=OtherProviderFake())
    )
    assert status == "completed"
    with Repository(tmp_db_path) as repo:
        results = repo.list_axis_results(run_id)
    assert len([r for r in results if r["status"] == "scored"]) >= 15
