"""Integration test for the onboarding flow (T026, amended T066, US1).

Exercises onboard_model end-to-end against a real repository: persistence and
listing for local/azure_openai/remote-provider configs, rejection cases
(malformed + duplicate name) with nothing persisted, and credential masking
(FR-005/006/007a/009).
"""

from __future__ import annotations

import pytest

from model_eval.config.onboarding import OnboardingError, onboard_model
from model_eval.config.secret import SecretRef
from model_eval.db.repository import Repository


@pytest.fixture
def repo(tmp_db_path) -> Repository:
    r = Repository(tmp_db_path)
    yield r
    r.close()


LOCAL = {
    "name": "local-1",
    "provider": "local",
    "model": "llama3:70b",
    "endpoint_url": "http://localhost:8000/v1",
    "api_key": "sk-localsecret9999",
    "capabilities": {"chat_suite": True, "extraction": False},
}
AZURE = {
    "name": "azure-1",
    "provider": "azure_openai",
    "model": "gpt-4o",
    "endpoint_url": "https://r.openai.azure.com",
    "api_key": "azkeysecret8888",
    "azure_deployment": "gpt4o",
    "azure_api_version": "2024-06-01",
    "capabilities": {"chat_suite": True, "extraction": True},
}
REMOTE = {
    "name": "remote-1",
    "provider": "anthropic",
    "model": "claude-opus-4-8",
    "api_key": "sk-ant-remotesecret7777",
    "capabilities": {"chat_suite": True, "extraction": False},
}


def test_onboard_local_azure_and_remote_then_listed(repo: Repository) -> None:
    r1 = onboard_model(repo, LOCAL)
    r2 = onboard_model(repo, AZURE)
    r3 = onboard_model(repo, REMOTE)
    assert r1.provider == "local" and r2.provider == "azure_openai" and r3.provider == "anthropic"
    names = {m["name"] for m in repo.list_models()}
    assert names == {"local-1", "azure-1", "remote-1"}


def test_malformed_rejected_nothing_persisted(repo: Repository) -> None:
    bad = {"name": "x", "provider": "local", "capabilities": {"chat_suite": True}}  # no model
    with pytest.raises(OnboardingError, match="model"):
        onboard_model(repo, bad)
    assert repo.list_models() == []


def test_azure_missing_field_rejected(repo: Repository) -> None:
    bad = dict(AZURE)
    del bad["azure_deployment"]
    with pytest.raises(OnboardingError, match="azure_deployment"):
        onboard_model(repo, bad)
    assert repo.list_models() == []


def test_duplicate_name_rejected(repo: Repository) -> None:
    onboard_model(repo, LOCAL)
    with pytest.raises(OnboardingError, match="already exists"):
        onboard_model(repo, dict(LOCAL))
    assert len(repo.list_models()) == 1


def test_api_key_never_plaintext_in_listing(repo: Repository) -> None:
    onboard_model(repo, LOCAL)
    row = repo.list_models()[0]
    # The stored value exists, but the UI/exports must wrap it in SecretRef.
    masked = SecretRef(row["api_key"]).masked()
    assert "localsecret" not in masked
    assert masked.endswith("9999")


def test_remote_provider_needs_no_endpoint(repo: Repository) -> None:
    result = onboard_model(repo, REMOTE)
    row = repo.get_model(result.model_id)
    assert row["endpoint_url"] is None
