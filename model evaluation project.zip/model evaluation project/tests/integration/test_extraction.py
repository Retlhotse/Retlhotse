"""Integration test for text-extraction (T047, US3).

Verifies the standalone extraction run scores documents and persists results
without touching the LLM suite, and that a non-capable model is prevented
(FR-050/054, SC-005/008).
"""

from __future__ import annotations

import time

import pytest

from model_eval.db.repository import Repository
from model_eval.eval.extraction.runner import (
    ExtractionCapabilityError,
    assert_extraction_capable,
    make_extraction_handler,
)
from model_eval.eval.extraction.scorer import DocumentGroundTruth
from model_eval.eval.runner import RunWorker
from model_eval.providers.base import ChatProvider

DOCS = [
    DocumentGroundTruth(
        document_id="doc-1", text="# Title\nHello", reading_order=["# Title", "Hello"],
        tables_html=[], formulas_latex=[],
    ),
    DocumentGroundTruth(
        document_id="doc-2", text="Plain text", reading_order=["Plain text"],
        tables_html=[], formulas_latex=[],
    ),
]


class DocProvider(ChatProvider):
    name = "doc-model"
    endpoint_url = "http://doc-host.internal:8000/v1"

    def complete(self, messages, **kwargs):  # noqa: ANN001
        return ""

    def complete_with_tools(self, messages, tools, **kwargs):  # noqa: ANN001
        return []


def _build_inputs(repo, run) -> dict:
    prov = DocProvider()

    def extract_fn(p, gt: DocumentGroundTruth) -> dict:
        # Perfect extraction: echo the ground-truth text back.
        return {"markdown": gt.text}

    return {
        "provider": prov,
        "documents": DOCS,
        "extract_fn": extract_fn,
    }


def _seed(repo: Repository, *, extraction: bool) -> int:
    return repo.add_model(
        name="docmodel", provider="local", model="doc-model",
        endpoint_url="http://doc-host.internal:8000/v1",
        capabilities={"chat_suite": False, "extraction": extraction},
    )


def test_extraction_run_scores_documents(tmp_db_path) -> None:
    with Repository(tmp_db_path) as repo:
        mid = _seed(repo, extraction=True)
        run_id = repo.create_run(
            model_config_id=mid, suite_type="text-extraction", config_snapshot={}
        )
    worker = RunWorker(
        str(tmp_db_path),
        {"text-extraction": make_extraction_handler(build_inputs=_build_inputs)},
        poll_interval=0.05,
    )
    worker.start()
    deadline = time.time() + 6
    status = "queued"
    while time.time() < deadline:
        with Repository(tmp_db_path) as repo:
            status = repo.get_run(run_id)["status"]
        if status in ("completed", "partial", "failed"):
            break
        time.sleep(0.05)
    worker.stop(timeout=2)

    assert status == "completed"
    with Repository(tmp_db_path) as repo:
        results = repo.list_extraction_results(run_id)
        # No LLM-suite (axis) results were produced.
        assert repo.list_axis_results(run_id) == []
    assert {r["document_id"] for r in results} == {"doc-1", "doc-2"}
    assert all(r["overall"] == pytest.approx(1.0) for r in results)  # perfect extraction


def test_non_capable_model_prevented() -> None:
    with pytest.raises(ExtractionCapabilityError):
        assert_extraction_capable({"chat_suite": True, "extraction": False})
    # capable model passes
    assert_extraction_capable({"extraction": True})
