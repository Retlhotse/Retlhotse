"""Contract test for the model-config onboarding schema (T023, amended T066).

Validates the contract in contracts/model-config.schema.json as implemented by
config/schema.py: valid local + azure_openai + remote-provider configs, missing
required fields, azure missing deployment, capability requirement, and unknown
provider rejection (FR-005/006/008).
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from pydantic import ValidationError

from model_eval.config.schema import parse_model_config

CONTRACTS = Path(__file__).resolve().parents[2] / "specs" / "001-model-evaluation-platform" / "contracts"


def test_local_example_is_valid() -> None:
    data = json.loads((CONTRACTS / "model-config.local.example.json").read_text())
    cfg = parse_model_config(data)
    assert cfg.provider == "local"
    assert cfg.capabilities.chat_suite is True


def test_azure_example_is_valid() -> None:
    data = json.loads((CONTRACTS / "model-config.azure.example.json").read_text())
    cfg = parse_model_config(data)
    assert cfg.provider == "azure_openai"
    assert cfg.azure_deployment and cfg.azure_api_version


def test_remote_example_is_valid() -> None:
    data = json.loads((CONTRACTS / "model-config.remote.example.json").read_text())
    cfg = parse_model_config(data)
    assert cfg.provider == "anthropic"
    assert cfg.endpoint_url is None  # no local endpoint needed for a hosted provider


def test_missing_model_rejected() -> None:
    with pytest.raises(ValidationError) as ei:
        parse_model_config(
            {"name": "x", "provider": "openai", "capabilities": {"chat_suite": True}}
        )
    assert "model" in str(ei.value)


def test_azure_missing_deployment_rejected() -> None:
    with pytest.raises(ValidationError) as ei:
        parse_model_config(
            {
                "name": "a",
                "provider": "azure_openai",
                "model": "gpt-4o",
                "endpoint_url": "https://r.openai.azure.com",
                "azure_api_version": "2024-06-01",
                "capabilities": {"chat_suite": True},
            }
        )
    assert "azure_deployment" in str(ei.value)


def test_capability_required() -> None:
    with pytest.raises(ValidationError):
        parse_model_config(
            {
                "name": "n",
                "provider": "local",
                "model": "llama3",
                "endpoint_url": "http://h/v1",
                "capabilities": {"chat_suite": False, "extraction": False},
            }
        )


def test_unknown_provider_rejected() -> None:
    with pytest.raises(ValidationError):
        parse_model_config(
            {
                "name": "n",
                "provider": "bogus_provider",
                "model": "x",
                "capabilities": {"chat_suite": True},
            }
        )


def test_extra_fields_forbidden() -> None:
    with pytest.raises(ValidationError):
        parse_model_config(
            {
                "name": "n",
                "provider": "local",
                "model": "llama3",
                "endpoint_url": "http://h/v1",
                "capabilities": {"chat_suite": True},
                "rogue_field": "x",
            }
        )
