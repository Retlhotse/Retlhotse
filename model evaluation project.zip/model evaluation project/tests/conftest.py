"""Shared pytest fixtures.

Phase 1 scaffolding: provides a throwaway on-disk SQLite database so that
persistence and integration tests (added in later phases) get an isolated,
WAL-mode store without touching the real application database.
"""

from __future__ import annotations

import sqlite3
from collections.abc import Iterator
from pathlib import Path

import pytest


@pytest.fixture
def tmp_db_path(tmp_path: Path) -> Path:
    """Return a path to an isolated SQLite file inside the test's tmp dir."""
    return tmp_path / "model_eval_test.sqlite3"


@pytest.fixture
def sqlite_conn(tmp_db_path: Path) -> Iterator[sqlite3.Connection]:
    """Yield a WAL-mode SQLite connection to an isolated test database.

    Mirrors the connection settings the repository layer will use (WAL +
    busy_timeout + foreign keys) so tests exercise the same pragmas.
    """
    conn = sqlite3.connect(tmp_db_path)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()
