"""Unit tests for tool-count distractor sampling (T031, FR-025)."""

from __future__ import annotations

import pytest

from model_eval.eval.axis.tool_count import (
    InsufficientDistractors,
    build_tool_set,
    tool_name,
)


def _tool(name: str) -> dict:
    return {"type": "function", "function": {"name": name, "parameters": {}}}


GT = _tool("get_weather")
POOL = [_tool(f"f{i}") for i in range(60)] + [_tool("get_weather")]  # incl. a dup of GT


@pytest.mark.parametrize("n", [5, 10, 20, 30, 50])
def test_exact_count(n: int) -> None:
    ts = build_tool_set(ground_truth_tool=GT, distractor_pool=POOL, n=n)
    assert ts.count == n
    assert len(ts.tools) == n


def test_ground_truth_present_and_excluded_from_distractors() -> None:
    ts = build_tool_set(ground_truth_tool=GT, distractor_pool=POOL, n=10)
    names = [tool_name(t) for t in ts.tools]
    assert "get_weather" in names
    assert names.count("get_weather") == 1  # GT not duplicated by a distractor


def test_dedup_by_name() -> None:
    pool = [_tool("dup"), _tool("dup"), _tool("other")]
    ts = build_tool_set(ground_truth_tool=GT, distractor_pool=pool, n=3)
    names = sorted(tool_name(t) for t in ts.tools)
    assert names == ["dup", "get_weather", "other"]


def test_insufficient_distractors_raises() -> None:
    pool = [_tool("a"), _tool("b")]
    with pytest.raises(InsufficientDistractors):
        build_tool_set(ground_truth_tool=GT, distractor_pool=pool, n=10)


def test_seed_is_reproducible() -> None:
    a = build_tool_set(ground_truth_tool=GT, distractor_pool=POOL, n=20, seed=7)
    b = build_tool_set(ground_truth_tool=GT, distractor_pool=POOL, n=20, seed=7)
    assert [tool_name(t) for t in a.tools] == [tool_name(t) for t in b.tools]
