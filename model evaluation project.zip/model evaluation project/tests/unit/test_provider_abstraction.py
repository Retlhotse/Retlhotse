"""MANDATORY provider-abstraction test (T059, Constitution Principle I/VII).

Proves the platform's evaluation engine talks only to the ``ChatProvider``
interface, never a concrete SDK — a fake provider (no network, no LangChain
dependency needed) can stand in for any real backend. If this test fails, a
caller has coupled itself to a specific provider implementation, breaking
"adding a provider is config-only" (FR-002a).
"""

from __future__ import annotations

from model_eval.providers.base import ChatMessage, ChatProvider
from model_eval.providers.deepeval_model import make_local_judge


class FakeProvider(ChatProvider):
    name = "fake-model"
    endpoint_url = ""

    def __init__(self) -> None:
        self.calls: list[list[ChatMessage]] = []

    def complete(self, messages, **kwargs):  # noqa: ANN001
        self.calls.append(messages)
        return "fake response"

    def complete_with_tools(self, messages, tools, **kwargs):  # noqa: ANN001
        self.calls.append(messages)
        return [{"name": tools[0]["function"]["name"], "arguments": {}}]


def test_fake_provider_satisfies_chat_provider_interface() -> None:
    provider = FakeProvider()
    assert isinstance(provider, ChatProvider)
    out = provider.complete([ChatMessage(role="user", content="hi")])
    assert out == "fake response"
    assert len(provider.calls) == 1


def test_fake_provider_drives_tool_calls_no_network() -> None:
    provider = FakeProvider()
    tools = [{"type": "function", "function": {"name": "get_weather", "parameters": {}}}]
    calls = provider.complete_with_tools([ChatMessage(role="user", content="weather?")], tools)
    assert calls == [{"name": "get_weather", "arguments": {}}]


def test_fake_provider_usable_as_deepeval_judge_no_network() -> None:
    # The same interface backs the judge — no provider-specific branching anywhere.
    judge = make_local_judge(FakeProvider())
    assert judge.generate("anything") == "fake response"
    assert "fake-model" in judge.get_model_name()


def test_engine_never_imports_a_concrete_provider_sdk() -> None:
    # The orchestrator/handler/scoring modules must depend only on ChatProvider,
    # never on langchain/openai types directly — a swap-in fake must work.
    import inspect

    from model_eval.eval.llm_suite import chatbot, rag
    from model_eval.eval.llm_suite.toolcalling import scorer as tool_scorer

    for module in (chatbot, rag, tool_scorer):
        src = inspect.getsource(module)
        assert "langchain" not in src.lower()
        assert "import openai" not in src.lower()
