"""Cross-cutting secret-masking audit (T053, FR-009, Constitution Principle VI).

The API key must never leak through any implicit stringification path used by
the UI, logs, or exports. The raw value is reachable only via reveal().
"""

from __future__ import annotations

import json

import pytest

from model_eval.config.secret import SecretRef

SECRET = "sk-supersecretvalue-1234"


@pytest.fixture
def ref() -> SecretRef:
    return SecretRef(SECRET)


def test_str_repr_format_all_masked(ref: SecretRef) -> None:
    assert SECRET not in str(ref)
    assert SECRET not in repr(ref)
    assert SECRET not in f"{ref}"
    assert SECRET not in "{}".format(ref)  # noqa: UP032
    assert SECRET not in f"{ref!r}"
    assert str(ref).endswith("1234")  # only last 4 visible


def test_reveal_is_the_only_way_out(ref: SecretRef) -> None:
    assert ref.reveal() == SECRET


def test_not_leaked_via_pickle() -> None:
    import pickle

    restored = pickle.loads(pickle.dumps(SecretRef(SECRET)))
    assert SECRET not in restored.reveal()  # pickling yields a masked, non-recoverable ref


def test_json_dump_of_container_does_not_leak(ref: SecretRef) -> None:
    # A dict that accidentally includes the masked form must not contain the secret.
    payload = {"api_key": ref.masked(), "name": "m1"}
    assert SECRET not in json.dumps(payload)


def test_empty_secret_masked() -> None:
    assert SecretRef("").masked() == "(none)"
    assert SecretRef(None).is_set is False
