"""Regression test for the local -> LangChain provider mapping.

``provider="local"`` is this platform's onboarding label for "any
OpenAI-compatible endpoint" (vLLM, LM Studio, Ollama's OpenAI shim, ...). It is
NOT a real LangChain provider key — passing it straight through to
``init_chat_model(model_provider=...)`` fails at construction time with
"No module named 'langchain_local'" (or similar), which is exactly the bug a
real onboarding run hit. This test constructs a real client (no mocking) and
asserts it routed through LangChain's "openai" integration with the local
base_url, so this regression can't silently return.
"""

from __future__ import annotations

from model_eval.providers.langchain_provider import LangChainProvider


def test_local_provider_routes_through_openai_integration() -> None:
    provider = LangChainProvider(
        name="my-local-model",
        provider="local",
        model="llama3:70b",
        endpoint_url="http://localhost:8000/v1",
    )
    # Must be a real langchain_openai client, not an attempt to import a
    # nonexistent "langchain_local" integration.
    from langchain_openai.chat_models.base import ChatOpenAI

    assert isinstance(provider._model, ChatOpenAI)
    assert provider._model.openai_api_base == "http://localhost:8000/v1"
    assert provider._model.model_name == "llama3:70b"


def test_local_provider_gets_placeholder_key_when_none_supplied() -> None:
    provider = LangChainProvider(
        name="m", provider="local", model="llama3", endpoint_url="http://localhost:8000/v1"
    )
    # The client library requires a non-empty key string even for servers with
    # no auth; must not be left unset (which would fall back to env/None).
    key = provider._model.openai_api_key
    revealed = key.get_secret_value() if hasattr(key, "get_secret_value") else key
    assert revealed == "not-needed"


def test_azure_openai_provider_constructs_azure_client() -> None:
    from langchain_openai.chat_models.azure import AzureChatOpenAI

    provider = LangChainProvider(
        name="m",
        provider="azure_openai",
        model="gpt-4o",
        endpoint_url="https://resource.openai.azure.com",
        api_key="sk-azure-test",
        azure_deployment="my-deployment",
        azure_api_version="2024-06-01",
    )
    assert isinstance(provider._model, AzureChatOpenAI)
