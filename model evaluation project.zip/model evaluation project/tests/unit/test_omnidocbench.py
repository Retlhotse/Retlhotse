"""Unit tests for the OmniDocBench extraction adapter (T044, FR-053, Principle V/VII)."""

from __future__ import annotations

import pytest

from model_eval.eval.extraction import omnidocbench as odb
from model_eval.eval.extraction.omnidocbench import LatexmlUnavailable
from model_eval.eval.extraction.scorer import DocumentGroundTruth, score_document


def test_normalized_edit_distance_bounds() -> None:
    assert odb.normalized_edit_distance("abc", "abc") == 0.0
    assert odb.normalized_edit_distance("", "") == 0.0
    assert odb.normalized_edit_distance("abc", "abd") == pytest.approx(1 / 3)


def test_teds_identical_and_different() -> None:
    t1 = "<table><tr><td>a</td><td>b</td></tr></table>"
    t2 = "<table><tr><td>a</td><td>b</td></tr></table>"
    t3 = "<table><tr><td>x</td></tr></table>"
    assert odb.teds(t1, t2) == pytest.approx(1.0)
    assert odb.teds(t1, t3) < 1.0


def test_perfect_text_document_scores_high() -> None:
    gt = DocumentGroundTruth(
        document_id="d1",
        text="# Title\nHello world",
        reading_order=["# Title", "Hello world"],
        tables_html=[],
        formulas_latex=[],
    )
    score = score_document(predicted_markdown="# Title\nHello world", ground_truth=gt)
    assert score.text_edit_distance == 0.0
    assert score.reading_order_edit_distance == 0.0
    assert score.overall == pytest.approx(1.0)


def test_empty_output_scored_not_crashed() -> None:
    gt = DocumentGroundTruth(
        document_id="d2", text="some text", reading_order=["some text"],
        tables_html=[], formulas_latex=[],
    )
    score = score_document(predicted_markdown="", ground_truth=gt)
    assert score.text_edit_distance == 1.0  # fully wrong, but no crash
    assert 0.0 <= score.overall <= 1.0


def test_latexml_missing_fails_loud(monkeypatch) -> None:
    monkeypatch.setattr(odb.metrics, "latexml_available", lambda: False)
    gt = DocumentGroundTruth(
        document_id="d3", text="t", reading_order=["t"], tables_html=[],
        formulas_latex=[r"\frac{a}{b}"],
    )
    with pytest.raises(LatexmlUnavailable):
        score_document(predicted_markdown="t", ground_truth=gt)


def test_table_document_uses_teds(monkeypatch) -> None:
    gt = DocumentGroundTruth(
        document_id="d4", text="t", reading_order=["t"],
        tables_html=["<table><tr><td>a</td></tr></table>"], formulas_latex=[],
    )
    score = score_document(
        predicted_markdown="t",
        ground_truth=gt,
        predicted_tables_html=["<table><tr><td>a</td></tr></table>"],
    )
    assert score.table_teds == pytest.approx(1.0)
