"""Unit tests for the SQLite repository (T007).

Covers persistence, the EvaluationRun state machine, the partial-vs-completed
rule (Constitution Principle V), unique model names (FR-007a), and stale-run
reaping (interrupted detection).
"""

from __future__ import annotations

import pytest

from model_eval.db.repository import InvalidStateTransition, Repository


@pytest.fixture
def repo(tmp_db_path) -> Repository:
    r = Repository(tmp_db_path)
    yield r
    r.close()


def _add_model(repo: Repository, name: str = "m1") -> int:
    return repo.add_model(
        name=name,
        provider="local",
        model="fake-model",
        endpoint_url="http://localhost:8000/v1",
        capabilities={"chat_suite": True, "extraction": False},
    )


def test_add_and_get_model(repo: Repository) -> None:
    mid = _add_model(repo)
    row = repo.get_model(mid)
    assert row["name"] == "m1"
    assert row["provider"] == "local"
    assert [m["id"] for m in repo.list_models()] == [mid]


def test_unique_model_name_rejected(repo: Repository) -> None:
    _add_model(repo, "dup")
    with pytest.raises(ValueError, match="already exists"):
        _add_model(repo, "dup")
    # Rejection persists nothing extra (FR-007a / FR-005).
    assert len(repo.list_models()) == 1


def test_judge_set_and_clear(repo: Repository) -> None:
    assert repo.get_judge_model_id() is None
    mid = _add_model(repo)
    repo.set_judge(mid)
    assert repo.get_judge_model_id() == mid
    repo.set_judge(None)
    assert repo.get_judge_model_id() is None


def test_run_lifecycle_completed(repo: Repository) -> None:
    mid = _add_model(repo)
    run_id = repo.create_run(
        model_config_id=mid, suite_type="llm-combined", config_snapshot={"axis": []}
    )
    assert repo.get_run(run_id)["status"] == "queued"
    repo.transition_run(run_id, "running")
    repo.add_axis_result(
        run_id=run_id,
        sub_evaluation="chatbot",
        axis_kind="context-window",
        axis_value=5000,
        metric_name="faithfulness",
        status="scored",
        score=0.8,
        threshold=0.5,
        passed=True,
    )
    assert repo.finalize_run(run_id) == "completed"
    assert repo.get_run(run_id)["ended_at"] is not None


def test_partial_when_some_skipped(repo: Repository) -> None:
    mid = _add_model(repo)
    run_id = repo.create_run(
        model_config_id=mid, suite_type="llm-combined", config_snapshot={}
    )
    repo.transition_run(run_id, "running")
    repo.add_axis_result(
        run_id=run_id, sub_evaluation="chatbot", axis_kind="context-window",
        axis_value=5000, metric_name="faithfulness", status="scored", score=0.7,
    )
    repo.add_axis_result(
        run_id=run_id, sub_evaluation="chatbot", axis_kind="context-window",
        axis_value=50000, metric_name="faithfulness", status="skipped",
        reason="exceeds model max context",
    )
    # >=1 scored + a skip => partial, never completed (Principle V).
    assert repo.finalize_run(run_id) == "partial"


def test_failed_when_no_scored_points(repo: Repository) -> None:
    mid = _add_model(repo)
    run_id = repo.create_run(
        model_config_id=mid, suite_type="llm-combined", config_snapshot={}
    )
    repo.transition_run(run_id, "running")
    repo.add_axis_result(
        run_id=run_id, sub_evaluation="rag", axis_kind="context-window",
        axis_value=5000, metric_name="faithfulness", status="failed",
        reason="judge unreachable",
    )
    assert repo.finalize_run(run_id) == "failed"


def test_illegal_transition_rejected(repo: Repository) -> None:
    mid = _add_model(repo)
    run_id = repo.create_run(
        model_config_id=mid, suite_type="text-extraction", config_snapshot={}
    )
    # queued -> completed is not allowed.
    with pytest.raises(InvalidStateTransition):
        repo.transition_run(run_id, "completed")


def test_reap_stale_running_marks_interrupted(repo: Repository) -> None:
    mid = _add_model(repo)
    run_id = repo.create_run(
        model_config_id=mid, suite_type="llm-combined", config_snapshot={}
    )
    repo.transition_run(run_id, "running")
    assert repo.reap_stale_running() == 1
    row = repo.get_run(run_id)
    assert row["status"] == "interrupted"
    assert "restarted" in row["failure_reason"]


def test_progress_and_extraction_results(repo: Repository) -> None:
    mid = repo.add_model(
        name="docmodel", provider="azure_openai", model="gpt-4o",
        endpoint_url="https://r.openai.azure.com",
        capabilities={"chat_suite": False, "extraction": True},
        azure_deployment="dep", azure_api_version="2024-06-01",
    )
    run_id = repo.create_run(
        model_config_id=mid, suite_type="text-extraction", config_snapshot={}
    )
    repo.transition_run(run_id, "running")
    repo.update_progress(run_id, {"done": 1, "total": 2})
    repo.add_extraction_result(
        run_id=run_id, document_id="doc-1", status="scored",
        text_edit_distance=0.1, table_teds=0.9, overall=0.85,
    )
    assert repo.finalize_run(run_id) == "completed"
    results = repo.list_extraction_results(run_id)
    assert len(results) == 1 and results[0]["document_id"] == "doc-1"
