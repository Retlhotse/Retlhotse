"""Unit tests for the BFCL AST scorer + AST-only loader (T034, FR-026a/b)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from model_eval.eval.llm_suite.toolcalling.ast_scorer import match_call, score
from model_eval.eval.llm_suite.toolcalling.bfcl_loader import (
    ForbiddenCategory,
    assert_ast_category,
    load_ast_tasks,
)


# --------------------------------------------------------------- AST scoring
def test_exact_match_correct() -> None:
    expected = {"name": "get_weather", "arguments": {"city": ["Paris"]}}
    actual = {"name": "get_weather", "arguments": '{"city": "Paris"}'}
    assert match_call(expected, actual) is True


def test_wrong_argument_value_incorrect() -> None:
    expected = {"name": "get_weather", "arguments": {"city": ["Paris"]}}
    actual = {"name": "get_weather", "arguments": {"city": "London"}}
    assert match_call(expected, actual) is False


def test_wrong_function_name_incorrect() -> None:
    expected = {"name": "get_weather", "arguments": {"city": ["Paris"]}}
    actual = {"name": "get_time", "arguments": {"city": "Paris"}}
    assert match_call(expected, actual) is False


def test_multiple_accepted_values() -> None:
    expected = {"name": "f", "arguments": {"unit": ["celsius", "c"]}}
    assert match_call(expected, {"name": "f", "arguments": {"unit": "c"}}) is True


def test_optional_param_may_be_omitted() -> None:
    expected = {"name": "f", "arguments": {"q": ["x"], "opt": ["", "y"]}}
    assert match_call(expected, {"name": "f", "arguments": {"q": "x"}}) is True


def test_parallel_calls_order_independent() -> None:
    expected = [
        {"name": "a", "arguments": {"x": [1]}},
        {"name": "b", "arguments": {"y": [2]}},
    ]
    actual = [
        {"name": "b", "arguments": {"y": 2}},
        {"name": "a", "arguments": {"x": 1}},
    ]
    assert score(expected, actual).correct is True


def test_call_count_mismatch_incorrect() -> None:
    expected = [{"name": "a", "arguments": {}}]
    actual = [{"name": "a", "arguments": {}}, {"name": "a", "arguments": {}}]
    assert score(expected, actual).correct is False


# --------------------------------------------------------------- AST-only loader
def test_executable_category_rejected() -> None:
    with pytest.raises(ForbiddenCategory):
        assert_ast_category("exec_simple")


def test_multiturn_category_rejected() -> None:
    with pytest.raises(ForbiddenCategory):
        assert_ast_category("multi_turn_base")


def test_unknown_category_rejected() -> None:
    with pytest.raises(ForbiddenCategory):
        assert_ast_category("irrelevance")


def test_load_ast_tasks(tmp_path: Path) -> None:
    rec = {
        "id": "simple_0",
        "question": "weather in Paris?",
        "function": [{"type": "function", "function": {"name": "get_weather", "parameters": {}}}],
        "ground_truth": [{"name": "get_weather", "arguments": {"city": ["Paris"]}}],
    }
    p = tmp_path / "bfcl_ast.jsonl"
    p.write_text(json.dumps(rec) + "\n", encoding="utf-8")
    tasks = load_ast_tasks(p, "simple")
    assert len(tasks) == 1
    assert tasks[0].ground_truth_tool()["function"]["name"] == "get_weather"


def test_dotted_function_name_sanitized_for_provider_compatibility(tmp_path: Path) -> None:
    # Real BFCL data (e.g. simple_python) uses dotted names like "math.factorial",
    # which Anthropic's tool-name pattern (^[a-zA-Z0-9_-]{1,128}$) rejects. Loading
    # must sanitize both the tool schema and the ground truth consistently.
    from model_eval.eval.llm_suite.toolcalling.ast_scorer import score

    rec = {
        "id": "simple_python_1",
        "question": "factorial of 5",
        "function": [
            {"type": "function", "function": {"name": "math.factorial", "parameters": {}}}
        ],
        "ground_truth": [{"name": "math.factorial", "arguments": {"number": [5]}}],
    }
    p = tmp_path / "bfcl_ast.jsonl"
    p.write_text(json.dumps(rec) + "\n", encoding="utf-8")
    task = load_ast_tasks(p, "simple")[0]

    sanitized_name = task.tools[0]["function"]["name"]
    assert "." not in sanitized_name
    assert sanitized_name == "math_factorial"
    # ground_truth_tool() still resolves post-sanitization (both sides renamed).
    assert task.ground_truth_tool()["function"]["name"] == sanitized_name
    assert task.ground_truth[0]["name"] == sanitized_name

    # A model that echoes the sanitized name back still scores correctly.
    actual_call = [{"name": sanitized_name, "arguments": {"number": 5}}]
    assert score(task.ground_truth, actual_call).correct is True
