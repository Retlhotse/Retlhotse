"""Unit tests for needle-in-haystack synthesis (T029, FR-023, Principle VII).

Uses a trivial whitespace tokenizer (injected) so the test does not depend on
the tiktoken cache / network.
"""

from __future__ import annotations

import pytest

from model_eval.eval.axis.needle import (
    NeedleTooLarge,
    SynthesizedContext,
    Tokenizer,
    synthesize_context,
)

# A deterministic word tokenizer: 1 token == 1 whitespace-delimited word.
WORD_TK = Tokenizer(
    count=lambda s: len(s.split()),
    encode=lambda s: s.split(),
    decode=lambda toks: " ".join(toks),
)

NEEDLE = "the secret code is platypus"  # 5 words
FILLER = " ".join(["filler"] * 200)


def test_total_size_hits_target_and_contains_needle() -> None:
    ctx = synthesize_context(
        needle=NEEDLE, filler=FILLER, target_tokens=50, tokenizer=WORD_TK
    )
    assert isinstance(ctx, SynthesizedContext)
    assert ctx.total_tokens == 50  # exact for the word tokenizer
    assert ctx.needle_tokens == 5
    assert "secret code is platypus" in ctx.text


def test_position_ratio_controls_depth() -> None:
    start = synthesize_context(
        needle=NEEDLE, filler=FILLER, target_tokens=50, position_ratio=0.0,
        tokenizer=WORD_TK,
    )
    end = synthesize_context(
        needle=NEEDLE, filler=FILLER, target_tokens=50, position_ratio=1.0,
        tokenizer=WORD_TK,
    )
    assert start.text.startswith("the secret code")          # needle at front
    assert end.text.rstrip().endswith("platypus")            # needle at back


def test_oversized_needle_skipped() -> None:
    big_needle = " ".join(["word"] * 100)
    with pytest.raises(NeedleTooLarge):
        synthesize_context(
            needle=big_needle, filler=FILLER, target_tokens=50, tokenizer=WORD_TK
        )


def test_needle_never_truncated_even_at_exact_fit() -> None:
    needle = " ".join(["w"] * 50)  # exactly the budget
    ctx = synthesize_context(
        needle=needle, filler=FILLER, target_tokens=50, tokenizer=WORD_TK
    )
    assert ctx.needle_tokens == 50
    assert ctx.text == needle  # no filler room, needle intact
