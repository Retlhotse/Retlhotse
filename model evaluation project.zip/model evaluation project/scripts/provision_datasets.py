#!/usr/bin/env python3
"""One-time dataset provisioning (Constitution Principle II).

Downloads real benchmark data, converts it to the shapes this platform's
loaders expect (datasets/loaders.py, eval/llm_suite/toolcalling/bfcl_loader.py),
writes it under ./data/, and registers each file in the SQLite dataset
registry. This script is the *only* place the platform touches the network for
data — it never runs during an evaluation (FR-013): the run-time loaders only
ever read the local files this script produces.

Sources (verified against the live repos/datasets before writing each converter):
  - BFCL v4 single-turn AST "simple" category (questions + ground truth),
    Apache 2.0: github.com/ShishirPatil/gorilla, berkeley-function-call-leaderboard
  - SQuAD 2.0 dev set, CC BY-SA 4.0: rajpurkar.github.io/SQuAD-explorer
  - OmniDocBench ground-truth annotations (OmniDocBench.json), CC BY 4.0:
    huggingface.co/datasets/opendatalab/OmniDocBench (page images are NOT
    downloaded by this script — see the --omnidoc-limit note below)

Usage:
    python scripts/provision_datasets.py [--db PATH] [--data-dir DIR] [--omnidoc-limit N] [--skip-omnidoc]
"""

from __future__ import annotations

import argparse
import json
import sys
import urllib.request
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))

from model_eval.db.repository import Repository  # noqa: E402

USER_AGENT = "model-eval-provisioning/1.0"

BFCL_QUESTIONS_URL = (
    "https://raw.githubusercontent.com/ShishirPatil/gorilla/main/"
    "berkeley-function-call-leaderboard/bfcl_eval/data/BFCL_v4_simple_python.json"
)
BFCL_ANSWERS_URL = (
    "https://raw.githubusercontent.com/ShishirPatil/gorilla/main/"
    "berkeley-function-call-leaderboard/bfcl_eval/data/possible_answer/"
    "BFCL_v4_simple_python.json"
)
SQUAD_URL = (
    "https://raw.githubusercontent.com/rajpurkar/SQuAD-explorer/master/"
    "dataset/dev-v2.0.json"
)
OMNIDOC_JSON_URL = (
    "https://huggingface.co/datasets/opendatalab/OmniDocBench/resolve/main/OmniDocBench.json"
)

# category_type values (verified against the real OmniDocBench.json) that
# carry running body text used for the "text" + "reading_order" metrics.
_OMNIDOC_TEXT_CATEGORIES = ("title", "text_block")


def _fetch(url: str) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=30) as resp:  # noqa: S310 - fixed https URLs above
        return resp.read()


def _fetch_jsonl(url: str) -> list[dict]:
    """BFCL data files are JSON Lines, despite the .json extension."""
    text = _fetch(url).decode("utf-8")
    return [json.loads(line) for line in text.splitlines() if line.strip()]


# --------------------------------------------------------------------- BFCL AST
def _bfcl_question_text(question_turns: list) -> str:
    # Single-turn AST records are [[{"role": "user", "content": "..."}]] —
    # one turn, list of messages. Join all message contents in that turn.
    if not question_turns:
        return ""
    turn = question_turns[0]
    return "\n".join(m.get("content", "") for m in turn)


def _bfcl_function_to_openai_tool(fn: dict) -> dict:
    params = fn.get("parameters", {})
    return {
        "type": "function",
        "function": {
            "name": fn["name"],
            "description": fn.get("description", ""),
            "parameters": {
                "type": "object",
                "properties": params.get("properties", {}),
                "required": params.get("required", []),
            },
        },
    }


def _bfcl_ground_truth(gt_list: list[dict]) -> list[dict]:
    # Native shape: [{"fn_name": {"param": [accepted, ...]}}, ...] (one entry
    # per expected call — >1 for parallel categories, 1 for simple).
    calls = []
    for entry in gt_list:
        for fn_name, args in entry.items():
            calls.append({"name": fn_name, "arguments": args})
    return calls


def provision_bfcl_ast(data_dir: Path) -> Path:
    print(f"Downloading BFCL v4 simple_python questions from {BFCL_QUESTIONS_URL}")
    questions = _fetch_jsonl(BFCL_QUESTIONS_URL)
    print(f"Downloading BFCL v4 simple_python ground truth from {BFCL_ANSWERS_URL}")
    answers = _fetch_jsonl(BFCL_ANSWERS_URL)
    answers_by_id = {rec["id"]: rec["ground_truth"] for rec in answers}

    out_path = data_dir / "bfcl_ast.jsonl"
    written = 0
    with out_path.open("w", encoding="utf-8") as fh:
        for q in questions:
            gt = answers_by_id.get(q["id"])
            if gt is None:
                continue  # no matching ground truth — skip rather than guess
            record = {
                "id": q["id"],
                "question": _bfcl_question_text(q.get("question", [])),
                "function": [_bfcl_function_to_openai_tool(fn) for fn in q.get("function", [])],
                "ground_truth": _bfcl_ground_truth(gt),
            }
            fh.write(json.dumps(record) + "\n")
            written += 1
    print(f"  -> wrote {written} BFCL AST tasks to {out_path}")
    return out_path


# --------------------------------------------------------------------- SQuAD
def _iter_squad_qas(squad: dict):
    for article in squad["data"]:
        for para in article["paragraphs"]:
            context = para["context"]
            for qa in para["qas"]:
                if qa.get("is_impossible"):
                    continue
                answers = qa.get("answers") or []
                if not answers:
                    continue
                yield qa["id"], qa["question"], answers[0]["text"], context


def provision_chatbot_qa_base(data_dir: Path, squad: dict, *, limit: int = 200) -> Path:
    out_path = data_dir / "chatbot_qa_base.jsonl"
    written = 0
    with out_path.open("w", encoding="utf-8") as fh:
        for qid, question, answer, context in _iter_squad_qas(squad):
            fh.write(
                json.dumps({"id": qid, "question": question, "answer": answer, "context": context})
                + "\n"
            )
            written += 1
            if written >= limit:
                break
    print(f"  -> wrote {written} QA items (SQuAD) to {out_path}")
    return out_path


def provision_filler_and_rag_corpus(
    data_dir: Path, squad: dict, *, filler_paragraphs: int = 60, rag_paragraphs: int = 60
) -> tuple[Path, Path]:
    contexts: list[str] = []
    seen = set()
    for article in squad["data"]:
        for para in article["paragraphs"]:
            ctx = para["context"]
            if ctx not in seen:
                seen.add(ctx)
                contexts.append(ctx)

    filler_slice = contexts[:filler_paragraphs]
    rag_slice = contexts[filler_paragraphs : filler_paragraphs + rag_paragraphs]

    filler_path = data_dir / "filler_corpus.txt"
    filler_path.write_text("\n\n".join(filler_slice), encoding="utf-8")
    print(f"  -> wrote {len(filler_slice)} filler paragraphs to {filler_path}")

    rag_path = data_dir / "rag_corpus.txt"
    rag_path.write_text("\n\n".join(rag_slice), encoding="utf-8")
    print(f"  -> wrote {len(rag_slice)} RAG distractor paragraphs to {rag_path}")

    return filler_path, rag_path


# --------------------------------------------------------------- OmniDocBench
def _omnidoc_page_to_record(page: dict) -> dict:
    # Real annotation shape (verified against OmniDocBench.json): each page has
    # `layout_dets` (a flat list of blocks with category_type/order/ignore plus
    # a text|latex|html payload depending on category) and `page_info`
    # (image_path uniquely identifies the page).
    blocks = [d for d in page["layout_dets"] if not d.get("ignore")]
    # A handful of real records have order=None; sort those last, deterministically.
    blocks.sort(key=lambda d: (d.get("order") is None, d.get("order") or 0))

    text_blocks = [d for d in blocks if d["category_type"] in _OMNIDOC_TEXT_CATEGORIES]
    reading_order = [d.get("text", "") for d in text_blocks]
    text = "\n".join(reading_order)

    tables = [d["html"] for d in blocks if d["category_type"] == "table" and d.get("html")]
    formulas = [
        d["latex"] for d in blocks if d["category_type"] == "equation_isolated" and d.get("latex")
    ]

    image_path = page["page_info"].get("image_path", f"page_{page['page_info'].get('page_no')}")
    doc_id = Path(image_path).stem or image_path

    return {
        "id": doc_id,
        "text": text,
        "reading_order": reading_order,
        "tables": tables,
        "formulas": formulas,
    }


def provision_omnidocbench(data_dir: Path, *, limit: int) -> Path:
    print(f"Downloading OmniDocBench ground truth from {OMNIDOC_JSON_URL}")
    print("  (this is a ~40MB annotation file; page images are NOT downloaded)")
    pages = json.loads(_fetch(OMNIDOC_JSON_URL))
    if limit:
        pages = pages[:limit]

    out_path = data_dir / "omnidocbench.jsonl"
    written = 0
    with out_path.open("w", encoding="utf-8") as fh:
        for page in pages:
            fh.write(json.dumps(_omnidoc_page_to_record(page)) + "\n")
            written += 1
    print(f"  -> wrote {written} OmniDocBench pages (of 1651 total) to {out_path}")
    return out_path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", default="model_eval.sqlite3", help="SQLite DB path")
    parser.add_argument("--data-dir", default="data", help="Local directory to write datasets into")
    parser.add_argument(
        "--omnidoc-limit",
        type=int,
        default=50,
        help="Number of OmniDocBench pages to provision (0 = all 1651; default 50)",
    )
    parser.add_argument(
        "--skip-omnidoc",
        action="store_true",
        help="Skip OmniDocBench entirely (only needed for text-extraction runs)",
    )
    args = parser.parse_args()

    data_dir = (REPO_ROOT / args.data_dir).resolve()
    data_dir.mkdir(parents=True, exist_ok=True)

    print(f"Downloading SQuAD 2.0 dev set from {SQUAD_URL}")
    squad = json.loads(_fetch(SQUAD_URL))

    bfcl_path = provision_bfcl_ast(data_dir)
    qa_path = provision_chatbot_qa_base(data_dir, squad)
    filler_path, rag_path = provision_filler_and_rag_corpus(data_dir, squad)
    omnidoc_path = None if args.skip_omnidoc else provision_omnidocbench(data_dir, limit=args.omnidoc_limit)

    db_path = (REPO_ROOT / args.db) if not Path(args.db).is_absolute() else Path(args.db)
    with Repository(db_path) as repo:
        repo.upsert_dataset(name="chatbot_qa_base", suite="chatbot", local_path=str(qa_path), version="squad-dev-v2.0")
        repo.upsert_dataset(name="filler_corpus", suite="chatbot", local_path=str(filler_path), version="squad-dev-v2.0")
        repo.upsert_dataset(name="rag_corpus", suite="rag", local_path=str(rag_path), version="squad-dev-v2.0")
        repo.upsert_dataset(name="bfcl_ast", suite="tool-calling", local_path=str(bfcl_path), version="bfcl-v4-simple-python")
        if omnidoc_path is not None:
            repo.upsert_dataset(
                name="omnidocbench", suite="extraction", local_path=str(omnidoc_path),
                version=f"omnidocbench-{args.omnidoc_limit or 1651}-pages",
            )

    n = 5 if omnidoc_path is not None else 4
    print(f"\nRegistered {n} datasets in {db_path}.")
    if omnidoc_path is None:
        print("Skipped 'omnidocbench' (--skip-omnidoc). Re-run without that flag to add it.")
    else:
        print(
            "Note: OmniDocBench page IMAGES were not downloaded (only the ground-truth"
        )
        print(
            "annotations) — the extraction runner's current model prompt does not yet"
        )
        print(
            "attach page images to the request, so this is sufficient for scoring "
            "mechanics"
        )
        print("but not yet a faithful image-grounded extraction test.")


if __name__ == "__main__":
    main()
