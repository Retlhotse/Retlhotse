# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this repository is

A **provider-neutral enterprise model-evaluation platform**: a Streamlit app that onboards LLMs from **any** provider (OpenAI, Anthropic, Azure OpenAI, Google, Ollama, or any OpenAI-compatible endpoint — local or remote) via JSON config, connected through **LangChain** as a universal provider layer, and runs two evaluation jobs against locally-provisioned data — a combined **LLM suite** (chatbot + RAG + tool-calling via deepeval, swept across context-window and tool-count axes) and standalone **text-extraction** (OmniDocBench). Results persist to SQLite and are browsable.

The repo is **also** a GitHub Spec Kit (Spec-Driven Development) project: the app was built through the SDD workflow, and the spec/plan/tasks that define it live under [specs/001-model-evaluation-platform/](specs/001-model-evaluation-platform/). Application code is in `src/model_eval/`.

**The constitution was amended to v2.0.0 (2026-07-01)**: the original design was air-gapped with a local-only judge; that was relaxed at the owner's direction so the platform can test models hosted anywhere through one universal connectivity layer. [tasks.md](specs/001-model-evaluation-platform/tasks.md) Phase 8 ("LangChain Migration") tracks migrating the implementation off the old `openai`-SDK + egress-guard design — check its checkboxes for current status before assuming `airgap/` or `local_openai.py`/`azure_openai.py` still exist.

## Commands

This is a Python 3.11+ project (developed/tested on 3.13). It is **not a git repo**.

```bash
# Install
pip install -e ".[dev]"

# Tests (pytest config in pyproject.toml; pythonpath=src so no install needed to run)
python -m pytest                              # full suite
python -m pytest -m "not integration"         # fast unit/contract subset
python -m pytest tests/unit/test_repository.py::test_partial_when_some_skipped  # one test

# Lint / format
ruff check src tests
black src tests

# Run the app (creates the SQLite DB + schema on first launch; set provider API keys first)
streamlit run src/model_eval/app/main.py
```

## Architecture (`src/model_eval/`)

A thin Streamlit UI over a **pure-Python library**, deliberately layered so the constitution's critical paths are unit-testable without Streamlit or a live model.

- **`app/`** — Streamlit entry (`main.py`) + 3 auto-discovered pages (`pages/1_Onboarding.py`, `2_Evaluation.py`, `3_Results.py`). Pages are thin: they call services and the repository.
- **`db/`** — `schema.sql` (6 entities), `repository.py` (the only writer; WAL SQLite, CRUD, and the **EvaluationRun state machine** `queued→running→{completed,partial,failed,interrupted}`), `results.py` (read-only result views for the Results page).
- **`config/`** — `schema.py` (pydantic model-config validation: `provider`+`model` required; `azure_openai` additionally requires deployment/api_version), `onboarding.py` (validate-then-persist service), `judge.py` (single global judge, any provider), `secret.py` (`SecretRef` mask-on-read), `templates.py`.
- **`providers/`** — `base.ChatProvider` interface; a **LangChain-backed** adapter (`init_chat_model(model, model_provider=...)`) covers every provider from one implementation; `deepeval_model.py` wraps a provider as a deepeval judge; `__init__.build_provider()` factory from a stored config row.
- **`datasets/`** — `registry.py` (resolves dataset names to local paths, verifies presence live, raises `DatasetNotProvisioned` — never fetches) and `loaders.py`.
- **`eval/`** — the engine:
  - `runner.py` — single background `RunWorker` thread: claims the next `queued` run, dispatches to a per-`suite_type` handler, derives completed/partial/failed via `repository.finalize_run`, reaps stale `running` runs as `interrupted` on startup.
  - `axis/` — `tokenizer.py` (single reference tokenizer, tiktoken `cl100k_base`), `needle.py` (needle-in-haystack context synthesis; oversized needle → `NeedleTooLarge` → skip), `tool_count.py` (distractor sampling to N tools).
  - `llm_suite/` — `orchestrator.run_llm_combined` runs chatbot+rag+tool-calling as **one indivisible job**; `chatbot.py`/`rag.py` sub-evals; `toolcalling/` (AST-only `bfcl_loader.py` + vendored `ast_scorer/`); `scoring.py` (deepeval metrics bound to the configured judge); `handler.py` bridges runner↔orchestrator.
  - `extraction/` — `scorer.py` + vendored `omnidocbench/` metrics (stdlib TEDS, latexml-gated formulas); `runner.py` handler with capability gating.

### Two patterns to know before editing the engine

1. **Run handlers take an injectable `build_inputs(repo, run) -> dict`.** Production gathers real providers/judge/datasets; tests inject fakes (fake `ChatProvider`, fake `QualityScorer`, in-memory docs) to drive the full `worker → handler → orchestrator` path with no network. See `eval/llm_suite/handler.py` + `tests/integration/test_llm_suite.py`. Mirror this when adding a suite type.
2. **The reference tokenizer and quality scorer are injectable too.** `needle.synthesize_context(tokenizer=...)` and the `QualityScorer` Protocol let unit tests avoid the tiktoken cache and deepeval entirely. Default = the real implementations.

## Constraints that override convention

- **The constitution ([.specify/memory/constitution.md](.specify/memory/constitution.md), v2.0.0) is binding.** 7 principles. **I (Provider Neutrality)**: all model access — candidate and judge — goes through one universal layer (LangChain); adding a provider MUST be config-only, never a code change to the engine/scoring/persistence. **III (Single Configurable Judge)**: exactly one judge is active at a time, explicitly configured (any provider); if unset, judge-dependent metrics don't run. Datasets are read-only local with fail-fast on absence (Principle II — reproducibility, not air-gap); **BFCL AST categories only** (Executable/multi-turn are out of scope for deterministic scoring, not an air-gap concern); runs **fail loud** — a degraded run is `partial`/`failed`, never silently `completed`; API keys never rendered (`SecretRef`). New code must keep these testable (Principle VII) — the mandatory test is that a fake provider can drive a full run with zero network access, not an egress guard.
- **No egress restriction.** Outbound connections to configured model/judge endpoints anywhere are expected and normal. Don't reintroduce offline-mode env vars or a socket-level guard unless a future amendment asks for an optional restricted deployment mode.
- **Traceability (Principle IV).** Every run persists a `config_snapshot` (provider, model, endpoint, datasets+versions, judge, axis points, thresholds, `scoring_method`, reference tokenizer, needle construction). Don't recompute provenance for display; record what the code actually did. Vendored scorers (BFCL AST, OmniDocBench) are independent reimplementations of the published methodology — see each `NOTICE.md` and [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

## SDD workflow (how features are added)

Features flow through user-invocable `/speckit-*` skills, in order: `constitution → specify → clarify → plan → tasks → analyze → implement`. Artifacts land in `specs/<NNN-short-name>/`; the active feature is tracked in `.specify/feature.json` (read by the PowerShell helper scripts in `.specify/scripts/powershell/`, not git branches). When a `SKILL.md` says to run an extension hook / `EXECUTE_COMMAND:`, actually invoke it and wait. The seed templates live in `.specify/templates/`; helper scripts are PowerShell and write project files UTF-8 **without BOM** by design.
