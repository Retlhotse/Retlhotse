# Enterprise Model Evaluation Platform

Streamlit application that onboards models from **any provider** — local or
remote — via JSON config, connected through **LangChain** as a universal
connectivity layer, and runs two evaluation jobs against **locally-provisioned**
data:

- **LLM suite** (one indivisible job): chatbot + RAG swept across context-window
  sizes (5k/10k/20k/30k/50k tokens, needle-in-haystack) and tool-calling swept
  across tool counts (5/10/20/30/50), via deepeval, with a single global judge
  (any provider) and the **BFCL native AST scorer**.
- **Text-extraction** (standalone): document-to-Markdown accuracy via OmniDocBench.

Specification, plan, and tasks live under
[`specs/001-model-evaluation-platform/`](specs/001-model-evaluation-platform/).
The project is governed by [`.specify/memory/constitution.md`](.specify/memory/constitution.md)
(v2.0.0) — **provider neutrality** (any model, reached through one universal
layer) and **a single explicitly-configured judge** are the binding principles.

> Status: all four user stories implemented (Onboarding, combined LLM suite,
> text-extraction, Results), migrated to LangChain per constitution v2.0.0. See
> [`specs/001-model-evaluation-platform/tasks.md`](specs/001-model-evaluation-platform/tasks.md)
> for the task breakdown and [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md)
> for vendored evaluation methodology (BFCL AST, OmniDocBench).

## Requirements

- Python 3.11+
- `latexml` binary on PATH, only if evaluated documents contain formulas
  (OmniDocBench formula scoring)
- Benchmark datasets provisioned to local storage (the platform consumes them;
  it never fetches them at run time)
- `tiktoken` `cl100k_base` encoding available locally
- API keys / credentials for whichever providers you plan to onboard

## Install

```bash
pip install -e ".[dev]"
```

Add the `langchain-<provider>` integration package for every backend you plan
to onboard (e.g. `langchain-openai`, `langchain-anthropic`, `langchain-google-genai`,
`langchain-ollama`) — these are declared as project dependencies; see `pyproject.toml`.

## Setup & run

```bash
# Set provider credentials for whichever providers you'll onboard, e.g.:
export OPENAI_API_KEY=...
export ANTHROPIC_API_KEY=...

# Provision benchmark datasets (one-time; downloads real BFCL v4 AST data,
# SQuAD, and OmniDocBench ground truth, converts, and registers all 5 — see
# scripts/provision_datasets.py).
python scripts/provision_datasets.py

# Launch the app (creates the SQLite file + schema on first run)
streamlit run src/model_eval/app/main.py
```

`scripts/provision_datasets.py` is the **only** place the platform touches the
network for data (Constitution Principle II) — it runs once, ahead of time; the
evaluation loaders only ever read the local files it produces. By default it
provisions 50 OmniDocBench pages (of the full 1,651); pass `--omnidoc-limit 0`
for the full set, or `--skip-omnidoc` to skip it entirely (only needed for
text-extraction runs). It downloads OmniDocBench's ground-truth annotations
only — not the ~1,651 page images, since the current extraction runner's model
prompt doesn't yet attach page images to the request (text/table/reading-order
scoring works against the ground truth regardless; formula scoring additionally
requires the `latexml` binary on PATH).

## Tests

```bash
pytest                  # all
pytest -m "not integration"   # fast unit/contract subset
```

The provider-abstraction test (`tests/unit/test_provider_abstraction.py`) and
the dataset fail-fast / fail-loud integration checks are mandatory (Constitution
Principle VII). See
[`specs/001-model-evaluation-platform/quickstart.md`](specs/001-model-evaluation-platform/quickstart.md)
for end-to-end validation scenarios (V1–V6).
