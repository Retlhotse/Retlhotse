# Phase 0 Research: Enterprise Model Evaluation Platform

**Feature**: `001-model-evaluation-platform` | **Date**: 2026-07-01

This document resolves the open technical decisions left to planning by the spec (the spec deferred "the specific deepeval base QA set" and "which concrete reference tokenizer" to the plan), plus the integration-pattern unknowns implied by the mandated stack. Every decision is constrained by the constitution — air-gap and local-judge are non-negotiable.

---

## R1. Reference tokenizer for the context-window axis (FR-021, FR-023)

- **Decision**: Use `tiktoken` with the `cl100k_base` encoding as the single reference tokenizer for counting "N tokens" across all models.
- **Rationale**: `tiktoken` ships its encodings as local files (vendorable into the offline cache via `TIKTOKEN_CACHE_DIR`), is deterministic, fast, and widely understood. `cl100k_base` is a reasonable common denominator for modern chat models. Using one fixed tokenizer is exactly what Q3 resolved (cross-model comparability over per-model accuracy).
- **Air-gap note**: `tiktoken` normally fetches the encoding `.tiktoken` file on first use. The encoding file MUST be pre-provisioned to `TIKTOKEN_CACHE_DIR` so no download occurs at run time; absence is treated as a missing dataset (Principle II).
- **Alternatives considered**: HuggingFace `transformers` tokenizer (heavier, pulls Hub by default — more air-gap surface); each model's own tokenizer (rejected by Q3 — not cross-model comparable); a naive whitespace/char heuristic (not representative of token budgets).

## R2. Base dataset for needle-in-haystack (FR-023)

- **Decision**: Use a locally-provisioned short-answer QA set as the needle source — a SQuAD-style `(context, question, short_answer)` collection — registered in the dataset registry as `chatbot_qa_base`. The "needle" is the answer-bearing sentence; filler is drawn from unrelated documents in the same local corpus.
- **Rationale**: Needle-in-haystack requires an item with a *verifiable* short answer that can be relocated to a known depth; QA pairs provide that cleanly. Conversational/G-Eval metrics then score whether the model recovered the needle at each context size.
- **Air-gap note**: The base QA set and the filler corpus are provisioned out-of-band; the registry verifies both before a run.
- **Alternatives considered**: deepeval's built-in benchmark datasets (most don't expose a relocatable short-answer needle and some trigger Hub access); synthetic generated needles (adds an LLM-generation dependency and weakens reproducibility).

## R3. Non-blocking long-running execution in Streamlit (FR-072)

- **Decision**: Run evaluations on a **single background worker thread** owned by the process, decoupled from Streamlit's script-rerun model. The worker pulls the next `queued` run, drives it, and writes state + progress to SQLite. The UI never calls the evaluation code directly; it submits a run (insert `queued` row) and **polls** run state from SQLite on each rerun (lightweight auto-refresh).
- **Rationale**: Streamlit reruns the script top-to-bottom on every interaction, so any in-band long job would block or be killed. Persisting state to SQLite (single source of truth) lets the user navigate away and return with accurate status (FR-072, SC-007), and makes "interrupted" detectable after a process restart (a `running` row with no live worker → `interrupted`).
- **Concurrency**: One worker = runs serialized (one `running` at a time; rest `queued`). Matches the single-node/single-user v1 assumption and avoids contention on the candidate/judge endpoints.
- **Alternatives considered**: `st.spawn`/`ScriptRunContext` hacks (fragile); a separate process/queue (Celery/RQ) — overkill and adds a broker dependency that complicates air-gap; `asyncio` in-app (still bound to the rerun lifecycle).

## R4. Universal model connectivity via LangChain (FR-002/002a; Principle I) — *amended v2.0.0*

- **Decision**: Connect to every model — candidate and judge — through **LangChain's `init_chat_model(model, model_provider=..., **kwargs)`**, wrapped behind one `ChatProvider` interface (`complete`, `complete_with_tools`). `build_provider(config)` maps a stored config (`provider`, `model`, optional `endpoint_url`/`api_key`, Azure fields) to the right LangChain chat model. A local OpenAI-compatible server is just `provider="openai"` (or `"ollama"`) with a `base_url`.
- **Rationale**: This is the universality the owner asked for — onboarding a new backend (OpenAI, Anthropic, Azure, Google, Ollama, local) becomes configuration, not code (Principle I, FR-002a). The engine/scoring/persistence never import a provider SDK.
- **No egress guard** (amended): the former air-gap socket guard and offline-env enforcement are removed. Outbound connections to configured endpoints are expected and allowed.
- **Alternatives considered**: keeping per-provider `openai`-SDK adapters (more code per provider, not universal); raw `httpx` (reinvents the wheel); the old socket egress guard (no longer a requirement).

## R5. deepeval judge backed by a LangChain model (FR-040, CON-004) — *amended v2.0.0*

- **Decision**: Implement a `DeepEvalLangChainModel(DeepEvalBaseLLM)` whose `generate()` calls a LangChain chat model's `.invoke()`. The single global judge is one such instance (any provider) passed explicitly as `model=` to every LLM-as-judge metric (Faithfulness, AnswerRelevancy, contextual precision/recall, conversational + G-Eval).
- **Rationale**: deepeval defaults its judge to OpenAI; passing an explicit instance removes the implicit default and lets the judge be any provider (relaxed Principle III). One shared instance encodes "single global judge" and is captured in the run snapshot (FR-042).
- **Alternatives considered**: deepeval's built-in LangChain integration / `set_local_model` CLI config (global mutable state, harder to snapshot per run).

## R6. Tool-calling: BFCL AST-only loading + native AST scorer (FR-026, FR-026a, FR-026b, Q2)

- **Decision**: **Vendor** the BFCL AST checker (`ast_checker` and its language/type-matching helpers) from the Gorilla repo (Apache 2.0) into `eval/llm_suite/toolcalling/ast_scorer/`, retaining the license. The loader reads only the single-turn AST category files (`simple`, `multiple`, `parallel`, `parallel_multiple`) from local storage and hard-rejects Executable/multi-turn categories. Scoring calls the vendored native AST checker, which validates the function name and argument values per BFCL's methodology.
- **Rationale**: Q2 chose leaderboard-faithful native AST scoring; vendoring keeps it air-gapped and version-pinned (no `pip install bfcl` pulling live-execution/runtime-API deps). Restricting at the loader makes the AST-only constraint structural, not advisory.
- **Tool-count axis (FR-025)**: For a fixed AST task, hold the query + ground-truth tool fixed and sample distractor tool **schemas** from other BFCL entries to reach exactly N total tools (5/10/20/30/50), de-duplicating by function name and excluding the ground-truth function from the distractor pool.
- **Alternatives considered**: deepeval `ToolCorrectnessMetric` (Q2 rejected — not leaderboard-comparable); `pip install` the full BFCL harness (drags in executable-category and live-API dependencies that fight the air-gap).

## R7. OmniDocBench text-extraction integration (FR-050–FR-053, CON-005, Q-extraction)

- **Decision**: **Vendor** OmniDocBench's end-to-end evaluation code into `eval/extraction/omnidocbench/` (license retained). Pipeline: render/serve local benchmark document images → candidate (document-capable) model emits Markdown → score Markdown vs local ground truth with OmniDocBench's end2end metrics: normalized edit distance (text + reading order), TEDS (tables, via `apted`), formula metric (via `latexml`), and the combined overall score.
- **Rationale**: CON-005 mandates OmniDocBench; its end2end module is the faithful scorer. Vendoring keeps it offline and pinned.
- **Dependencies / risk**: `latexml` is an external binary (not pip) required for formula/table rendering — flagged in the spec's Assumptions as locally available; the extraction runner MUST detect its absence and fail loud (Principle V) rather than silently zero-scoring formulas.
- **Alternatives considered**: re-implementing edit-distance/TEDS ourselves (diverges from the benchmark, violates Principle IV faithfulness); skipping formula scoring if `latexml` is missing (silent degradation — forbidden).

## R8. Config → provider mapping (FR-002, FR-006) — *amended v2.0.0*

- **Decision**: A single `ChatProvider` (LangChain-backed, R4); `build_provider(config)` calls `init_chat_model(model=cfg.model, model_provider=cfg.provider, api_key=…, base_url=…)`, with Azure mapped to `model_provider="azure_openai"` + `azure_deployment`/`api_version`/`azure_endpoint`. A pydantic schema validates `provider`+`model` (required) and the Azure-specific fields when `provider="azure_openai"`, giving precise per-field errors (FR-005/FR-006).
- **Rationale**: One mapping covers every backend; there is no per-provider adapter code to maintain (Principle I).
- **Alternatives considered**: discriminated union per provider (unnecessary once LangChain normalizes the client); separate SDK clients (the thing we're removing).

## R9. Credential storage & masking (FR-009, Principle VI)

- **Decision**: Store API keys in SQLite in a dedicated column accessed only through a `SecretRef` wrapper whose `__repr__`/`__str__`/serialization return a mask (`••••last4`). UI widgets render masked; result exports and logs receive only `SecretRef`. Keys are used solely to construct provider clients, never placed in displayed URLs.
- **Rationale**: Single-node air-gapped host makes the DB itself the trust boundary; the realistic leak vectors are UI/logs/exports, which the `SecretRef` closes structurally and testably.
- **Alternatives considered**: OS keyring (not portable across the air-gapped targets; adds a dependency); encryption-at-rest (defensible later, but key-management overhead with low marginal benefit on a single-node air-gapped box — deferred, not blocking).

## R10. SQLite concurrency between UI thread and worker (FR-064, FR-072)

- **Decision**: Single SQLite file in **WAL** mode, short-lived connections per operation, `busy_timeout` set. Writes flow only from the worker (run/result rows) and from onboarding (model rows); the UI thread reads. Run progress is a small, frequently-updated column on the run row.
- **Rationale**: WAL permits concurrent readers with a writer, which fits one-writer-worker + UI-reader cleanly without an external datastore (CON-003/FR-064).
- **Alternatives considered**: external DB (violates CON-003); in-memory state (lost on restart, breaks "interrupted" detection and SC-007).

---

## Resolved unknowns summary

| Unknown (from spec/plan) | Resolution |
|--------------------------|------------|
| Reference tokenizer | `tiktoken` `cl100k_base`, pre-cached locally (R1) |
| Needle base dataset | local SQuAD-style QA set `chatbot_qa_base` + filler corpus (R2) |
| Non-blocking execution | single background worker + SQLite-polled state (R3) |
| Model connectivity | LangChain `init_chat_model` behind one `ChatProvider`; no egress guard (R4) |
| Judge wiring | `DeepEvalLangChainModel` (any provider) passed as `model=` to every judge metric (R5) |
| Tool scoring | vendored BFCL native AST checker, AST-only loader (R6) |
| Extraction scoring | vendored OmniDocBench end2end metrics; `latexml` only for formulas (R7) |
| Config → provider | `build_provider` maps `provider`+`model`(+endpoint/key) via LangChain (R8) |
| Credential masking | `SecretRef` mask-on-read (R9) |
| UI/worker DB concurrency | SQLite WAL, one writer (R10) |

No `NEEDS CLARIFICATION` remain. Proceed to Phase 1.
