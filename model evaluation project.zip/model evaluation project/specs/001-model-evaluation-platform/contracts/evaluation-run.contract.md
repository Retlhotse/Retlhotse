# Internal Contract: Evaluation Run Submission & Lifecycle

**Feature**: `001-model-evaluation-platform` | **Date**: 2026-07-01

This app exposes no external HTTP API. The contract that matters is the **internal boundary** between the Streamlit UI (`app/`) and the evaluation engine (`eval/runner.py`) via the SQLite run record. Documenting it pins the shape the UI submits and the states it must render, independent of implementation.

## Submission (UI → engine)

The Evaluation page submits a run by inserting a `queued` EvaluationRun. Two actions, never mixed (FR-020/071):

### A. Combined LLM suite (`suite_type = "llm-combined"`)
```json
{
  "model_config_id": 1,
  "suite_type": "llm-combined",
  "requested_axis": {
    "context_window": [5000, 10000, 20000, 30000, 50000],
    "tool_count": [5, 10, 20, 30, 50]
  }
}
```
- Runs chatbot + RAG + tool-calling together; sub-evaluations are **not** individually selectable (FR-020).
- Preconditions checked before enqueue (else reject, do not enqueue):
  - selected model `capabilities.chat_suite == true`;
  - a global judge is configured (FR-041) — else the LLM-as-judge metrics cannot run;
  - required datasets present: `chatbot_qa_base`, filler corpus, `rag_corpus`, `bfcl_ast`, plus tokenizer cache (FR-073/013).

### B. Text-extraction (`suite_type = "text-extraction"`)
```json
{
  "model_config_id": 2,
  "suite_type": "text-extraction"
}
```
- Precondition: selected model `capabilities.extraction == true`, else prevented with explanation (FR-054/SC-008).
- Precondition: `omnidocbench` dataset present and `latexml` available (FR-052/073).

## Lifecycle (engine, observable via polling)

`queued → running → {completed | partial | failed | interrupted}` (see data-model state machine).

The UI reads `status` + `progress` from the run row on each rerun (FR-072). Contract guarantees:

| Guarantee | Requirement |
|-----------|-------------|
| A `running` run reports `progress.{current_sub, current_axis_point, done, total}` | FR-072 |
| Any skipped/failed axis point with ≥1 retained result ⇒ `partial`, never `completed` | Principle V |
| Missing dataset ⇒ `failed` with `failure_reason`, **no fetch attempted** | FR-013/SC-004 |
| Judge/model unreachable mid-run ⇒ `failed`/`partial`, completed points retained | Edge Cases |
| Context point > model max ⇒ that AxisResult `skipped` w/ reason, run continues | FR-024 |
| Process restart with a stale `running` row ⇒ `interrupted` | Principle V |
| The same submission flow works unchanged regardless of the model's provider (local or remote) | FR-002/002a/SC-003 |

## Results read (engine → UI)

Results page queries (FR-062/063):
- **List**: runs with `model.name`, `suite_type`, `started_at`, `status`.
- **Drill-down (llm-combined)**: AxisResults grouped by `sub_evaluation` then `axis_value` (chatbot/RAG per context window; tool-calling per tool count).
- **Drill-down (text-extraction)**: ExtractionResults per `document_id` with per-element + overall scores.
- **Compare**: two runs of the same `suite_type` aligned on identical `axis_value`s.

## Output invariants (all reads)

- `api_key` is never returned to the UI in plaintext — only a masked `SecretRef` (FR-009).
- `config_snapshot` is read-only provenance; it is never recomputed for display (FR-IV).
