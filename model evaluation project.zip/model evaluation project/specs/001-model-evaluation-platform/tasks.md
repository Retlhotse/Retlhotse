---
description: "Task list for Enterprise Model Evaluation Platform implementation"
---

# Tasks: Enterprise Model Evaluation Platform

**Input**: Design documents from `/specs/001-model-evaluation-platform/`

**Prerequisites**: [plan.md](plan.md) (required), [spec.md](spec.md) (user stories), [research.md](research.md), [data-model.md](data-model.md), [contracts/](contracts/)

**Tests**: Test tasks are INCLUDED and REQUIRED — the project constitution (Principle VII, Verifiability) mandates automated coverage of the egress guard, scoring adapters, axis construction, and persistence. The egress-guard test is non-negotiable.

**Organization**: Tasks are grouped by user story (US1–US4 from spec.md) so each can be implemented and tested independently.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies on incomplete tasks)
- **[Story]**: US1–US4 for user-story tasks; Setup/Foundational/Polish carry no story label
- All paths are repository-relative.

## Path Conventions

Single project: library under `src/model_eval/`, tests under `tests/` (see plan.md → Project Structure).

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Project initialization and offline-first scaffolding.

- [X] T001 Create the project tree per plan.md: `src/model_eval/{app/pages,airgap,config,providers,datasets,eval/axis,eval/llm_suite/toolcalling,eval/extraction,db}` and `tests/{unit,integration,contract}`, each with `__init__.py` where applicable.
- [X] T002 Create `pyproject.toml` (Python 3.11+) declaring deps: streamlit, deepeval, openai, tiktoken, pydantic>=2, apted, lxml, pytest; document the local wheelhouse / offline install in `README` stub.
- [X] T003 [P] Configure tooling in `pyproject.toml`: ruff + black + pytest sections; add `tests/conftest.py` with a temp-SQLite fixture.
- [X] T004 [P] Add `.env.example` and `scripts/offline-env.ps1`/`.sh` exporting `HF_HUB_OFFLINE`, `TRANSFORMERS_OFFLINE`, `HF_DATASETS_OFFLINE`, `DEEPEVAL_TELEMETRY_OPT_OUT=YES`, `ERROR_REPORTING=NO`, `TIKTOKEN_CACHE_DIR` (research.md R4).

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Shared infrastructure that MUST exist before ANY user story. Covers persistence, air-gap, config, providers, datasets, tokenizer, app shell, and the run worker.

**⚠️ CRITICAL**: No user story work begins until this phase is complete.

- [X] T005 Create SQLite DDL in `src/model_eval/db/schema.sql` for ModelConfig, JudgeConfig, Dataset, EvaluationRun, AxisResult, ExtractionResult + indexes (data-model.md).
- [X] T006 Implement `src/model_eval/db/repository.py`: WAL connection (busy_timeout), schema bootstrap, CRUD for all entities, and the EvaluationRun state machine (`queued→running→{completed,partial,failed,interrupted}`).
- [X] T007 [P] Unit-test persistence + state machine + `partial` vs `completed` rule in `tests/unit/test_repository.py` (Principle V/VII).
- [X] T008 [P] Implement `SecretRef` mask-on-read wrapper in `src/model_eval/config/secret.py` (FR-009, research.md R9).
- [X] T009 Implement the model-config pydantic schema (discriminated union local|azure, per-field validation, Azure required fields) in `src/model_eval/config/schema.py` matching [contracts/model-config.schema.json](contracts/model-config.schema.json).
- [X] T010 [P] Implement copyable local/azure JSON templates in `src/model_eval/config/templates.py` from the contracts examples (FR-004).
- [X] T011 Implement offline-mode bootstrap (set env, disable deepeval telemetry, point tiktoken cache) in `src/model_eval/airgap/offline.py` (FR-014, R4).
- [X] T012 Implement the socket-level egress guard (allowlist = model + judge hosts; raise `EgressBlocked` otherwise) in `src/model_eval/airgap/egress_guard.py` (FR-015, Principle I).
- [X] T013 [P] **Mandatory** unit test: egress guard blocks a disallowed connection and permits allowlisted hosts, in `tests/unit/test_egress_guard.py` (Principle VII).
- [X] T014 Implement the common `ChatProvider` interface in `src/model_eval/providers/base.py`.
- [X] T015 [P] Implement local OpenAI-compatible provider in `src/model_eval/providers/local_openai.py` (R8).
- [X] T016 [P] Implement Azure provider (endpoint/deployment/api_version) in `src/model_eval/providers/azure_openai.py` (FR-006, R8).
- [X] T017 Implement `DeepEvalLocalModel(DeepEvalBaseLLM)` wrapper over the providers in `src/model_eval/providers/deepeval_model.py` (R5).
- [X] T018 Implement the dataset registry + live presence verification + `DatasetNotProvisioned` in `src/model_eval/datasets/registry.py` (FR-013/073, Principle II).
- [X] T019 [P] Implement dataset loaders (QA base, filler corpus, RAG corpus, BFCL, OmniDocBench) in `src/model_eval/datasets/loaders.py`.
- [X] T020 Implement the single reference tokenizer (tiktoken `cl100k_base`, offline cache, missing-cache → fail loud) in `src/model_eval/eval/axis/tokenizer.py` (FR-021, R1).
- [X] T021 Implement the Streamlit app shell + 3-page navigation in `src/model_eval/app/main.py` (FR-070).
- [X] T022 Implement the background worker skeleton (pull next `queued`, drive run, write progress, detect stale `running`→`interrupted`) in `src/model_eval/eval/runner.py` (FR-072, R3).

**Checkpoint**: Persistence, air-gap, providers, datasets, tokenizer, app shell, and worker exist — user stories can begin.

---

## Phase 3: User Story 1 — Onboard a model via JSON (Priority: P1) 🎯 MVP

**Goal**: Register local/Azure models via validated JSON; persist them uniquely with masked credentials.

**Independent Test**: Submit a valid local and a valid Azure config → both appear selectable; submit a malformed config and a duplicate name → both rejected with specific errors, nothing persisted.

- [X] T023 [US1] Contract test for the model-config schema in `tests/contract/test_model_config_schema.py`: valid local, valid azure, missing `endpoint_url`, azure missing `azure_deployment`, duplicate `name` (FR-005/006/007a).
- [X] T024 [US1] Wire validation + unique-name enforcement (reject + persist-nothing) across `src/model_eval/config/schema.py` and `src/model_eval/db/repository.py` (FR-005/007/007a).
- [X] T025 [US1] Implement the Onboarding page (show local/azure templates, submit, field-level errors, masked key display) in `src/model_eval/app/pages/1_Onboarding.py` (FR-004/008/009).
- [X] T026 [P] [US1] Integration test onboarding flows (persist, list on Evaluation page, rejection cases, key masking) in `tests/integration/test_onboarding.py`.

**Checkpoint**: Models can be onboarded and selected — MVP delivered.

---

## Phase 4: User Story 2 — Run the combined LLM suite (Priority: P1)

**Goal**: One indivisible job runs chatbot + RAG + tool-calling, sweeping context-window (5k–50k) and tool-count (5–50) axes with a global local judge and BFCL native AST scoring; results persisted per axis point.

**Independent Test**: With an onboarded model + configured judge + local datasets, start the suite → one run yields ≥15 AxisResults; no egress beyond model+judge; removing a dataset fails fast; an oversized needle is skipped → run `partial`.

- [X] T027 [US2] Implement global JudgeConfig persistence + selection UI; block LLM-as-judge metrics when unset (FR-040/041/042) in `src/model_eval/db/repository.py` and `src/model_eval/app/pages/1_Onboarding.py`.
- [X] T028 [US2] Implement needle-in-haystack context synthesis + oversized-item skip-with-reason in `src/model_eval/eval/axis/needle.py` (FR-023, R2).
- [X] T029 [P] [US2] Unit-test needle synthesis + skip rule in `tests/unit/test_needle.py` (Principle VII).
- [X] T030 [US2] Implement tool-count distractor sampling to exactly N tools (fixed query/ground-truth) in `src/model_eval/eval/axis/tool_count.py` (FR-025).
- [X] T031 [P] [US2] Unit-test tool-count sampling (counts, dedup, ground-truth excluded from distractors) in `tests/unit/test_tool_count.py`.
- [X] T032 [US2] Vendor the BFCL native AST checker (Apache 2.0, license retained) into `src/model_eval/eval/llm_suite/toolcalling/ast_scorer/`.
- [X] T033 [US2] Implement the BFCL AST-only loader (accept simple/multiple/parallel/parallel_multiple; reject Executable + V3 multi-turn) in `src/model_eval/eval/llm_suite/toolcalling/bfcl_loader.py` (FR-026/026a).
- [X] T034 [P] [US2] Unit-test the AST scorer adapter + AST-only enforcement in `tests/unit/test_ast_scorer.py` (Principle VII).
- [X] T035 [US2] Implement the chatbot sub-eval (deepeval conversational/G-Eval per context size; raw score + threshold default 0.5) in `src/model_eval/eval/llm_suite/chatbot.py` (FR-021/027/028).
- [X] T036 [US2] Implement the RAG sub-eval (faithfulness/contextual precision-recall/answer-relevancy per context size; fixed relevant:distractor ratio) in `src/model_eval/eval/llm_suite/rag.py` (FR-030/031/032).
- [X] T037 [US2] Implement the tool-calling sub-eval (native AST scoring across tool counts) in `src/model_eval/eval/llm_suite/toolcalling/scorer.py` (FR-022/026b).
- [X] T038 [US2] Implement the orchestrator running all three sub-evals as one indivisible job in `src/model_eval/eval/llm_suite/orchestrator.py` (FR-020).
- [X] T039 [US2] Wire `llm-combined` into the runner: progress, AxisResult persistence, threshold/verdict, partial/failed transitions, judge-identity snapshot in `src/model_eval/eval/runner.py` (FR-028/042/060/061/072).
- [X] T040 [US2] Implement the Evaluation page combined-suite action: preconditions (capability, judge, dataset presence), single non-deselectable action, live progress in `src/model_eval/app/pages/2_Evaluation.py` (FR-020/071/073).
- [X] T041 [P] [US2] Integration test in `tests/integration/test_llm_suite.py`: ≥15 AxisResults; egress only to model+judge (SC-003); dataset fail-fast (SC-004); oversized-needle → `partial`; context > model max → skipped point (FR-024).

**Checkpoint**: The core evaluation job runs end-to-end and is air-gap/fail-loud verified.

---

## Phase 5: User Story 3 — Run text-extraction standalone (Priority: P2)

**Goal**: Run OmniDocBench document-to-Markdown scoring on extraction-capable models, independent of the LLM suite.

**Independent Test**: Run extraction on a document-capable model → OmniDocBench per-element + overall scores stored, LLM suite untouched; attempting it on a non-capable model is prevented with an explanation.

- [X] T042 [US3] Vendor OmniDocBench end2end evaluation code (Apache 2.0, license retained) into `src/model_eval/eval/extraction/omnidocbench/`.
- [X] T043 [US3] Implement the OmniDocBench adapter (text/reading-order edit distance, table TEDS via apted, formula via latexml, overall) in `src/model_eval/eval/extraction/scorer.py` (FR-053).
- [X] T044 [P] [US3] Unit-test the extraction adapter + latexml-missing fail-loud + empty-output handled in `tests/unit/test_omnidocbench.py` (Principle V/VII).
- [X] T045 [US3] Implement the extraction runner: capability gating (FR-054), ExtractionResult persistence, `text-extraction` run type in `src/model_eval/eval/extraction/runner.py` (FR-050/052/055/061).
- [X] T046 [US3] Add the Evaluation page extraction action (separate from the suite) + capability-prevention message in `src/model_eval/app/pages/2_Evaluation.py` (FR-071/054, SC-008).
- [X] T047 [P] [US3] Integration test extraction run + capability prevention in `tests/integration/test_extraction.py` (SC-005/008).

**Checkpoint**: Both run types work and persist as distinct types.

---

## Phase 6: User Story 4 — View and compare results (Priority: P2)

**Goal**: Browse historical runs with per-axis and per-document drill-down and same-axis cross-model comparison.

**Independent Test**: After a combined run and an extraction run, the Results page lists both, drills into per-axis-point/per-document scores, and compares two same-suite runs on identical axes.

- [X] T048 [US4] Implement results read queries (list, axis drill-down, document drill-down, same-axis compare) in `src/model_eval/db/repository.py` (FR-062/063).
- [X] T049 [US4] Implement the Results page: run list (model, suite type, timestamp, status) + drill-down views in `src/model_eval/app/pages/3_Results.py` (FR-062).
- [X] T050 [US4] Implement the same-axis comparison view for two runs of a suite type in `src/model_eval/app/pages/3_Results.py` (FR-063, SC-006).
- [X] T051 [P] [US4] Integration test list/drill-down/compare + verify keys masked in all reads in `tests/integration/test_results.py` (FR-009/062/063).

**Checkpoint**: All four user stories independently functional.

---

## Phase 7: Polish & Cross-Cutting Concerns

- [X] T052 [P] Add LICENSE/NOTICE files for vendored BFCL AST checker and OmniDocBench under their directories.
- [X] T053 [P] Cross-cutting secret-masking audit across UI, logs, and exports in `tests/unit/test_secret_masking.py` (FR-009, Principle VI).
- [X] T054 [P] Write `README.md` (offline setup, dataset provisioning, running the app) referencing [quickstart.md](quickstart.md).
- [X] T055 Execute quickstart.md scenarios V1–V6 end-to-end and record outcomes (Definition of Done).

---

## Dependencies & Execution Order

### Phase dependencies
- **Setup (P1)** → no deps.
- **Foundational (P2)** → depends on Setup; **blocks all user stories**.
- **US1 (P3)** → after Foundational. No dependency on other stories (MVP).
- **US2 (P4)** → after Foundational; uses onboarded models + judge (judge config task T027 lives here).
- **US3 (P5)** → after Foundational; independent of US2 (different run type).
- **US4 (P6)** → after Foundational; needs runs to exist (US2/US3) to display real data, but the page/queries can be built and unit-exercised independently.
- **Polish (P7)** → after the stories it touches.

### Critical within-story ordering
- US2: T028/T030 (axis) and T032–T034 (scorer) → sub-evals T035–T037 → orchestrator T038 → runner wiring T039 → page T040 → integration T041.
- US3: T042 → T043 → T045 → T046; T044 after T043.
- US4: T048 → T049 → T050 → T051.

## Parallel Opportunities

- **Setup**: T003, T004 in parallel after T001/T002.
- **Foundational**: T007, T008, T010, T013, T015, T016, T019 are `[P]` (distinct files); note T015/T016 depend on T014, T013 on T012, T007 on T006.
- **US1**: T026 `[P]` after T023–T025.
- **US2**: unit tests T029, T031, T034 `[P]`; integration T041 `[P]` last.
- **US3/US4**: T044, T047, T051 `[P]` within their stories.

```text
# Example — Foundational parallel batch (after their direct deps):
T008 SecretRef · T010 templates · T019 loaders · (T013 after T012) · (T015/T016 after T014)
```

## Implementation Strategy

- **MVP = Phase 1 + Phase 2 + Phase 3 (US1)**: a working, air-gap-scaffolded app that onboards models with validation and masked credentials. Stop and validate against US1's independent test.
- **Increment 2 — US2**: the core combined LLM suite (highest value). Validate air-gap + fail-loud via T041.
- **Increment 3 — US3**: standalone text-extraction.
- **Increment 4 — US4**: results browsing/comparison.
- **Polish**: licenses, masking audit, README, full quickstart validation.

## Notes
- Tests are mandated by Constitution Principle VII; the provider-abstraction test (T059) and dataset-fail-fast / oversized-needle checks (T041) are the reliability guarantees made real.
- `[P]` = different files, no incomplete dependency. Tasks editing the same file (e.g., `repository.py`: T006/T024/T027/T048; `2_Evaluation.py`: T040/T046) are sequential.
- Commit after each task or logical group; stop at any checkpoint to validate a story independently.

---

## Phase 8: LangChain Migration (constitution v2.0.0 amendment)

**Purpose**: Relax air-gap/local-judge to provider-neutral connectivity via LangChain, per the amended constitution ([.specify/memory/constitution.md](../../.specify/memory/constitution.md) v2.0.0) and updated [spec.md](spec.md)/[plan.md](plan.md)/[research.md](research.md). Supersedes T011–T013 (offline bootstrap + egress guard, now removed) and T015–T016 (local/Azure `openai`-SDK adapters, replaced).

- [X] T056 Remove `src/model_eval/airgap/` (offline.py, egress_guard.py) and its `__init__.py`; remove `tests/unit/test_egress_guard.py`; drop the `HF_HUB_OFFLINE`/`TRANSFORMERS_OFFLINE`/`HF_DATASETS_OFFLINE`/telemetry-opt-out env wiring from `scripts/offline-env.*` and `.env.example` (FR-011 removed).
- [X] T057 Update `pyproject.toml`: remove the `openai` SDK dependency (unless still needed transitively), add `langchain`, `langchain-openai`, `langchain-anthropic` (+ any other provider integration needed); remove the offline-wheelhouse framing from README install instructions.
- [X] T058 [P] Implement `src/model_eval/providers/langchain_provider.py`: a `ChatProvider` implementation wrapping `langchain.chat_models.init_chat_model(model, model_provider=..., base_url=..., api_key=...)`, mapping `azure_openai` to `azure_deployment`/`azure_api_version`/`azure_endpoint`. Delete `local_openai.py` and `azure_openai.py`.
- [X] T059 [P] **Mandatory** unit test: a fake `ChatProvider` drives `complete()`/`complete_with_tools()` without any network access, proving the provider abstraction is swappable, in `tests/unit/test_provider_abstraction.py` (Principle VII).
- [X] T060 Update `src/model_eval/providers/deepeval_model.py`: rename `DeepEvalLocalModel` → `DeepEvalLangChainModel`; its `generate()` calls the wrapped LangChain model's `.invoke()` (any provider) instead of assuming a local endpoint (FR-040, R5).
- [X] T061 Update `src/model_eval/providers/__init__.py` `build_provider(config)` to construct a `LangChainProvider` from `provider`+`model`(+`endpoint_url`/`api_key`/Azure fields) for every provider key (FR-002).
- [X] T062 Update `src/model_eval/config/schema.py`: replace the `local`/`azure` discriminated union with a single schema requiring `provider`+`model`, with `azure_openai` requiring `azure_deployment`/`azure_api_version`/`endpoint_url`, matching [contracts/model-config.schema.json](contracts/model-config.schema.json).
- [X] T063 [P] Update `src/model_eval/config/templates.py` to match the amended [contracts/model-config.local.example.json](contracts/model-config.local.example.json), [contracts/model-config.azure.example.json](contracts/model-config.azure.example.json), and new [contracts/model-config.remote.example.json](contracts/model-config.remote.example.json); add a third "remote provider" template tab to `1_Onboarding.py`.
- [X] T064 Update `src/model_eval/db/schema.sql` and `repository.py`: rename `model_config.provider` semantics (now a LangChain provider key, not `local`/`azure`), add `model` column, make `azure_openai` the Azure enum value, `endpoint_url` nullable (data-model.md ModelConfig).
- [X] T065 Update `src/model_eval/app/main.py` and both page files to remove the `apply_offline_env()` call and the "Air-gap status" panel; remove any egress-guard usage from `eval/llm_suite/handler.py` and `eval/extraction/runner.py` (both used `EgressGuard()` around the run).
- [X] T066 [P] Update `tests/contract/test_model_config_schema.py`, `tests/integration/test_onboarding.py`, `tests/integration/test_llm_suite.py`, `tests/integration/test_extraction.py`, `tests/integration/test_results.py` to use `provider`+`model` fields and a fake `ChatProvider` (no `EgressGuard`); update `README.md` and `THIRD_PARTY_NOTICES.md` framing (no air-gap claims).
- [X] T067 Run the full test suite; verify zero failures and zero references to `airgap`/`EgressGuard`/`egress` remain in `src/` and `tests/` (`grep -ri egress src tests` empty).

**Checkpoint**: The platform onboards and evaluates models from any LangChain-supported provider through one abstraction, with no egress restriction, and the full worker→handler→orchestrator path is still fully testable with fakes (no live network required).
