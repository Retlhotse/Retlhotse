# Implementation Plan: Enterprise Model Evaluation Platform

**Branch**: `001-model-evaluation-platform` | **Date**: 2026-07-01 | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `/specs/001-model-evaluation-platform/spec.md`

**Note**: This template is filled in by the `/speckit-plan` command. See `.specify/templates/plan-template.md` for the execution workflow.

> **Amended 2026-07-01 (constitution v2.0.0)**: air-gap removed; model connectivity is now via **LangChain** (universal provider layer); candidate and judge models may be hosted anywhere; no egress guard. Datasets remain locally provisioned.

## Summary

A Streamlit application (three pages: Onboarding, Evaluation, Results) that onboards models from **any** provider via JSON config — through **LangChain** as the universal connectivity layer — and runs two evaluation jobs against locally-provisioned data: (1) an indivisible **LLM suite** — chatbot + RAG swept across synthesized context-window sizes (5k/10k/20k/30k/50k tokens via needle-in-haystack) and tool-calling swept across tool counts (5/10/20/30/50), all on deepeval with a single global judge (any provider) for LLM-as-judge metrics and the **BFCL native AST scorer** for tool calls; and (2) a standalone **text-extraction** job on OmniDocBench. Runs execute on a background worker and persist state/progress/results to SQLite at axis-point granularity. The design's job is to keep the constitution's remaining guarantees structural and testable: a uniform provider abstraction (adding a provider is config-only), a dataset presence gate, an explicit single-judge gate, and fail-loud run states.

## Technical Context

**Language/Version**: Python 3.11+

**Primary Dependencies**: Streamlit (UI); **LangChain** (`langchain` + `langchain-openai`, `langchain-anthropic`, plus any provider integration the deployment needs) as the universal model-connectivity layer for candidate models AND the judge, via `init_chat_model(model, model_provider=...)`; deepeval (chatbot/RAG/conversational + G-Eval metrics, with its judge backed by a LangChain chat model); OmniDocBench end2end metrics (vendored, Apache 2.0; stdlib TEDS — no apted/lxml); BFCL AST checker (vendored from Gorilla, Apache 2.0); `tiktoken` (single reference tokenizer for the context-window axis); `pydantic` v2 (config schema + validation); `latexml` (formula rendering, external binary, only when documents contain formulas); `pytest` (tests). Persistence via the stdlib `sqlite3`.

**Storage**: SQLite (single embedded file, single-node). Accessed through a thin repository layer; WAL mode to allow the background worker and the Streamlit UI thread to read/write concurrently.

**Testing**: `pytest`. Mandatory coverage per Constitution Principle VII — provider abstraction (a fake provider drives a full run), scoring adapters (BFCL AST + OmniDocBench), axis construction (needle synthesis + tool-count synthesis), and persistence.

**Target Platform**: Single-node host (Linux or Windows), with network access to whatever model/judge endpoints are configured.

**Project Type**: Single project — a Streamlit application with a supporting library package (`src/model_eval/`).

**Performance Goals**: Not latency-sensitive. Long-running evaluations MUST NOT block the UI (FR-072); progress is observable within ~1–2 s of a UI refresh by reading run state from SQLite. Onboarding round-trip < 2 minutes (SC-001).

**Constraints**: Provider neutrality (FR-002/002a) — adding a backend is config-only, via LangChain; datasets read-only from local storage with fail-fast on absence (FR-013); API keys never rendered in plaintext (FR-009); single reference tokenizer for cross-model comparability (FR-021); BFCL AST categories only (FR-026a).

**Scale/Scope**: Single evaluation host, single concurrent user assumed (v1). Runs are serialized through a single background worker (one active run at a time; others `queued`). 3 UI pages, 2 run types, ~6 persisted entities.

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

Constitution v2.0.0. Evaluated each principle against this design:

| Principle | Gate | Design enforcement | Status |
|-----------|------|--------------------|--------|
| I. Provider Neutrality & Connectivity | All model access via one universal layer; adding a provider is config-only | `providers/` wraps **LangChain** `init_chat_model(model, model_provider=...)` behind a single `ChatProvider` interface; `build_provider(config)` constructs any backend from `provider`+`model`(+endpoint/key). The engine, scoring, and persistence never reference a provider SDK. No egress guard. | PASS |
| II. Datasets Provisioned, Not Fetched | No run-time fetch; fail fast on missing; report presence pre-run | `datasets/registry.py` resolves every required dataset from a local path, verifies presence before a run starts (FR-073), and raises a typed `DatasetNotProvisioned` error that marks the run failed — no fallback path exists. | PASS |
| III. Single Configurable Judge | One explicit judge (any provider); block judge metrics if unconfigured | Single global `JudgeConfig` (any provider); deepeval metrics are constructed with a LangChain-backed judge instance. If no judge is configured, LLM-as-judge metrics are not constructed and the suite reports why (FR-041). Judge identity recorded in the snapshot. | PASS |
| IV. Faithful & Traceable Measurement | Reproducible provenance; disclose non-native scoring | Each run persists a full config snapshot (provider, model, endpoint, datasets+versions, judge identity, axis points, thresholds, scoring method, reference tokenizer, needle construction). Tool scoring uses BFCL's **native** AST scorer → results labeled BFCL-AST-comparable. No silent approximation. | PASS |
| V. Fail Loud, Never Silently Degrade | Explicit run states; record failures at granularity; no silent substitution | Run state machine: `queued → running → {completed, failed, interrupted, partial}`. Oversized-needle items and over-capacity context points recorded as skipped-with-reason; other points retained. No smaller-context/alt-dataset/alt-model substitution anywhere. | PASS |
| VI. Credential Safety | Keys never rendered; not in logs/URLs/exports | API keys stored in SQLite, surfaced through a `SecretRef` that masks on read for UI/logs/exports; never interpolated into displayed URLs. | PASS |
| VII. Verifiability of Critical Paths | Tests for provider abstraction, scoring adapters, axis construction, persistence | Mandatory pytest suites for each; the full `worker → handler → orchestrator` path is exercised with a fake `ChatProvider` and fake scorer, no network required. | PASS |

**Result**: All gates PASS. No principle requires a waiver. **Complexity Tracking is empty** (no violations to justify).

## Project Structure

### Documentation (this feature)

```text
specs/001-model-evaluation-platform/
├── plan.md              # This file (/speckit-plan command output)
├── research.md          # Phase 0 output (/speckit-plan command)
├── data-model.md        # Phase 1 output (/speckit-plan command)
├── quickstart.md        # Phase 1 output (/speckit-plan command)
├── contracts/           # Phase 1 output (/speckit-plan command)
│   ├── model-config.schema.json
│   ├── model-config.local.example.json
│   ├── model-config.azure.example.json
│   └── evaluation-run.contract.md
└── tasks.md             # Phase 2 output (/speckit-tasks command - NOT created by /speckit-plan)
```

### Source Code (repository root)

```text
src/model_eval/
├── app/                      # Streamlit entrypoint + 3 pages
│   ├── main.py               # st app shell / navigation
│   └── pages/
│       ├── 1_Onboarding.py
│       ├── 2_Evaluation.py
│       └── 3_Results.py
├── config/                   # model-config schema + validation (pydantic)
│   ├── schema.py
│   └── templates.py          # copyable provider JSON templates (FR-004)
├── providers/                # universal model connectivity (LangChain)
│   ├── base.py               # common ChatProvider interface
│   ├── langchain_provider.py # wraps init_chat_model() — any provider
│   ├── __init__.py           # build_provider(config) factory
│   └── deepeval_model.py     # DeepEvalBaseLLM wrapper over a LangChain model (judge)
├── datasets/                 # local dataset registry + presence checks (Principle II)
│   ├── registry.py
│   └── loaders.py
├── eval/
│   ├── runner.py             # background worker, run state machine, progress
│   ├── axis/
│   │   ├── tokenizer.py       # single reference tokenizer (tiktoken)
│   │   ├── needle.py          # context-window needle-in-haystack synthesis (FR-023)
│   │   └── tool_count.py      # distractor tool sampling to N tools (FR-025)
│   ├── llm_suite/
│   │   ├── orchestrator.py    # runs chatbot+rag+toolcalling as one job (FR-020)
│   │   ├── chatbot.py
│   │   ├── rag.py
│   │   └── toolcalling/
│   │       ├── bfcl_loader.py     # AST-categories-only loader (FR-026a)
│   │       └── ast_scorer/        # vendored BFCL native AST checker (Apache 2.0)
│   └── extraction/
│       ├── runner.py
│       └── omnidocbench/          # vendored OmniDocBench end2end metrics (Apache 2.0)
└── db/
    ├── schema.sql
    └── repository.py          # run/result/model persistence (SQLite, WAL)

tests/
├── contract/        # model-config schema validation; run-submission contract
├── integration/     # end-to-end suite run, extraction run, results drill-down
└── unit/            # ast_scorer, omnidocbench adapter, needle/tool-count, repository, secret masking
```

**Structure Decision**: Single project. The Streamlit app (`app/`) is a thin presentation layer over a pure-Python library (`config`, `providers`, `datasets`, `eval`, `db`) so that the constitution's critical paths (provider abstraction, scoring adapters, axis construction, persistence) are unit-testable without Streamlit or a live model. Vendored third-party scorers (BFCL AST checker, OmniDocBench) live under their consuming modules with their licenses retained.

## Complexity Tracking

> No Constitution Check violations. This section is intentionally empty.
