# Quickstart & Validation Guide: Enterprise Model Evaluation Platform

**Feature**: `001-model-evaluation-platform` | **Date**: 2026-07-01

> **Amended 2026-07-01 (constitution v2.0.0)**: air-gap requirements removed; model connectivity is now via **LangChain**, and candidate/judge models may be hosted anywhere.

This guide proves the feature works end-to-end. It references [data-model.md](data-model.md), [contracts/](contracts/), and [research.md](research.md) rather than restating them. It is a validation/run guide — implementation belongs to `tasks.md`.

## Prerequisites

- Python 3.11+, with LangChain plus the provider integration(s) you plan to use (e.g. `langchain-openai`, `langchain-anthropic`) installed.
- `latexml` binary on PATH, only if evaluated documents contain formulas (OmniDocBench formula scoring — R7).
- Benchmark data provisioned to local storage and registered in the Dataset registry:
  `chatbot_qa_base`, filler corpus, `rag_corpus`, `bfcl_ast` (AST categories only), `omnidocbench`.
- `tiktoken` `cl100k_base` encoding available (R1).
- At least one reachable model endpoint (local or remote) to serve as the candidate, and one to serve as the **global judge** (R5) — any LangChain-supported provider.

## Setup

```bash
# Set provider credentials for whichever providers you'll onboard, e.g.:
export OPENAI_API_KEY=...
export ANTHROPIC_API_KEY=...

# Launch the app (creates the SQLite file + schema on first run)
streamlit run src/model_eval/app/main.py
```

## Validation scenarios

Each scenario maps to user stories / success criteria. ✅ = expected outcome.

### V1 — Onboard models from different providers (US1, SC-001, SC-003)
1. Onboarding page → "Show template" → copy the **local** and **remote-provider** templates ([contracts/model-config.local.example.json](contracts/model-config.local.example.json), [contracts/model-config.remote.example.json](contracts/model-config.remote.example.json), [contracts/model-config.azure.example.json](contracts/model-config.azure.example.json)).
2. Submit a valid local config (`capabilities.chat_suite=true`). ✅ Model appears on the Evaluation page; round-trip < 2 min.
3. Submit a valid config for a different provider (e.g. `anthropic`). ✅ Same workflow, no code change needed (FR-002a/SC-003).
4. Submit a config missing `model`. ✅ Rejected naming the field; nothing persisted (FR-005).
5. Submit an azure_openai config without `azure_deployment`. ✅ Rejected identifying the Azure field (FR-006).
6. Re-submit a config whose `name` already exists. ✅ Rejected "model name already exists"; nothing persisted (FR-007a).
7. Anywhere the model is shown afterwards. ✅ API key is masked, never plaintext (FR-009).

### V2 — Configure the global judge (US2 precondition, FR-040/041)
1. Designate an onboarded model — any provider — as the global judge.
2. Remove the judge and start an LLM suite. ✅ LLM-as-judge metrics do not run and the suite reports why (FR-041).

### V3 — Combined LLM suite (US2, SC-002)
1. Select a `chat_suite` model + configured judge → start the combined suite (one action; sub-evaluations not individually selectable — FR-020).
2. ✅ A single run produces AxisResults for **all 5** chatbot context sizes, **all 5** RAG context sizes, and **all 5** tool counts (≥15 rows; SC-002).
3. ✅ Context sizes are counted with the single reference tokenizer; tool-calling rows use `bfcl_ast` (native scorer); each AxisResult records `score`, `threshold` (default 0.5), `passed` (FR-028).
4. Navigate away and back mid-run. ✅ Live `progress` and status are accurate; UI never blocks (FR-072/SC-007).
5. Repeat with a model from a different provider than the judge. ✅ Same behavior — the run doesn't care where either endpoint lives (SC-003).

### V4 — Text-extraction standalone (US3, SC-005, SC-008)
1. Run text-extraction on an `extraction`-capable model. ✅ Runs without triggering the LLM suite; ExtractionResults stored per document with text/table/formula/reading-order + overall (FR-053).
2. Attempt text-extraction on a non-`extraction` model. ✅ Prevented with an explanation (FR-054/SC-008).

### V5 — Results & comparison (US4, SC-006)
1. Results page lists prior runs (model, suite type, timestamp, status) (FR-062).
2. Drill into the combined run → chatbot/RAG per context window, tool-calling per tool count (FR-062).
3. Compare two `llm-combined` runs — even across different providers — on identical axes (FR-063/SC-006).

### V6 — Dataset provisioning & fail-loud guarantees (Principles II/V, SC-004) — **mandatory tests**
1. **Dataset fail-fast**: remove a required dataset (e.g., `bfcl_ast`) and start a suite. ✅ Run `failed` with "dataset not provisioned locally"; **no fetch attempted** (SC-004); other datasets unaffected report normally.
2. **Oversized needle**: include a base QA item longer than 5k reference tokens. ✅ That item is `skipped` with reason at the 5k point; the run is `partial`, not `completed` (FR-023/Principle V).
3. **Judge/model unreachable**: point the judge or candidate at an unreachable endpoint mid-run. ✅ Run marked `failed`/`partial` with a reason; completed axis points retained.

## Automated validation (pytest — Principle VII)

```bash
pytest tests/unit/test_ast_scorer.py          # BFCL native AST scoring adapter
pytest tests/unit/test_omnidocbench.py        # extraction scoring adapter
pytest tests/unit/test_needle.py              # context-window synthesis + skip rule
pytest tests/unit/test_tool_count.py          # distractor sampling to N tools
pytest tests/unit/test_repository.py          # run/result persistence + state machine
pytest tests/integration                      # full suite + extraction + results drill-down (fake providers, no network)
```

✅ **Definition of done for this guide**: V1–V6 pass and the mandatory pytest suites are green, with the integration suite demonstrating the full `worker → handler → orchestrator` path runs against a fake provider with no live network dependency.
