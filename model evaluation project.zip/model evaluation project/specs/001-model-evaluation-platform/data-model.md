# Phase 1 Data Model: Enterprise Model Evaluation Platform

**Feature**: `001-model-evaluation-platform` | **Date**: 2026-07-01 | **Store**: SQLite (WAL), single file

Derived from the spec's Key Entities and clarifications. All persistence is local (CON-003/FR-064). Timestamps are ISO-8601 UTC. Enumerated values are stored as text and validated in the repository layer.

---

## Entity overview & relationships

```text
ModelConfig 1 ──< EvaluationRun 1 ──< AxisResult        (LLM-suite runs)
                              └──< ExtractionResult      (text-extraction runs)
JudgeConfig (singleton, global)  ── snapshot copied into EvaluationRun.config_snapshot
Dataset (local registry)         ── referenced by name in EvaluationRun.config_snapshot
```

---

## ModelConfig

A registered model available for evaluation. (Spec: ModelConfig; FR-001/002/006/007/007a/008/009/010)

| Field | Type | Notes |
|-------|------|-------|
| `id` | INTEGER PK | surrogate key |
| `name` | TEXT | **UNIQUE** (FR-007a); user-facing logical id |
| `provider` | TEXT | LangChain provider key: `openai` \| `anthropic` \| `azure_openai` \| `google_genai` \| `ollama` \| `local` |
| `model` | TEXT | the model identifier passed to the provider (e.g. `gpt-4o`, `claude-opus-4-8`) |
| `endpoint_url` | TEXT nullable | base URL for local/custom servers / `azure_endpoint` (azure) |
| `api_key` | TEXT (secret) | stored; surfaced only via `SecretRef` mask (FR-009) |
| `azure_deployment` | TEXT nullable | required when `provider=azure_openai` (FR-006) |
| `azure_api_version` | TEXT nullable | required when `provider=azure_openai` (FR-006) |
| `capabilities` | TEXT (JSON) | flags: `chat_suite` (bool), `extraction` (bool) (FR-008) |
| `max_context_window` | INTEGER nullable | optional declared cap (FR-010 → FR-024) |
| `created_at` | TEXT | ISO-8601 |

**Validation**: `name` non-empty + unique; `provider` non-empty; `model` non-empty; if `provider=azure_openai`, `azure_deployment` and `azure_api_version` present (FR-006); `capabilities` has at least one true flag. Invalid → reject naming the field, persist nothing (FR-005). `endpoint_url` is optional (required only for local/custom-hosted servers).

**Note**: `is_judge` is intentionally **not** a ModelConfig field — the judge is a global singleton (Q3), see JudgeConfig.

## JudgeConfig (global singleton)

The single model (any provider) used to grade all LLM-as-judge metrics. (Spec: JudgeConfig; FR-040/041/042)

| Field | Type | Notes |
|-------|------|-------|
| `id` | INTEGER PK | enforced single row (id=1) |
| `model_config_id` | INTEGER FK → ModelConfig.id nullable | the model (any provider) acting as judge |
| `updated_at` | TEXT | |

**Rules**: At most one active judge. If unset (`model_config_id IS NULL`), LLM-as-judge metrics MUST NOT run and the suite reports why (FR-041). The judge's identity is copied into each run's `config_snapshot` at start (FR-042) so later changes don't rewrite history.

## Dataset (local registry)

A locally-provisioned benchmark dataset. (Spec: Dataset; FR-012/013/073)

| Field | Type | Notes |
|-------|------|-------|
| `name` | TEXT PK | logical name (e.g., `chatbot_qa_base`, `bfcl_ast`, `rag_corpus`, `omnidocbench`) |
| `suite` | TEXT enum | `chatbot` \| `rag` \| `tool-calling` \| `extraction` |
| `local_path` | TEXT | absolute path on the host |
| `present` | BOOLEAN (derived) | verified at check time; not trusted as cached |
| `version` | TEXT nullable | recorded for provenance (FR-IV) |

**Rules**: Presence is verified live before a run (FR-073). A required-but-absent dataset raises `DatasetNotProvisioned` → run `failed`, no fetch (FR-013). The reference-tokenizer encoding cache and `latexml` availability are validated by the same pre-run gate.

## EvaluationRun

One execution of a job. (Spec: EvaluationRun; FR-055/060/072)

| Field | Type | Notes |
|-------|------|-------|
| `id` | INTEGER PK | |
| `model_config_id` | INTEGER FK → ModelConfig.id | model under test |
| `suite_type` | TEXT enum | `llm-combined` \| `text-extraction` (FR-055) |
| `status` | TEXT enum | `queued` \| `running` \| `completed` \| `failed` \| `interrupted` \| `partial` (FR-060/V) |
| `started_at` / `ended_at` | TEXT nullable | |
| `progress` | TEXT (JSON) | `{current_sub, current_axis_point, done, total}` (FR-072) |
| `config_snapshot` | TEXT (JSON) | axis points, judge identity, datasets+versions, thresholds, scoring method, reference tokenizer, needle params (FR-IV/042) |
| `failure_reason` | TEXT nullable | populated for `failed`/`interrupted` |

**State machine**:

```text
queued ──> running ──> completed         (all axis points produced)
                   ├─> partial            (some axis points skipped/failed, others retained)
                   ├─> failed             (fatal: missing dataset, unreachable judge/model w/ no usable results)
                   └─> interrupted        (process died: a `running` row with no live worker on restart)
```

A run with any skipped/failed axis point but ≥1 retained result is `partial`, never `completed` (Principle V).

## AxisResult

A result at one axis point of an LLM-suite sub-evaluation. (Spec: AxisResult; FR-021/022/023/026b/028/061)

| Field | Type | Notes |
|-------|------|-------|
| `id` | INTEGER PK | |
| `run_id` | INTEGER FK → EvaluationRun.id | |
| `sub_evaluation` | TEXT enum | `chatbot` \| `rag` \| `tool-calling` |
| `axis_kind` | TEXT enum | `context-window` \| `tool-count` |
| `axis_value` | INTEGER | e.g., `20000` (tokens) or `30` (tools) |
| `metric_name` | TEXT | e.g., `faithfulness`, `answer_relevancy`, `conversational_completeness`, `bfcl_ast` |
| `score` | REAL nullable | raw score on native scale (0–1 for judge metrics) (FR-028) |
| `threshold` | REAL nullable | applied cutoff, default 0.5, from snapshot (FR-028) |
| `passed` | BOOLEAN nullable | `score >= threshold`; null when skipped |
| `status` | TEXT enum | `scored` \| `skipped` \| `failed` |
| `reason` | TEXT nullable | skip/fail reason (e.g., "needle exceeds 5k", "exceeds model max context") (FR-023/024) |

**Rules**: One row per (sub_evaluation, axis_value, metric_name). Tool-calling rows use the BFCL native AST scorer and `metric_name=bfcl_ast` with `scoring_method` recorded in the run snapshot (FR-026b/IV). Skipped points carry a `reason` and null `score`/`passed` (Principle V).

## ExtractionResult

A per-document text-extraction result. (Spec: ExtractionResult; FR-051/053/061)

| Field | Type | Notes |
|-------|------|-------|
| `id` | INTEGER PK | |
| `run_id` | INTEGER FK → EvaluationRun.id | |
| `document_id` | TEXT | benchmark doc/page id |
| `text_edit_distance` | REAL nullable | normalized edit distance (text) |
| `reading_order_edit_distance` | REAL nullable | normalized edit distance (reading order) |
| `table_teds` | REAL nullable | TEDS |
| `formula_score` | REAL nullable | formula metric (requires `latexml`) |
| `overall` | REAL nullable | combined OmniDocBench score |
| `status` | TEXT enum | `scored` \| `failed` |
| `reason` | TEXT nullable | e.g., "latexml unavailable", "empty model output" |

**Rules**: Malformed/empty model output is scored as-is by OmniDocBench, not crashed (Edge Cases). A missing `latexml` fails the run loud rather than zero-scoring formulas silently (Principle V).

---

## Derived / snapshot structures (not separate tables)

- **MetricThreshold** (spec entity): represented by `AxisResult.threshold` + the per-metric default map captured in `config_snapshot.thresholds` (FR-028).
- **config_snapshot** schema (JSON in EvaluationRun): `{ model: {name, provider}, judge: {name} | null, datasets: [{name, version}], axis: {context_window:[...], tool_count:[...]}, thresholds: {metric: value}, scoring_method: "bfcl_ast_native", reference_tokenizer: "tiktoken/cl100k_base", needle: {position, filler_source} }`.

## Indexes

- `ModelConfig(name)` UNIQUE.
- `EvaluationRun(model_config_id)`, `EvaluationRun(status)`, `EvaluationRun(suite_type)`.
- `AxisResult(run_id)`, `AxisResult(run_id, sub_evaluation, axis_kind)`.
- `ExtractionResult(run_id)`.

These support the Results page list + drill-down and same-axis comparison (FR-062/063).
