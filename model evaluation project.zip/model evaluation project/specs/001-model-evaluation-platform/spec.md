# Feature Specification: Enterprise Model Evaluation Platform

**Feature Branch**: `001-model-evaluation-platform`
**Created**: 2026-06-30
**Status**: Draft
**Input**: User description: "An enterprise evaluation platform (Streamlit + SQLite + Python) that onboards models hosted **anywhere** — local or remote — through a universal provider layer (LangChain), via JSON config, and runs four evaluation suites — chatbot, RAG, and tool-calling (via deepeval, run together) and text-extraction (via OmniDocBench, run standalone) — using locally-provisioned benchmark datasets, with results persisted and browsable."

> **Amended 2026-07-01 (constitution v2.0.0)**: The original air-gapped, local-only design was relaxed at the owner's direction. Models may now be hosted anywhere and are reached through one universal provider abstraction (LangChain); the judge may be any provider; there is no egress guard. Datasets remain locally provisioned (for reproducibility, not air-gap). Air-gap requirements (former FR-011/014/015, SC-003) are removed.

---

## Clarifications

This section consolidates the open decisions surfaced during specification. Each is also tagged inline at the relevant requirement.

- **Judge model** (amended v2.0.0): deepeval's LLM-as-judge metrics (Faithfulness, Answer Relevancy, conversational metrics, G-Eval) need a grader model. A single global judge is configured explicitly and MAY be any provider (local or remote), reached through the same LangChain provider layer. `ToolCorrectnessMetric`/BFCL AST scoring are deterministic and need no judge. → Resolved in FR-040/FR-041.
- **Context-window axis (chatbot)** (RESOLVED, Q1): deepeval benchmark datasets do not vary by context length, so the 5k/10k/20k/30k/50k-token axis is synthesized via **needle-in-haystack** placement — the answer-bearing content is embedded at varying depths within filler context padded to each target size. The base dataset is a QA-style set from the locally-provisioned deepeval benchmark data (specific set selected in planning).
- **Tool-calling dataset**: RESOLVED — BFCL (Berkeley Function Calling Leaderboard), Apache 2.0, provisioned locally. Scope restricted to single-turn **AST** categories (simple / multiple / parallel / parallel_multiple); **Executable** categories and V3 multi-turn are excluded because they require live API execution / a stateful backend — out of scope for deterministic AST scoring.
- **Tool-calling scoring method** (RESOLVED, Q2): BFCL's **native AST scorer** — leaderboard-faithful, validates argument values per BFCL's own methodology. Deterministic (no judge LLM). Results are directly comparable to the public BFCL AST leaderboard. This is a separate scoring path from deepeval's `ToolCorrectnessMetric`.
- **Token counting** (RESOLVED, Q3): a **single reference tokenizer** is used to count "N tokens" for all models, making the context-window axis cross-model comparable. The actual context each model's own tokenizer sees may differ slightly from N; this is accepted in exchange for comparability.
- **RAG axis ratio** (resolved default): The RAG retrieval-context budget mirrors the chatbot axis (5k/10k/20k/30k/50k). Relevant-to-distractor composition is held constant across sizes at a fixed proportion (default: ~10% relevant content by token budget, ~90% distractor), so growth measures retrieval robustness rather than relevance density. Recorded as a default in FR-031; revisable in `/speckit-clarify`.

### Session 2026-07-01

- Q: How is pass/fail determined for LLM-as-judge quality metrics (no threshold was defined)? → A: Persist the raw 0–1 score and apply a configurable per-metric threshold (default 0.5, overridable per run) to derive pass/fail (FR-028).
- Q: In needle-in-haystack construction, when a base QA item already exceeds the target size N, what happens? → A: Skip that item at that axis point and record skip-with-reason; never truncate the answer-bearing content (FR-023, Edge Cases).
- Q: How is the judge model chosen? → A: A single, globally-configured judge model is used for all runs; it may be any provider (local or remote); the active judge is recorded in each run's snapshot (FR-040/FR-042).
- Q: What happens when a model with an existing logical name is onboarded again? → A: Model logical name MUST be unique; a colliding submission is rejected with a clear message and nothing is persisted (FR-007a, Edge Cases).

---

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Onboard a model via JSON configuration (Priority: P1)

A platform engineer registers a new model — hosted anywhere (e.g. OpenAI, Anthropic, Azure OpenAI, Google, Ollama, or any OpenAI-compatible local endpoint) — by submitting a JSON configuration that names the `provider` and `model` and, where required, an endpoint URL and API key. The platform validates the configuration and stores it for later evaluation runs.

**Why this priority**: No evaluation can run without at least one onboarded model. This is the entry point of the entire workflow and must exist before any other story delivers value.

**Independent Test**: Submit a valid JSON config for two different providers (e.g. a local OpenAI-compatible model and a remote provider); confirm both appear as selectable, persisted models. Submit a malformed config and confirm it is rejected with a specific validation error.

**Acceptance Scenarios**:

1. **Given** an empty model registry, **When** the user submits a valid model JSON config (provider + model + capabilities), **Then** the model is persisted and appears in the model list on the Evaluation page.
2. **Given** the onboarding page, **When** the user requests the template example, **Then** a complete, copyable JSON template is shown with placeholder fields for provider, model, endpoint URL, and API key.
3. **Given** a JSON config missing a required field (e.g., model), **When** the user submits it, **Then** onboarding fails with a message naming the missing/invalid field and nothing is persisted.
4. **Given** an Azure-OpenAI config, **When** the user submits it without a deployment name or API version, **Then** validation fails identifying the Azure-specific missing field.

---

### User Story 2 - Run the combined LLM evaluation suite (chatbot + RAG + tool-calling) (Priority: P1)

An engineer selects an onboarded model and runs the combined LLM suite. The three sub-evaluations always run together as one job. Each sub-evaluation sweeps its configured axis: chatbot and RAG across context-window sizes (5k/10k/20k/30k/50k tokens), tool-calling across tool counts (5/10/20/30/50). Datasets are read from local storage; the judge is the configured global judge model. Results are persisted per sub-evaluation, per axis point.

**Why this priority**: This is the core value of the platform — measuring how a candidate model behaves across the dimensions the organization cares about, regardless of where that model is hosted.

**Independent Test**: With one onboarded model and locally-present datasets, launch the combined suite; confirm a single run produces chatbot, RAG, and tool-calling results at every configured axis point, with all judged metrics graded by the configured judge.

**Acceptance Scenarios**:

1. **Given** an onboarded model and locally-cached benchmark datasets, **When** the user starts the combined suite, **Then** chatbot, RAG, and tool-calling sub-evaluations all execute within one run and cannot be deselected individually.
2. **Given** the chatbot sub-evaluation, **When** it executes, **Then** the model is evaluated at exactly 5k, 10k, 20k, 30k, and 50k token context windows and a score is recorded for each.
3. **Given** the tool-calling sub-evaluation, **When** it executes, **Then** the model is evaluated with exactly 5, 10, 20, 30, and 50 available tools and a tool-selection score is recorded for each.
4. **Given** a configured global judge model, **When** any LLM-as-judge metric runs, **Then** all judging is performed by that single configured judge (whatever provider it is) and its identity is recorded in the run snapshot.
5. **Given** no judge is configured, **When** the user starts the suite, **Then** the LLM-as-judge metrics do not run and the suite reports why (the deterministic tool-calling metric still runs).
6. **Given** a long-running suite, **When** it is executing, **Then** the UI reflects live progress (current sub-evaluation and axis point) and the run can be observed without blocking the app.

---

### User Story 3 - Run the text-extraction evaluation standalone (Priority: P2)

An engineer selects a model that supports document input and runs the text-extraction evaluation alone (independent of the LLM suite). The model converts benchmark PDF/page documents to Markdown; OmniDocBench scores the extraction accuracy against locally-stored ground truth.

**Why this priority**: Document-to-Markdown accuracy is a distinct capability evaluated against a different benchmark (OmniDocBench) and a different model capability profile (document/vision input). It is valuable but not every onboarded model is a candidate, so it ranks below the universal LLM suite.

**Independent Test**: Select a document-capable model, run text-extraction alone, and confirm OmniDocBench end-to-end metrics (edit distance, table TEDS, etc.) are produced and stored, with the LLM suite untouched.

**Acceptance Scenarios**:

1. **Given** a document-capable onboarded model, **When** the user runs text-extraction, **Then** it executes without triggering the chatbot/RAG/tool-calling suite.
2. **Given** locally-stored OmniDocBench files, **When** extraction runs, **Then** the model's Markdown outputs are scored against the local ground truth and accuracy metrics are recorded.
3. **Given** a model whose configuration does not declare document/extraction capability, **When** the user attempts to run text-extraction on it, **Then** the platform prevents the run and explains the capability requirement.

---

### User Story 4 - View and compare previous results (Priority: P2)

An engineer opens the Results page to review historical evaluation runs for one or more models, including per-axis breakdowns (per context window, per tool count) and per-document extraction scores.

**Why this priority**: Persisted, browsable results are what make the platform a decision-support tool rather than a one-shot script. It depends on runs existing (Stories 2/3) so it follows them.

**Independent Test**: After at least one combined run and one extraction run, open the Results page and confirm both runs are listed with drill-down to per-axis-point scores.

**Acceptance Scenarios**:

1. **Given** prior completed runs, **When** the user opens the Results page, **Then** runs are listed with model, suite type, timestamp, and status.
2. **Given** a selected combined run, **When** the user drills in, **Then** chatbot/RAG scores per context window and tool-calling scores per tool count are displayed.
3. **Given** two runs of the same suite on different models, **When** the user views them, **Then** results are presented so the models can be compared on the same axis.

---

### Edge Cases

- What happens when a required benchmark dataset is not present in local storage at run time? (Run must fail fast with a clear "dataset not provisioned locally" error, not attempt a download.)
- What happens when the configured judge model (any provider) is unreachable mid-run? (Run is marked failed/partial; completed axis points are retained.)
- What happens when a model endpoint times out at the largest context window (e.g., 50k tokens exceeds the model's max context)? (That axis point is recorded as a failure/skipped with reason; other points still complete.)
- What happens when the same model JSON is onboarded twice? (Logical names are unique — a name collision is rejected with a "model name already exists" message and nothing is persisted; see FR-007a.)
- What happens when an API key is present in a stored config and the Results/onboarding pages are displayed? (Key must never be rendered in plaintext in the UI or logs.)
- What happens if a combined run is interrupted (process restart)? (Run state in the database must allow it to be marked interrupted; no silent partial "success".)
- What happens when "N tokens" of padding cannot be reached because the base item is already longer than N? (The item is skipped at that axis point and recorded as skipped-with-reason; the answer-bearing content is never truncated — see FR-023.)
- What happens during text-extraction when the model emits malformed Markdown or empty output for a page? (Scored as-is by OmniDocBench; not crashed.)

---

## Requirements *(mandatory)*

### Functional Requirements — Onboarding

- **FR-001**: System MUST accept model onboarding as a JSON configuration document.
- **FR-002**: System MUST support models from any LangChain-supported provider (e.g. `openai`, `anthropic`, `azure_openai`, `google_genai`, `ollama`, and any OpenAI-compatible local endpoint). A configuration identifies the model by `provider` + `model`; an optional endpoint/base URL targets local or custom-hosted servers.
- **FR-002a**: Adding support for a new provider MUST be a configuration concern only — it MUST NOT require changes to the evaluation engine, scoring, or persistence (Constitution Principle I).
- **FR-003**: System MUST allow an API key to be included in the configuration (for providers that require one).
- **FR-004**: System MUST provide a copyable template example of the configuration JSON, with placeholder fields for provider, model, endpoint URL, and API key.
- **FR-005**: System MUST validate submitted configurations and reject invalid ones with a message identifying the offending field; nothing is persisted on failure.
- **FR-006**: System MUST require, for Azure configs, the Azure-specific fields needed to address a deployment (e.g., endpoint, deployment name, API version) and validate their presence.
- **FR-007**: System MUST persist accepted configurations so onboarded models are selectable on the Evaluation page across sessions.
- **FR-007a**: Each model's logical name/id MUST be unique within the registry. Onboarding a configuration whose name collides with an existing model MUST be rejected with a clear "model name already exists" message, and nothing is persisted (protecting the reproducibility of prior runs that reference that name).
- **FR-008**: Each model configuration MUST declare the capabilities it is eligible for (at minimum: chat/LLM-suite eligibility, and document/extraction eligibility).
- **FR-009**: System MUST NOT display stored API keys in plaintext anywhere in the UI or in result exports/logs.
- **FR-010**: Configuration SHOULD allow declaring the model's maximum context window so axis points exceeding it can be handled gracefully (see FR-024).

### Functional Requirements — Connectivity & Datasets

> *(amended v2.0.0 — the former air-gap requirements FR-011/FR-014/FR-015 are removed; the platform may reach model endpoints anywhere. Dataset provenance requirements are retained for reproducibility.)*

- **FR-011**: System MAY reach model and judge endpoints over the network at any location; there is no air-gap or egress allowlist enforced. *(An optional restricted/offline deployment mode may be added later by amendment.)*
- **FR-012**: All benchmark datasets MUST be provisioned ahead of time and read exclusively from local storage during runs (reproducibility — Constitution Principle II).
- **FR-013**: System MUST NOT attempt any benchmark-dataset download or remote dataset fetch during an evaluation run; absence of a required local dataset MUST cause a fast, explicit failure.

### Functional Requirements — Combined LLM suite (run together)

- **FR-020**: System MUST run chatbot, RAG, and tool-calling sub-evaluations together as a single, indivisible job; the user MUST NOT be able to run one of the three alone.
- **FR-021**: System MUST evaluate the chatbot sub-evaluation at exactly these context-window sizes: 5,000 / 10,000 / 20,000 / 30,000 / 50,000 tokens, recording a result per size. Token counts MUST be measured with a single fixed reference tokenizer applied uniformly to all models (see Clarifications, Q3), so axis points are cross-model comparable; the reference tokenizer identity MUST be recorded with each run.
- **FR-022**: System MUST evaluate the tool-calling sub-evaluation at exactly these tool counts: 5 / 10 / 20 / 30 / 50 available tools, recording a result per count.
- **FR-023**: The chatbot context-window axis MUST be produced via **needle-in-haystack** synthesis: the answer-bearing content of a locally-stored base QA dataset item is embedded at a controlled depth within filler context padded to each target token count (5k/10k/20k/30k/50k). The construction (needle depth/position and filler source) MUST be recorded with each result per the constitution's traceability principle. When a base item's answer-bearing content already exceeds a target size N (so the needle cannot fit), that item MUST be skipped at that axis point and recorded as skipped-with-reason; the answer-bearing content MUST NOT be truncated.
- **FR-024**: When a target context-window size exceeds a model's declared/observed maximum, the system MUST record that axis point as skipped-with-reason rather than failing the entire run.
- **FR-025**: The tool-calling axis MUST present the model with the correct (ground-truth) tool plus distractor tool definitions — drawn from other BFCL tool schemas — such that the total number of available tools equals the axis point (5/10/20/30/50), while holding the query and ground-truth tool fixed across the sweep. Per FR-026b, scoring validates both tool selection and argument values.
- **FR-026**: The tool-calling sub-evaluation MUST draw tasks (queries, function/tool schemas, and ground-truth function calls) from BFCL, downloaded and stored locally (Apache 2.0).
- **FR-026a**: The tool-calling sub-evaluation MUST be restricted to BFCL single-turn **AST** categories (simple / multiple / parallel / parallel_multiple). It MUST NOT use BFCL **Executable** categories or V3 multi-turn categories, because these require live API execution or a stateful backend — out of scope for deterministic AST scoring.
- **FR-026b**: Tool-call correctness MUST be scored deterministically (no judge LLM) using **BFCL's native AST scorer**, which validates both the selected function and its argument values per BFCL's published methodology. Because this is BFCL's native method, AST-category results MAY be presented as comparable to the public BFCL AST leaderboard; the scoring method MUST still be recorded with each result per the constitution's traceability principle.
- **FR-027**: The chatbot sub-evaluation MUST produce conversational quality scores (e.g., completeness / relevancy / knowledge-retention class metrics) per context-window size.
- **FR-028**: For every LLM-as-judge quality metric (chatbot and RAG), the system MUST persist the raw metric score on its native 0–1 scale, and MUST derive a pass/fail verdict by comparing that score to a configurable threshold. The default threshold is 0.5 per metric and MUST be overridable per run; the threshold applied MUST be recorded with each AxisResult so verdicts are reproducible. (Deterministic metrics scored by the BFCL native AST scorer are unaffected.)

### Functional Requirements — RAG sub-evaluation

- **FR-030**: The RAG sub-evaluation MUST mirror the chatbot axis by varying the injected retrieval-context token budget across 5,000 / 10,000 / 20,000 / 30,000 / 50,000 tokens, recording RAG-quality scores (e.g., faithfulness, contextual precision/recall, answer relevancy class metrics) per size.
- **FR-031**: The RAG sub-evaluation MUST hold a defined relevant-to-distractor content ratio constant across sizes so growth measures retrieval robustness, not just relevance density. Default: ~10% relevant content by token budget and ~90% distractor, held constant across all axis sizes (revisable in `/speckit-clarify`).
- **FR-032**: RAG retrieval context MUST be assembled from locally-stored corpora only.

### Functional Requirements — Judge model (shared by LLM-as-judge metrics)

- **FR-040**: System MUST use a single, globally-configured model as the evaluation judge for all LLM-as-judge metrics (chatbot, RAG, any G-Eval-style metric). The judge MAY be any provider (local or remote), reached through the same provider layer as candidate models. It is configured once and applies to every run rather than being chosen per run.
- **FR-041**: System MUST NOT grade with an unspecified/default model; if no judge is configured, LLM-as-judge metrics MUST NOT run (and MUST report why).
- **FR-042**: The identity of the globally-configured judge model in effect at run time MUST be captured in each run's configuration snapshot, so a result remains interpretable even if the global judge is later changed.

### Functional Requirements — Text-extraction (standalone)

- **FR-050**: System MUST allow the text-extraction evaluation to run on a model independently of the combined LLM suite.
- **FR-051**: Text-extraction MUST evaluate a model's accuracy at converting documents (e.g., PDF pages) into Markdown.
- **FR-052**: Text-extraction MUST use OmniDocBench evaluation files and ground truth served entirely from local storage.
- **FR-053**: Text-extraction MUST score outputs using OmniDocBench's end-to-end metrics (normalized edit distance for text/reading order, TEDS for tables, formula metric, and the combined overall score).
- **FR-054**: System MUST only permit text-extraction on models whose configuration declares document/extraction capability, and MUST explain the requirement when a non-eligible model is selected.
- **FR-055**: Text-extraction runs and the combined LLM suite MUST be persisted as distinct run types.

### Functional Requirements — Results & persistence

- **FR-060**: System MUST persist every run with at least: model reference, suite type, start/end time, status (queued / running / completed / failed / interrupted / partial), and configuration snapshot.
- **FR-061**: System MUST persist results at axis-point granularity (per context-window size, per tool count) and per-document granularity for extraction.
- **FR-062**: The Results page MUST list historical runs and allow drill-down into per-axis-point and per-document scores.
- **FR-063**: The Results page MUST allow viewing two or more runs of the same suite type so models can be compared on the same axis.
- **FR-064**: All persistence MUST use the local embedded database; no external datastore.

### Functional Requirements — Application & UX

- **FR-070**: System MUST present exactly three pages: Onboarding, Evaluation, and Results.
- **FR-071**: The Evaluation page MUST expose the combined LLM suite as one action and text-extraction as a separate action.
- **FR-072**: Long-running evaluations MUST not freeze the interface; the system MUST track run progress/state in the database and surface live status, so a user can navigate away and return.
- **FR-073**: System MUST clearly indicate, before a run starts, which datasets are required and whether they are present locally.

### Non-Functional / Constraints *(organization-mandated)*

- **CON-001**: Implementation language MUST be Python.
- **CON-002**: The application MUST be a Streamlit application.
- **CON-003**: Persistent storage MUST be SQLite.
- **CON-004**: Chatbot, RAG, and tool-calling MUST use deepeval.
- **CON-005**: Text-extraction MUST use OmniDocBench.
- **CON-006**: All benchmark/evaluation **datasets** MUST be provisioned locally (no run-time dataset fetch) — for reproducibility, not air-gap.
- **CON-007**: Model connectivity (candidate models and judge) MUST go through **LangChain** as the universal provider layer, so any supported backend is reachable through one uniform interface.

> Note: Per Spec Kit convention these stack choices normally live in the plan, not the spec. They are recorded here because the organization has mandated them as non-negotiable inputs (consistent with the project constitution's Technology & Architecture Constraints).

---

## Key Entities *(include if feature involves data)*

- **ModelConfig**: A registered model. Attributes: name/id (**unique** within the registry — see FR-007a), `provider` (LangChain provider key, e.g. openai | anthropic | azure_openai | google_genai | ollama | local), `model` (the model identifier passed to the provider), optional endpoint/base URL (for local/custom-hosted servers), credential reference (API key — stored, never displayed), provider-specific fields (e.g., Azure deployment, API version), declared capabilities (chat-suite eligible, extraction eligible), optional declared max context window. Relationships: one ModelConfig has many EvaluationRuns.
- **Dataset (local registry)**: A locally-provisioned benchmark dataset. Attributes: logical name, suite it serves (chatbot/RAG/tool-calling/extraction), local path, presence/verification status. Used to enforce FR-013/FR-073.
- **EvaluationRun**: One execution. Attributes: model reference, suite type (llm-combined | text-extraction), status, start/end time, configuration snapshot (axis points, judge model, datasets used), progress marker.
- **AxisResult**: A result at one axis point within a run. Attributes: run reference, sub-evaluation (chatbot | rag | tool-calling), axis kind (context-window | tool-count), axis value (e.g., 20000 tokens / 30 tools), metric name(s), score(s), pass/fail vs. threshold, failure/skip reason if any.
- **ExtractionResult**: A per-document extraction result. Attributes: run reference, document id/page, metric set (text edit distance, table TEDS, formula metric, reading-order edit distance, overall), score(s).
- **JudgeConfig**: the single, globally-configured model used to grade LLM-as-judge metrics (any provider, local or remote). One active judge applies to all runs (FR-040); the judge identity in effect is copied into each run's snapshot (FR-042).
- **MetricThreshold**: the pass/fail cutoff applied to a quality metric's raw 0–1 score (default 0.5, overridable per run; FR-028). Recorded alongside the AxisResult so verdicts are reproducible.

---

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: A user can onboard a valid model via JSON and see it available for evaluation in under 2 minutes, with zero plaintext exposure of the API key thereafter.
- **SC-002**: A complete combined LLM suite run on one model produces a recorded result for all 5 chatbot context-window sizes, all 5 RAG context-window sizes, and all 5 tool-count points — 15 axis results minimum — in a single run.
- **SC-003**: The same onboarding-and-run workflow works unchanged for at least two different providers (e.g. a local OpenAI-compatible model and one remote provider), with no change to the evaluation engine, scoring, or persistence (provider neutrality — Constitution Principle I).
- **SC-004**: With a required dataset deliberately removed, 100% of affected runs fail fast with an explicit "dataset not provisioned locally" message and never attempt a remote fetch.
- **SC-005**: A text-extraction run on a document-capable model yields OmniDocBench overall and per-element (text/table/formula/reading-order) scores stored and viewable, without invoking the LLM suite.
- **SC-006**: From the Results page, a user can compare the same suite across two models on identical axes without leaving the page.
- **SC-007**: A user can start a suite that runs for an extended period, navigate away, return, and observe accurate live/finished status — the UI never blocks waiting on the run.
- **SC-008**: Attempting to run text-extraction on a non-document-capable model is prevented in 100% of cases with an explanatory message.

---

## Assumptions

- Candidate and judge models are reachable through LangChain from the application host: local OpenAI-compatible servers via a base URL; remote providers (OpenAI, Anthropic, Google, etc.) via their API + key; Azure OpenAI via endpoint + deployment + API version.
- The benchmark datasets (deepeval benchmark sets, BFCL tool-calling data, RAG corpora, and OmniDocBench files) are provisioned to local storage by an out-of-band process before runs; provisioning itself is out of scope for this feature (the platform consumes, it does not fetch).
- The judge model for LLM-as-judge metrics is a single globally-configured model that may be any provider (local or remote), reached through the same provider layer as candidate models.
- "Tokens" for the context-window axis are counted with a single fixed reference tokenizer applied to all models (Clarifications, Q3), making axis points cross-model comparable; each model's own tokenizer may see a slightly different effective context.
- Text-extraction candidate models can accept document/page image input (multimodal) or are document-parsing pipelines; the extraction "model" may differ from the chat models used in the LLM suite.
- A single evaluation host is assumed (single-node SQLite); concurrent multi-user write contention is out of scope for v1.
- latexml (or equivalent) needed by OmniDocBench table scoring is available in the local environment.
- Dataset licensing permits local enterprise use; license compliance is assumed handled during provisioning. (BFCL is Apache 2.0; OmniDocBench and deepeval benchmark sources carry their own licenses to verify at provisioning time.)
- Duplicate onboarding is resolved by enforcing unique model names: a colliding submission is rejected and nothing is persisted (FR-007a), protecting the reproducibility of prior runs that reference that name.
