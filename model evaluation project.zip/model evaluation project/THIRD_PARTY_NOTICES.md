# Third-Party Notices

This project incorporates re-implementations of evaluation methodology from the
following Apache-2.0 licensed projects. Each component retains a `NOTICE.md`
beside its source describing exactly what was implemented and how it differs
from the upstream source.

## Berkeley Function Calling Leaderboard (BFCL) / Gorilla

- Upstream: https://github.com/ShishirPatil/gorilla
- License: Apache License 2.0
- Used for: tool-calling **AST** scoring (single-turn categories only).
- Location: [`src/model_eval/eval/llm_suite/toolcalling/ast_scorer/`](src/model_eval/eval/llm_suite/toolcalling/ast_scorer/NOTICE.md)
- Note: Executable and multi-turn categories are intentionally excluded (they
  require live execution / a stateful backend, out of scope for deterministic
  AST scoring).

## OmniDocBench

- Upstream: https://github.com/opendatalab/OmniDocBench
- License: Apache License 2.0
- Used for: text-extraction **end2end** metrics (normalized edit distance, TEDS,
  formula similarity, overall).
- Location: [`src/model_eval/eval/extraction/omnidocbench/`](src/model_eval/eval/extraction/omnidocbench/NOTICE.md)
- Note: the `latexml` external binary is required at run time when documents
  contain formulas; its absence fails the run loud rather than zero-scoring.

A full copy of the Apache License 2.0 should accompany any verbatim vendoring of
the upstream sources; the current modules are independent implementations of the
published metric definitions, recorded in each run's `scoring_method` for
traceability (Constitution Principle IV).
